<?php 
	session_start();
	include 'php/database.php';
	$c_id=$_GET['id'];
	$url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$who=$_SESSION['who'];
	//print_r($_SESSION);
	if(!isset($_SESSION['who']))
		header('location:html/login.php');

	$clgshortname1=$_SESSION['clg'];
	$sql = "select * from classroom where c_id = '$c_id'";
	$result = mysqli_query($db, $sql);
	if (mysqli_num_rows($result) ==1) {
	    while($row = mysqli_fetch_assoc($result)){
	    	 $classroomname=$row['c_name'];
	    	 $classroomid=$row['c_id'];
	    	 $startdate=$row['c_startdate'];
	    	 $shortname=$row['clg_shortname'];
	    	 $dis=$row['dis'];
	    }
	}
	$sql = "select * from colleges where clg_shortname = '$shortname'";
	$result = mysqli_query($db, $sql);
	if (mysqli_num_rows($result) ==1) {
	    while($row = mysqli_fetch_assoc($result)){
	    	 $collegesFullName=$row['clg_name'];
	    }
	}

	if($who!='student')
	header('location:admin/classroom/index.php?id='.$c_id.'&name='.$classroomname);
	/*echo $classroomname."<br/>";
	echo $classroomid."<br/>";
	echo $startdate."<br/>";
	echo $shortname."<br/>";*/

	$phnoofadmin=$_SESSION['uid'];
	$sql = "select * from users where phno1 = '$phnoofadmin'";
	$result = mysqli_query($db, $sql);
	echo mysqli_error($db);
	if (mysqli_num_rows($result) == 1) {
	    while($row = mysqli_fetch_assoc($result)){
	    	 $nameofadmin=$row['fname'];
	    	$myno=$row['phno1'];
	    }
	}
	$sql = "select * from clasroomstud where u_phno = '$myno' and classroom_id = '$c_id'";
	$result = mysqli_query($db, $sql);
	echo mysqli_error($db);
	if (mysqli_num_rows($result) == 1) {
		$show=0;
	}else{
		$show=1;
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
	body{
		background-color: #fafafa;
	}
	.back-image{
		position: absolute;
		height: 40%;
		min-height: 300px;
		width: 100%;
		background-image: url('https://visme.co/blog/wp-content/uploads/2017/07/50-Beautiful-and-Minimalist-Presentation-Backgrounds-014.jpg');
		background-size: 100% 100%;
	}
	.head-part{
      position: relative;
      top: 20px;
      width:100%;
      padding :40px;
	}
	.head-part-content{
      position: relative;
      width:100%;
      background-color: #fff;
      border-radius: 20px;
      box-shadow: 0px 0px 2px 2px #f1f1f1;
      background-size: cover;
      color: #fff;
	}
	.left-part{
		position: relative;
		min-height: 130px;
		padding :20px;
		margin-top: 0px;
		word-wrap: break-word;
       transform: translate(-1%,-25%);
      background-image: linear-gradient(to right, #0088cc, #006699);
      clip-path: polygon(0 0, 95% 0, 80% 99%, 0% 100%);
      border-radius: 20px 0px 0px 0px;
      transition: .5s;
		/*background-color: red;*/
	}
	.left-part:hover{
		background-color: #0088cc;
	}
	.left-part span{
		position: relative;
		left: 20px;
		font-weight: bold;
		color: lightgrey;
	}
	.left-part h1{
		position: relative;
		left: 20px;
		margin-right: 20px;
	}
	.right-part{
		position: relative;
		min-height: 150px;
		padding: 20px;
		/*background-color: grey;*/
	}
	.join-btn{
		position: absolute;
		left: 40px;
		top: 50%;
		transform: translate(-50%,-50%);
		background:none;
		border-radius:80px 80px 80px 80px;
		outline: none;
		padding: 5px 40px 5px 40px;
		border:3px solid #0077b3;
		color: #0077b3;
		font-weight: bold;
		transition: .2s;
	}
	.join-btn:hover{
       background-color: #0077b3;
       color: #fff;
       box-shadow: 1px 1px 5px 2px #d3d3d3;
       margin-top: -2px;
	}
	.join-btn:focus{
		outline: none;
	}
	                         /*mainp part*/
	.main-part{
		position: relative;
		width: 100%;
		padding: 40px;
	}
	.main-part-content{
		position: relative;
		width: 100%;
		
      background-color: #fff;
      border-radius: 20px;
      box-shadow: 0px 0px 2px 2px #f1f1f1;
      padding: 20px;
	}
	.heading{
		border-bottom: 4px solid #0088cc;
		display: inline-block;
		padding-bottom: 5px;
	}
	@media only screen and (max-width: 768px){
	  .right-part{
		min-height: 80px;
	  }
	  .join-btn{
		position: absolute;
		top: 0%;
		transform: translate(0%,0%);
       }
		.left-part{
			position: relative;
			min-height: 150px;
			padding :20px;
			clip-path: polygon(0 0, 100% 0, 100% 100%, 0% 100%);
			transform: translate(0%,-25%);
			border-radius: 20px 20px 0px 0px;
			/*background-color: red;*/
		}
		.left-part h1{
			font-size: 1.3em;
	    }
	    .left-part span{
			font-size: .7em;
		}
	}
</style>
</head>

<body>
                         <!-- head part -->
<div class="back-image">
	
</div>
<div class="head-part"> 
	<div class="head-part-content">
      <div class="row">
      	<div class="left-part col-md-10 col-12">
      		<h1><?php echo $collegesFullName;?></h1>
      		<span><?php echo "(".strtoupper($shortname).")";?></span>
      	</div>
      	<div class="right-part col-md-2 col-12">
      		<?php if($show){?>
      		<button class="join-btn" onclick="joinNow('<?php echo $c_id?>','<?php echo $myno?>')" >+&nbsp;Join</button>
		      <script type="text/javascript">
				function joinNow(x,y){
					$.ajax({
			            url:'php/joinclass.php',
			            data:{
			                id:x,
			                myno:y
			            },
			            type:"POST",
			            success:function(a,b){
			         	alert(a);
			         	location.reload();
			            }
			        });
			        return false;
					}
				</script>
			<?php }
				else{?>
						<button disabled class="join-btn">Already Join </button>
					<?
					}
					?>
		   </div>
      </div>
	</div>
</div>
 
                         <!-- main Part -->

<div class="main-part">
	<div class="main-part-content">
		<h3 class="heading">Description</h3>
		<p><?php echo $dis;?></p>
<!-- 		<h3 class="heading">Subjects</h3>
		<p>asdadasd</p> -->
	</div>
</div>

</body>
</html>