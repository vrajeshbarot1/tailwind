<?php
	session_start();
	include 'database.php';
	if(!isset($_SESSION['who']))
		header('location:../html/login.php');
	$who=$_SESSION['who'];
	if($who!='student' || $who=='')
		header('location:../html/login.php');
	$phnoofadmin=$_SESSION['uid'];
	$sql = "select * from users where phno1 = '$phnoofadmin'";
	$result = mysqli_query($db, $sql);
	echo mysqli_error($db);
	if (mysqli_num_rows($result) == 1) {
	    while($row = mysqli_fetch_assoc($result)){
	    	 $nameofadmin=$row['fname'];
	    	 $nameofadmin.='&nbsp;'.$row['lname'];
	    }
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
	body{
		background-color: #f1f1f1;

	}
	.head-part{
		position: relative;
		/*height: 350px;*/
		width: 96%;
		left: 2%;
		top: 10px;
		border-radius: 10px;
		background-color: #fff;
		box-shadow: 1px 1px 2px 1px #f1f1f1;
		padding-bottom: 10px;
		/*clip-path: polygon(100% 0, 100% 92%, 50% 100%, 0 92%, 0 0);*/
	}

	.head-part-top{
		position: relative;
		background: linear-gradient(rgba(0,0,0,.5),rgba(0,0,0,.5)),url('https://previews.123rf.com/images/annaleni/annaleni1603/annaleni160300100/54183996-thin-line-blue-office-business-seamless-pattern-website-design-and-seamless-background-in-trendy-mod.jpg'), linear-gradient(#000, #d3d3d3);
		width: 100%;
		height: 130px;
		border-radius: 10px 10px 0px 0px;
	}
	.head-part-bottom img{
		position: absolute;
		top: -50px;
		left: 0%;
		height: 150px;
		width: 150px;
		border-radius: 50%;
		border:5px solid #fff;
		z-index: 2;
	}

	.head-part-bottom{
		position: relative;	
		z-index: 1;
		/*background-color: red;*/
		top: 2px;
		padding-bottom: 10px;
		transform: translate(2%,-50%);
	}
	.head-part-bottom h3{
		position: relative;
		top: -20px;
		color: #fff;
		left: 170px;
		display: inline-block;
	}
	.usr-description{
	   position: relative;
	   left: 200px;
	   top: -30px;
	   display: inline-block;
	   word-break: break-all;
	   font-weight: 600;
	   letter-spacing: .5px;
	   word-spacing: 2px;
	}
	.main-part{
		position: relative;
		margin-top: 40px;
		padding: 20px;
		background-color: #fff;
		width: 96%;
		left: 2%;
	}
	.main-part h3{
      border-bottom: 4px solid #006699;
      display: inline-block;
      padding-bottom: 5px;
      margin-bottom: 20px;	
	}
	.main-part-list{
		position: relative;
		height: 60px;
		width: 100%;
		border-bottom: 1px solid #f1f1f1; 
		user-select: none;
     	cursor: pointer;
     	transition: .4s;
	}
	.main-part-list:hover{
      background-color: #f1f1f1;
	}
	.main-part-list i{
		position: absolute;
		right: 30px;
		top: 15px;
     }
     .main-part-list b{
     	position: relative;
     	top: 20px;
     	left: 20px;
     }
     .change_profile_list{
     	display: none;
        transition: .3s;
        border-bottom: 1px solid #006699;
     }
     .profile-data{
     	background-color: #fcfcfc;
     	width: 100%;
     }
     .name_change_data,.contact_change_data,.email_change_data,.pass_change_data{
     	display: none;
     	transition: .3s;
     	padding: 30px;
     }
     .input{
     	border:none;
     	border-bottom: 2px solid #000;	
     	padding: 10px;
     	font-weight: 400;
     	font-size: 1.2em;
     	letter-spacing: 1px;
     	margin: 10px;
     }
     .input:focus{
     	outline: none;
     	border:2px solid #000;
     }
      #btnfod{
	  	float:right;
	  }
	@media only screen and (max-width: 768px){
	   .head-part-top{
	   	height: 160px;
		clip-path: polygon(0 0, 100% 0, 100% 70%, 50% 100%, 0 70%);
	   }
	  .head-part-bottom img{
	  	left: 50%;
	  	top: -70px;
	  	transform: translate(-50%,0%);
	  }
	  .head-part-bottom{
		transform: translate(0%,-20%);
	  } 
	  .head-part-bottom h3{
	  	top: 100px;
	  	text-align: center;
	  	display: block;
	  	color: #000;
		left: 0px;
	  }
	  .usr-description{
	  	margin-top: 100px;
		text-align: center;
		left: 0px;
	  }
	  #btnfod{
	  	float: none;
	  }
	}
</style>
</head>
<body>
<div class="head-part">
	<div class="head-part-top">
	</div>
	<div class="head-part-bottom col-12 col-md-11">
		<img src="../img/login1.png">
		<h3><?php echo $nameofadmin;?></h3><br/>
	</div>
	<div class="usr-description col-12 col-md-6" style="text-transform: uppercase;"><?php echo $_SESSION['collageFullName'];?></div>
	<div class="col-0 col-md-2" style="float: right;"></div>
	<div class="col-0 col-md-1" style="float: right;"></div>
	<div class="usr-description col-12  col-md-3" id="btnfod"><button class="btn btn-primary hohome">Go Home</button></div>
</div>
<div class="main-part" style="border-radius: 5px;">
	<h3>Account Settings</h3>
	<div class="main-part-list profile">
		<b>Change Your Profile</b>
		<i class="fa fa-angle-down"  style="font-size:36px"></i>
	</div>
	                           <!-- change profile drop down -->
	<div class="change_profile_list">
			<div class="profile-data name_change">
				<div class="main-part-list">
				   <b>Change Name</b>
				   <i class="fa fa-angle-down"  style="font-size:36px"></i>
			    </div>
			</div>
			<div class="name_change_data">
			    	<input type="text" name="new_fname" id="first_name" class="input col-md-3" placeholder="First Name">
			    	<input type="text" name="new_lname" id="last_name" class="input col-md-3" placeholder="Last Name">
			    	<input type="submit" name="change_name" id="change_user_name" value="Change" class="btn btn-primary btn-lg ml-2 mt-2">
			</div>

			<div class="profile-data contact_change">
				<div class="main-part-list">
				   <b>Change Contact No</b>
				   <i class="fa fa-angle-down"  style="font-size:36px"></i>
			    </div>
			</div>
			<div class="contact_change_data">
				<input type="number" name="old_contact" id="old_contact" class="input col-md-3" placeholder="Old Contact Number">
				<input type="number" name="new_contact" id="new_contact" class="input col-md-3" placeholder="New Contact Number">
			    <input type="submit" name="change_contact" id="change_user_contact" value="Update" class="btn btn-primary btn-lg ml-2 mt-2">
			</div>

			<div class="profile-data email_change">
				<div class="main-part-list">
				   <b>Change Email Id</b>
				   <i class="fa fa-angle-down"  style="font-size:36px"></i>
			    </div>
			</div>
			<div class="email_change_data">
				<input type="email" name="old_email" id="old_email" class="input col-md-3" placeholder="Old Email Id">
				<input type="email" name="new_email" id="new_email" class="input col-md-3" placeholder="New Email Id">
			    <input type="submit" name="change_email" id="change_user_email" value="Update" class="btn btn-primary btn-lg ml-2 mt-2">
			</div>
     </div>


	<div class="main-part-list pass_change">
		<b>Change Your Password</b>
		<i class="fa fa-angle-down"  style="font-size:36px"></i>
	</div>
    <div class="pass_change_data">
    	<input type="text" name="old_pass" id="old_pass" class="input col-md-3" placeholder="Old Password">
				<input type="password" name="new_pass" id="new_pass" class="input col-md-3" placeholder="New password">
			    <input type="submit" name="change_pass" id="change_user_pass" value="Update" class="btn btn-primary btn-lg ml-2 mt-2">
    </div>

<!-- 	<div class="main-part-list">
		<b>Privacy</b>
	</div>
	<div class="main-part-list">
		<b>About</b>
	</div> -->
	<br/>
	<br/>
</div>
</body>
<script type="text/javascript">
$('.hohome').click(function(){
	location.replace('../');
});

$(document).ready(function(){
                                // update name
$('#change_user_name').click(function(){
	$first_name = $('#first_name').val();
	$last_name = $('#last_name').val();
	$update_name = true;
	$.ajax({
		url:'update_user_info.php',
		method:'post',
		data:{update_name:$update_name,first_name:$first_name,last_name:$last_name},
		success:function(data){
           alert(data);
           location.reload();
           //location.replace('../html/login.php');
		}
	});
});
                              // update contact
$('#change_user_contact').click(function(){

$old_contact = $('#old_contact').val();
$new_contact = $('#new_contact').val();
$update_contact = true;
	$.ajax({
          url:'update_user_info.php',
          method:'post',
          data:{update_contact:$update_contact,old_contact:$old_contact,new_contact:$new_contact},
          success:function(data){
              alert(data);
           	  location.reload();
          }
    });
})

                          // update Email
$('#change_user_email').click(function(){
	$old_email = $('#old_email').val();
	$new_email = $('#new_email').val();
	$update_email = true;
	$.ajax({
          url:'update_user_info.php',
          method:'post',
          data:{update_email:$update_email,old_email:$old_email,new_email:$new_email},
          success:function(data){
              alert(data);
           	  location.reload();
          }
    });
});
              // update contact

$('#change_user_pass').click(function(){
	$old_pass = $('#old_pass').val();
	$new_pass = $('#new_pass').val();
	$update_pass = true;
	$.ajax({
          url:'update_user_info.php',
          method:'post',
          data:{update_pass:$update_pass,old_pass:$old_pass,new_pass:$new_pass},
          success:function(data){
              alert(data+"\n Please Login Again!");
              location.replace('../html/login.php');
          }
    });
});

	                          // profile drop down
	$dropdown = 0;
	$('.profile').click(function(){
		if($dropdown == 0){
			$('.profile').css('color','#fff');
			$('.profile').css('background-color','#0088cc');
		  $('.profile i').css('transform','rotate(180deg)');
		  $dropdown =1;
	    }
	    else{
	    	$('.profile').css('color','#000');
			$('.profile').css('background-color','#fff');
           $('.profile i').css('transform','rotate(0deg)');  
            $dropdown =0;
	    }
	    $('.change_profile_list').toggle();
	});





     $name_change = 0;
	$('.name_change').click(function(){
		if($name_change == 0){
			$('.name_change').css('background-color','#f1f1f1');
			$('.name_change').css('color','#006699');
			$(this).find('i').css('transform','rotate(180deg)');
			$('.name_change_data').show();
			$name_change = 1;
	    }else{
	    	$('.name_change').css('background-color','#fcfcfc');
			$('.name_change').css('color','#000');
            $(this).find('i').css('transform','rotate(0deg)');
            $('.name_change_data').hide();
            $name_change = 0;
	    }
	});

	  $contact_change = 0;
	$('.contact_change').click(function(){
		if($contact_change == 0){
			$('.contact_change').css('background-color','#f1f1f1');
			$('.contact_change').css('color','#006699');
			$(this).find('i').css('transform','rotate(180deg)');
			$('.contact_change_data').show();
			$contact_change = 1;
	    }else{
	    	$('.contact_change').css('background-color','#fcfcfc');
			$('.contact_change').css('color','#000');
            $(this).find('i').css('transform','rotate(0deg)');
            $('.contact_change_data').hide();
            $contact_change = 0;
	    }
	});

	 $email_change = 0;
	$('.email_change').click(function(){
		if($email_change == 0){
			$('.email_change').css('background-color','#f1f1f1');
			$('.email_change').css('color','#006699');
			$(this).find('i').css('transform','rotate(180deg)');
			$('.email_change_data').show();
			$email_change = 1;
	    }else{
	    	$('.email_change').css('background-color','#fcfcfc');
			$('.email_change').css('color','#000');
            $(this).find('i').css('transform','rotate(0deg)');
            $('.email_change_data').hide();
            $email_change = 0;
	    }
	});

	 $pass_change = 0;
	$('.pass_change').click(function(){
		if($pass_change == 0){
			$('.pass_change').css('background-color','#f1f1f1');
			$('.pass_change').css('color','#006699');
			$(this).find('i').css('transform','rotate(180deg)');
			$('.pass_change_data').show();
			$pass_change = 1;
	    }else{
	    	$('.pass_change').css('background-color','#fcfcfc');
			$('.pass_change').css('color','#000');
            $(this).find('i').css('transform','rotate(0deg)');
            $('.pass_change_data').hide();
            $pass_change = 0;
	    }
	});

});
</script>
</html>