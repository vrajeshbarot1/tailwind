<?php 
include 'database.php';
$id=$_POST['id'];
$clg=$_POST['clg'];
$type=$_POST['type'];
if($type=='admin')
	$sql="select * from admin where a_emailid='$id'";
if($type=='hod')
	$sql="select * from hod where h_emailid='$id'";
if($type=='teacher')
	$sql="select * from teacher where t_emailid='$id'";
if($type=='student')
	$sql="select * from users where email='$id'";

$result = mysqli_query($db,$sql);
if (mysqli_num_rows($result) == 1){
    while($row = mysqli_fetch_assoc($result)) {
    	if($type=='admin'){
    		$pass=$row['a_pass'];
    	    $emailo=$row['a_emailid'];
    	}
    	if($type=='hod'){
    		$pass=$row['h_pass'];
            $emailo=$row['h_emailid'];
    	}
    	if($type=='teacher'){
    		$pass=$row['t_pass'];
            $emailo=$row['t_emailid'];
        }
    	if($type=='student'){
    		$pass=$row['pass'];
    	    $emailo=$row['email'];
    	    
    	}
     $to=$emailo;
     $subject='Forgot Password';
     $msg='Your Password is = '.$pass;
     $headers = "From: beginclass20@gmail.com" . "\r\n";
     if(@mail($to,$subject,$msg,$headers))
        echo "Successfully Send Your Pass on your Email-id\n if any case you not foud our mail then please check spam on your mail Account";
    }

}else{
	echo "Worng Email-id!Please enter right Email-id";
}
?>