<?php 
	$id=$_POST['id'];
	$no=$_POST['myno'];
	include "database.php";
	date_default_timezone_set('Asia/Kolkata');
	$date=date("D M Y H:i:s");
	$sql = "insert into clasroomstud value('$id', '$no', '$date')";

	if (mysqli_query($db, $sql)) {
	    echo "New class Join successfully";
	} else {
	    echo "Error: " . $sql . "<br>" . mysqli_error($db);
	}
?>