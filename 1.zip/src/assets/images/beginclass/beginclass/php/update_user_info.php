<?php
session_start();
include 'database.php';
if(!isset($_SESSION['who']))
	header('location:../html/login.php');
if($who!='student' || $who=='')
	header('location:../html/login.php');
$ChageDataidOfStudent=$_SESSION['ChageDataidOfStudent'];                                      // update Name
  if(isset($_POST['update_name'])){
  	$first_name = $_POST['first_name'];
  	$last_name = $_POST['last_name'];
    $update_user = mysqli_query($db,"update users set fname ='$first_name',lname = '$last_name' where id ='$ChageDataidOfStudent'");
    if($update_user){
    	echo "Name Updated";
    }else{
    	echo "Please Try Again";
    }
  }
                         // update contact

   if(isset($_POST['update_contact'])){
   	  $old_contact = $_POST['old_contact'];
   	  $new_contact = $_POST['new_contact'];
   	  $validate = mysqli_query($db,"select * from users where phno1 ='$old_contact'");
   	  $rows = mysqli_num_rows($validate);
   	  if($rows >= 1){
         $update_contact = mysqli_query($db,"update users set phno1 = '$new_contact' where id='$ChageDataidOfStudent'");
         if($update_contact){
         	echo "Contact Updated";
         }else{
         	echo "Already Exists This Number";
         }
   	  }else{
   	  	echo "wrong Contact Number";
   	  }
   }
                          // update email

   if(isset($_POST['update_email'])){
	   	$old_email = $_POST['old_email'];
	   	$new_email = $_POST['new_email'];
	   	$validate = mysqli_query($db,"select * from users where email ='$old_email'");
	   	$rows = mysqli_num_rows($validate);
	   	if($rows >= 1){
	   		$update_email = mysqli_query($db,"update users set email = '$new_email' where id='$ChageDataidOfStudent' ");
	          if($update_email){
	         	echo "Email Updated";
	         }else{
	         	echo "Please Try again";
	         }
	   	}else{
	   	  	echo "wrong Email ID";
	   	 }
	 }
	                 // update Password

	if(isset($_POST['update_pass'])){
		$old_pass = $_POST['old_pass'];
		$new_pass = $_POST['new_pass'];
		$validate = mysqli_query($db,"select * from users where pass ='$old_pass' and id='$ChageDataidOfStudent'");
		$rows = mysqli_num_rows($validate);
	   	if($rows >= 1){
	   		$update_pass = mysqli_query($db,"update users set pass= '$new_pass' where id='$ChageDataidOfStudent'");
	   	    if($update_pass){
	         	echo "Password Updated";
	         }else{
	         	echo "Please Try again";
	         }
        }else{
	   	  	echo "wrong Old Password";
	   	 }
	 }
?>