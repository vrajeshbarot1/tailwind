<?php
$db=mysqli_connect('127.0.0.1','root','','beginclass');
if(!$db)echo "Error";
?>