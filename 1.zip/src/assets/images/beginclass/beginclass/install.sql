create database beginclass;
CREATE TABLE `admin` (
  `a_name` varchar(50) NOT NULL,
  `a_emailid` varchar(40) NOT NULL,
  `a_pass` varchar(30) NOT NULL,
  `a_phno` varchar(20) NOT NULL,
  `a_insshortname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_name`, `a_emailid`, `a_pass`, `a_phno`, `a_insshortname`) VALUES
('BeginClass', 'jeet@gmail.com', 'root', '9711111111', 'BeginClass');

-- --------------------------------------------------------

--
-- Table structure for table `c6999801957_metadata`
--

CREATE TABLE `c6999801957_metadata` (
  `txtname` varchar(50) DEFAULT NULL,
  `starttime` varchar(50) DEFAULT NULL,
  `endtime` varchar(50) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `result` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c6999801957_metadata`
--

INSERT INTO `c6999801957_metadata` (`txtname`, `starttime`, `endtime`, `subject`, `result`) VALUES
('7000265755', '2020-05-09 10:23:00', '2020-05-09 11:00:00', 'Ajava', '1'),
('7004089047', '2020-05-08 01:05:00', '2020-05-09 11:55:00', 'java', '0'),
('7005833937', '2020-05-09 12:00:00', '2020-05-09 12:10:00', '', '0'),
('7006573019', '2020-05-09 12:00:00', '2020-05-09 01:00:00', 'ajava', '0'),
('7006600065', '2020-05-09 12:15:00', '2020-05-09 01:15:00', '', '0'),
('7006688322', '2020-05-09 12:15:00', '2020-05-09 13:15:00', 'ajava', '0');

-- --------------------------------------------------------

--
-- Table structure for table `c6999801957_result`
--

CREATE TABLE `c6999801957_result` (
  `u_phono` varchar(20) DEFAULT NULL,
  `txtname` varchar(40) DEFAULT NULL,
  `my_marks` varchar(50) DEFAULT NULL,
  `result` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c6999801957_result`
--

INSERT INTO `c6999801957_result` (`u_phono`, `txtname`, `my_marks`, `result`) VALUES
('9595959595', '7004089047', '0/1', '<<>!<>>'),
('9595959595', '7005833937', '0/1', '<<>!<>>'),
('9595959595', '7006688322', '1/4', '<<>!<>><<>!<>><<>!<>><<>!<>>'),
('11', '7006688322', '1/4', '<<>!<>><<>!<>><<>!<>><<>!<>>');

-- --------------------------------------------------------

--
-- Table structure for table `c7008191071_metadata`
--

CREATE TABLE `c7008191071_metadata` (
  `txtname` varchar(50) DEFAULT NULL,
  `starttime` varchar(50) DEFAULT NULL,
  `endtime` varchar(50) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `result` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c7008191071_metadata`
--

INSERT INTO `c7008191071_metadata` (`txtname`, `starttime`, `endtime`, `subject`, `result`) VALUES
('7008549747', '2020-05-09 13:00:00', '2020-05-09 14:15:00', 'maths', '0');

-- --------------------------------------------------------

--
-- Table structure for table `c7008191071_result`
--

CREATE TABLE `c7008191071_result` (
  `u_phono` varchar(20) DEFAULT NULL,
  `txtname` varchar(40) DEFAULT NULL,
  `my_marks` varchar(50) DEFAULT NULL,
  `result` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c7008191071_result`
--

INSERT INTO `c7008191071_result` (`u_phono`, `txtname`, `my_marks`, `result`) VALUES
('123456', '7008549747', '0/10', '<<>!<>>');

-- --------------------------------------------------------

--
-- Table structure for table `c7018260988_metadata`
--

CREATE TABLE `c7018260988_metadata` (
  `txtname` varchar(50) DEFAULT NULL,
  `starttime` varchar(50) DEFAULT NULL,
  `endtime` varchar(50) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `result` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c7018260988_metadata`
--

INSERT INTO `c7018260988_metadata` (`txtname`, `starttime`, `endtime`, `subject`, `result`) VALUES
('7018423645', '2020-05-09 03:30:00', '2020-05-09 03:55:00', 'Ajava', '0');

-- --------------------------------------------------------

--
-- Table structure for table `c7022676544_metadata`
--

CREATE TABLE `c7022676544_metadata` (
  `txtname` varchar(50) DEFAULT NULL,
  `starttime` varchar(50) DEFAULT NULL,
  `endtime` varchar(50) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `result` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c7022676544_metadata`
--

INSERT INTO `c7022676544_metadata` (`txtname`, `starttime`, `endtime`, `subject`, `result`) VALUES
('7022867745', '2020-05-09 16:00:00', '2020-05-09 16:57:00', 'Ajava', '1'),
('7552501971', '2020-05-15 18:30:00', '2020-05-15 20:05:00', 'jeetmakk', '0'),
('7558022467', '2020-05-15 00:00:00', '2020-05-15 21:35:00', 'hello world', '1'),
('7559395961', '2020-05-15 00:00:00', '2020-05-15 21:55:00', 'nice', '1'),
('7560330876', '2020-05-15 02:00:00', '2020-05-15 21:10:00', 'jeet', '0');

-- --------------------------------------------------------

--
-- Table structure for table `c7022676544_result`
--

CREATE TABLE `c7022676544_result` (
  `u_phono` varchar(20) DEFAULT NULL,
  `txtname` varchar(40) DEFAULT NULL,
  `my_marks` varchar(50) DEFAULT NULL,
  `result` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c7022676544_result`
--

INSERT INTO `c7022676544_result` (`u_phono`, `txtname`, `my_marks`, `result`) VALUES
('12345678', '7022867745', '1/2', '0<<>!<>><<>!<>>'),
('123', '7552501971', '2/2', '0<<>!<>>0<<>!<>>'),
('1234', '7558022467', '1/1', '0<<>!<>>'),
('1234', '7560330876', '1/1', '0<<>!<>>'),
('123', '7560330876', '0/1', '1<<>!<>>');

-- --------------------------------------------------------

--
-- Table structure for table `c7572223957_metadata`
--

CREATE TABLE `c7572223957_metadata` (
  `txtname` varchar(50) DEFAULT NULL,
  `starttime` varchar(50) DEFAULT NULL,
  `endtime` varchar(50) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `result` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c8064123786_metadata`
--

CREATE TABLE `c8064123786_metadata` (
  `txtname` varchar(50) DEFAULT NULL,
  `starttime` varchar(50) DEFAULT NULL,
  `endtime` varchar(50) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `result` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `c8072814211_metadata`
--

CREATE TABLE `c8072814211_metadata` (
  `txtname` varchar(50) DEFAULT NULL,
  `starttime` varchar(50) DEFAULT NULL,
  `endtime` varchar(50) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `result` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c8072814211_metadata`
--

INSERT INTO `c8072814211_metadata` (`txtname`, `starttime`, `endtime`, `subject`, `result`) VALUES
('8072889670', '2020-05-14 02:10:00', '2020-04-30 15:15:00', 'hello', '1'),
('8908047189', '2020-05-31 12:25:00', '2020-05-31 12:28:00', 'maths', '1'),
('8908333567', '2020-05-31 12:30:00', '2020-05-31 12:35:00', 'maths', '1'),
('8920856330', '2020-05-31 10:10:00', '2020-05-31 10:15:00', 'maths', '1'),
('8921002069', '2020-05-31 22:10:00', '2020-05-31 22:15:00', 'MATHS', '1'),
('8921567343', '2020-05-31 22:17:00', '2020-05-31 22:22:00', 'MATHS 2', '1'),
('9698343947', '2020-06-09 19:30:00', '2020-06-09 19:35:00', 'maths', '1'),
('9698395738', '2020-06-09 19:40:00', '2020-06-09 19:45:00', 'maths 2', '1'),
('9713662436', '2020-06-09 20:15:00', '2020-06-09 20:20:00', 'maths', '0'),
('9713697424', '2020-06-09 20:25:00', '2020-06-09 20:35:00', 'maths-2', '1'),
('9783778025', '2020-06-10 19:25:00', '2020-06-10 19:30:00', 'maths 2', '0'),
('9783823343', '2020-06-10 19:30:00', '2020-06-10 19:35:00', 'maths', '0'),
('9796449293', '2020-06-10 19:30:00', '2020-06-10 19:35:00', 'maths 3', '0');

-- --------------------------------------------------------

--
-- Table structure for table `c8908674507_metadata`
--

CREATE TABLE `c8908674507_metadata` (
  `txtname` varchar(50) DEFAULT NULL,
  `starttime` varchar(50) DEFAULT NULL,
  `endtime` varchar(50) DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `result` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clasroomstud`
--

CREATE TABLE `clasroomstud` (
  `classroom_id` varchar(30) DEFAULT NULL,
  `u_phno` varchar(20) DEFAULT NULL,
  `joindate` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clasroomstud`
--

INSERT INTO `clasroomstud` (`classroom_id`, `u_phno`, `joindate`) VALUES
('6917765826', '12345', 'Fri May 2020 11:37:17'),
('6999801957', '9595959595', 'Sat May 2020 11:22:43'),
('6999801957', '11', 'Sat May 2020 12:33:39'),
('7008191071', '123456', 'Sat May 2020 12:54:30'),
('7022676544', '12345678', 'Sat May 2020 16:49:56'),
('7022676544', '1234', 'Fri May 2020 19:48:20'),
('7022676544', '123', 'Fri May 2020 19:50:12'),
('8064123786', '123456789', 'Thu May 2020 17:59:46'),
('8908674507', '123', 'Sun May 2020 12:39:45');

-- --------------------------------------------------------

--
-- Table structure for table `classroom`
--

CREATE TABLE `classroom` (
  `c_name` varchar(50) DEFAULT NULL,
  `c_id` varchar(50) DEFAULT NULL,
  `c_startdate` varchar(50) DEFAULT NULL,
  `clg_shortname` varchar(50) DEFAULT NULL,
  `dis` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `classroom`
--

INSERT INTO `classroom` (`c_name`, `c_id`, `c_startdate`, `clg_shortname`, `dis`) VALUES
('5th CE', '7022676544', '2020-05-09', 'Ait', 'This is for only 5th CE '),
('maths', '8064123786', '2020-05-21', 'Ahuja', 'well there'),
('maths', '8072814211', '2020-05-21', 'BeginClass', 'maths class'),
('thermo', '8908674507', '2020-05-31', 'BeginClass', 'thermo');

-- --------------------------------------------------------

--
-- Table structure for table `colleges`
--

CREATE TABLE `colleges` (
  `clg_name` varchar(200) DEFAULT NULL,
  `clg_shortname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `colleges`
--

INSERT INTO `colleges` (`clg_name`, `clg_shortname`) VALUES
('BeginClass', 'BeginClass');

-- --------------------------------------------------------

--
-- Table structure for table `hod`
--

CREATE TABLE `hod` (
  `h_id` int(11) NOT NULL,
  `h_name` varchar(50) DEFAULT NULL,
  `h_emailid` varchar(40) DEFAULT NULL,
  `h_pass` varchar(30) DEFAULT NULL,
  `h_phno` varchar(20) DEFAULT NULL,
  `h_insshortname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hod`
--

INSERT INTO `hod` (`h_id`, `h_name`, `h_emailid`, `h_pass`, `h_phno`, `h_insshortname`) VALUES
(1, 'jeet', 'jeet.12@gmail.com', '123456789', '123456789', 'BeginClass');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `t_id` int(11) NOT NULL,
  `t_name` varchar(50) DEFAULT NULL,
  `t_emailid` varchar(40) DEFAULT NULL,
  `t_pass` varchar(30) DEFAULT NULL,
  `t_phno` varchar(20) DEFAULT NULL,
  `t_insshortname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `enrollno` varchar(30) DEFAULT NULL,
  `phno1` varchar(20) NOT NULL,
  `phno2` varchar(20) DEFAULT NULL,
  `branch` varchar(50) DEFAULT NULL,
  `fatheremail` varchar(40) DEFAULT NULL,
  `fatherphno` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `clgshortname` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `pass` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`fname`, `lname`, `email`, `enrollno`, `phno1`, `phno2`, `branch`, `fatheremail`, `fatherphno`, `gender`, `clgshortname`, `id`, `pass`) VALUES
('aaa', 'bbb', 'a@a', '12', '11', '11', '12 Science', 'f@f', '22', 'male', 'Aitindia', 4, 'aa'),
('Makk', 'Makwana', 'jeetmakk@gmail.xo', '4790432', '123', '123', '11 Commerce', 'jeetmakk.21@gmail.com', '12345', 'male', 'Ait', 10, '1234'),
('Jeet', 'Makwana', 'jeetmakk.21@gmail.com', '12738911', '1234', '1234', '11 Commerce', 'jeet.makk27@gmail.com', '12345', 'male', 'Ait', 9, '1234'),
('Jeet', 'Makwana', 'jeetmakk.21@gmail.com', '123456', '12345', '12345', '11 Commerce', 'father@gmail.com', '12345', 'male', 'ardhya', 1, 'jeet'),
('jeet', 'MAKWANA', 'jeet@gmail.com', '123465899', '123456', '123456', '12 Science', 'FATYHER@GMAIL.COM', '1234556', 'male', 'Aitindia', 5, '1234'),
('jeet', 'makwana', 'jeet@gmail.com', '170020107029', '12345678', '12345678', '8', 'father@gmail.com', '1234567890', 'male', 'Ait', 7, 'jeet'),
('jeet', 'makwana', 'jeet@gmail.com', '123456', '123456789', '123456789', '12 Science', 'father@gmail.com', '123456789', 'male', 'Ahuja', 8, '1234'),
('Jeet', 'Makwana', 'jeet@gmail.com', '170020107029', '9595959595', '9595959595', '12 Science', 'f@gmail.com', '9595959595', 'male', 'ardhya', 3, 'aa'),
('jeet', 'makwana', 'jeetmakk@gmail.com', '170020107029', '9714505540', '9714505540', '4', 'father@gmail.com', '97764978704', 'male', 'Ait', 6, 'jeet'),
('Jeet', 'Makwana', 'jeet@gmail.com', '170020107029', '9946484673', '9946484673', '12 Science', 'f@gmail.com', '7555481485', 'male', 'ardhya', 2, 'jeet');

-- --------------------------------------------------------

--
-- Table structure for table `webabout`
--

CREATE TABLE `webabout` (
  `title` varchar(100) DEFAULT NULL,
  `list1` varchar(100) DEFAULT NULL,
  `list1des` varchar(255) DEFAULT NULL,
  `list2` varchar(100) DEFAULT NULL,
  `list2des` varchar(255) DEFAULT NULL,
  `list3` varchar(100) DEFAULT NULL,
  `list3des` varchar(255) DEFAULT NULL,
  `aboutbox` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webabout`
--

INSERT INTO `webabout` (`title`, `list1`, `list1des`, `list2`, `list2des`, `list3`, `list3des`, `aboutbox`) VALUES
('assd', 'asdasd dadsa', ' ty ty', 'daaaaasdasd a f r er e ert ', 'tyutyutyuty', 'utyu ret ert ', 'd  ert ert', ' reery ty ujyujj yuuk');

-- --------------------------------------------------------

--
-- Table structure for table `webback`
--

CREATE TABLE `webback` (
  `id` int(40) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `image` varchar(40) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `btn` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webback`
--

INSERT INTO `webback` (`id`, `title`, `image`, `description`, `btn`) VALUES
(1, 'ertert', '1.JPG', 'tertrete', 'ertre');

-- --------------------------------------------------------

--
-- Table structure for table `webcources`
--

CREATE TABLE `webcources` (
  `c_name` varchar(50) DEFAULT NULL,
  `c_photo` varchar(50) DEFAULT NULL,
  `c_startingon` date DEFAULT NULL,
  `c_duration` int(40) DEFAULT NULL,
  `c_author` varchar(60) DEFAULT NULL,
  `author_photo` varchar(100) DEFAULT NULL,
  `c_price` int(100) DEFAULT NULL,
  `c_des` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webcources`
--

INSERT INTO `webcources` (`c_name`, `c_photo`, `c_startingon`, `c_duration`, `c_author`, `author_photo`, `c_price`, `c_des`) VALUES
('sdasda', '2.JPG', '2020-05-07', 12, 'jghf', '1.JPG', 50000, 'vdfsg'),
('sada', 'backimgforuser.jpeg', '2020-05-07', 123, 'dasdas', 'Screenshot from 2020-03-04 20-02-19.png', 34535, 'gfdgfgdfg'),
('sada', 'backimgforuser.jpeg', '2020-05-07', 123, 'dasdas', 'Screenshot from 2020-03-04 20-02-19.png', 34535, 'gfdgfgdfg'),
('asd', 'Screenshot from 2020-03-04 20-02-19.png', '2020-05-07', 545, 'fdgdfgg', 'Screenshot from 2020-03-04 23-13-40.png', 5345, 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `webdetailbox`
--

CREATE TABLE `webdetailbox` (
  `title1` varchar(50) DEFAULT NULL,
  `des1` varchar(100) DEFAULT NULL,
  `title2` varchar(50) DEFAULT NULL,
  `des2` varchar(100) DEFAULT NULL,
  `title3` varchar(50) DEFAULT NULL,
  `des3` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `webnav`
--

CREATE TABLE `webnav` (
  `title` varchar(30) DEFAULT NULL,
  `nav1` varchar(30) DEFAULT NULL,
  `nav2` varchar(30) DEFAULT NULL,
  `nav3` varchar(30) DEFAULT NULL,
  `nav4` varchar(30) DEFAULT NULL,
  `nav5` varchar(30) DEFAULT NULL,
  `nav6` varchar(30) DEFAULT NULL,
  `contact` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webnav`
--

INSERT INTO `webnav` (`title`, `nav1`, `nav2`, `nav3`, `nav4`, `nav5`, `nav6`, `contact`) VALUES
('asdaaaaaa', 'as', 'dasdasd', 'asd', 'asdasdasdas', 'asasd', 'asdad', 45654);

-- --------------------------------------------------------

--
-- Table structure for table `webreviews`
--

CREATE TABLE `webreviews` (
  `name` varchar(50) DEFAULT NULL,
  `des` varchar(50) DEFAULT NULL,
  `photo` varchar(200) DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `review` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webreviews`
--

INSERT INTO `webreviews` (`name`, `des`, `photo`, `rating`, `review`) VALUES
('asdadd', '6th', 'Screenshot from 2020-03-04 20-02-19.png', 4.5, 'asdasdasddsfgsrthyrtrt');

-- --------------------------------------------------------

--
-- Table structure for table `webteacher`
--

CREATE TABLE `webteacher` (
  `teacher_name` varchar(50) DEFAULT NULL,
  `teacher_photo` varchar(100) DEFAULT NULL,
  `teacher_gmail` varchar(60) DEFAULT NULL,
  `teacher_facebook` varchar(200) DEFAULT NULL,
  `teacher_twitter` varchar(200) DEFAULT NULL,
  `teacher_insta` varchar(200) DEFAULT NULL,
  `teacher_yt` varchar(200) DEFAULT NULL,
  `teacher_whatsapp` varchar(200) DEFAULT NULL,
  `teacher_des` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webteacher`
--

INSERT INTO `webteacher` (`teacher_name`, `teacher_photo`, `teacher_gmail`, `teacher_facebook`, `teacher_twitter`, `teacher_insta`, `teacher_yt`, `teacher_whatsapp`, `teacher_des`) VALUES
('sandeep singh', '1.JPG', 'dsfsdfsf', 'dasfsdf', 'g', 'sdfgs', 'gsdfgsdfg', 'gd', 'dfgsdfgdsf'),
('jeet k nakwana', '2.JPG', 'fsdf', 'dsf', '', 'fsd', '', '', 'fsdfsfs'),
('asdasdas', '1.JPG', '', 'https://facebook.com', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `_result`
--

CREATE TABLE `_result` (
  `u_phono` varchar(20) DEFAULT NULL,
  `txtname` varchar(40) DEFAULT NULL,
  `my_marks` varchar(50) DEFAULT NULL,
  `result` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_insshortname`);

--
-- Indexes for table `colleges`
--
ALTER TABLE `colleges`
  ADD PRIMARY KEY (`clg_shortname`);

--
-- Indexes for table `hod`
--
ALTER TABLE `hod`
  ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`phno1`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hod`
--
ALTER TABLE `hod`
  MODIFY `h_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
