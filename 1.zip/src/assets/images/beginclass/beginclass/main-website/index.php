<?php
   include 'admin-customize/ajax/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>

     <title>Known - Education HTML Template</title>
<!-- 

Known Template 

https://templatemo.com/tm-516-known

-->
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/templatemo-style.css">

</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<?php 
    $check_entry = mysqli_query($db,"select * from webback");
    if(mysqli_num_rows($check_entry) <= 0 ){
       ?>
       <h2>
            <center>Looks Like Website Didn't Customized Yet , Plese Contact To Admin Of Website</center>
       </h2>
       <center><h3 style="color: #d3d3d3">Note(If You Are Admin) :  You Didn't Added First Page</h3></center>
       <?php
    }else{
 ?>
     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                     <?php
                       $nav =  mysqli_query($db,"select * from webnav");
                       $navdata =  mysqli_fetch_assoc($nav);
                    ?>
                    <a href="#" class="navbar-brand"><?php echo $navdata["title"]; ?></a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="#top" class="smoothScroll"><?php echo $navdata['nav1']; ?></a></li>
                         <li><a href="#about" class="smoothScroll"><?php echo $navdata['nav2']; ?></a></li>
                         <li><a href="#team" class="smoothScroll"><?php echo $navdata['nav3']; ?></a></li>
                         <li><a href="#courses" class="smoothScroll"><?php echo $navdata['nav4']; ?></a></li>
                         <li><a href="#testimonial" class="smoothScroll"><?php echo $navdata['nav5']; ?></a></li>
                         <li><a href="#contact" class="smoothScroll"><?php echo $navdata['nav6']; ?></a></li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="#"><i class="fa fa-phone"></i><?php echo $navdata["contact"]; ?></a></li>
                    </ul>
               </div>

          </div>
     </section>


     <!-- HOME -->
     <section id="home">
          <div class="row">
                <?php
                 $webback1 = mysqli_query($db,"select * from webback where id = '1'");
                 $background1 = mysqli_fetch_assoc($webback1);
               ?>
                    <div class="owl-carousel owl-theme home-slider">
                         <div class="item item-first">
                         <img src="<?php echo "admin-customize/images/".$background1['image']; ?>" height="650px" width="100%">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1><?php echo $background1['title']; ?></h1>
                                             <h3><?php echo $background1['description']; ?>.</h3>
                                             <a href="#feature" class="section-btn btn btn-default smoothScroll"><?php echo $background1['btn']; ?></a>
                                        </div>
                                   </div>
                              </div>
                         </div>
                  
                   <?php  
                      $webback2 = mysqli_query($db,"select * from webback where id = '2'");
                      $background2 = mysqli_fetch_assoc($webback2);
                    ?>

                         <div class="item item-second">
                              <img src="<?php echo "admin-customize/images/".$background2['image']; ?>" height="650px" width="100%">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1><?php echo $background2['title']; ?>"</h1>
                                             <h3><?php echo $background2['description']; ?>.</h3>
                                             <a href="#courses" class="section-btn btn btn-default smoothScroll"><?php echo $background2['btn']; ?></a>
                                        </div>
                                   </div>
                              </div>
                         </div>

           <?php  
            $webback3 = mysqli_query($db,"select * from webback where id = '3'");
            $background3 = mysqli_fetch_assoc($webback3);
          ?>

                         <div class="item item-third">
                              <img src="<?php echo "admin-customize/images/".$background3['image']; ?>" height="650px" width="100%">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-6 col-sm-12">
                                             <h1><?php echo $background3['title']; ?></h1>
                                             <h3><?php echo $background3['description']; ?>.</h3>
                                             <a href="#contact" class="section-btn btn btn-default smoothScroll"><?php echo $background3['btn']; ?></a>
                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>
          </div>
     </section>


     <!-- FEATURE -->
     <section id="feature">
          <div class="container">
               <div class="row">
     <?php
      $details = mysqli_query($db,"select * from webdetailbox");
      $detailbox  =mysqli_fetch_assoc($details);
     ?>
                    <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <span>01</span>
                              <h3><?php echo $detailbox['title1']; ?></h3>
                              <p><?php echo $detailbox['des1']; ?></p>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <span>02</span>
                              <h3><?php echo $detailbox['title2']; ?></h3>
                              <p><?php echo $detailbox['des2']; ?></p>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <span>03</span>
                              <h3><?php echo $detailbox['title3']; ?></h3>
                              <p><?php echo $detailbox['des3']; ?></p>
                         </div>
                    </div>

               </div>
          </div>
     </section>


     <!-- ABOUT -->
     <section id="about">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="about-info">
                  <?php
                     $query = mysqli_query($db,"select * from webabout");
                     $about = mysqli_fetch_assoc($query);
                  ?>      
                              <h2><?php echo $about['title']; ?></h2>

                              <div class="row">
                                   <div class="col-sm-2 abt-img"><i class="fa fa-users"></i></div>
                                   <div class="col-sm-10 abt-data">
                                        <h3><?php echo $about['list1']; ?></h3>
                                        <p><?php echo $about['list1des']; ?></p>
                                   </div>
                              </div>
                              <br>
 
                              <div class="row">
                                   <div class="col-sm-2 abt-img"><i class="fa fa-certificate"></i></div>
                                   <div class="col-sm-10">
                                        <h3><?php echo $about['list2']; ?></h3>
                                        <p><?php echo $about['list2des']; ?></p>
                                   </div>
                              </div>
                              <br>

                              <div class="row">
                                   <div class="col-sm-2 abt-img"><i class="fa fa-bar-chart-o"></i></div>
                                  <div class="col-sm-10">
                                        <h3><?php echo $about['list3']; ?></h3>
                                        <p><?php echo $about['list3des']; ?></p>
                                   </div>
                              </div>
                         </div>
                    </div>

                    <div class=" col-md-6 col-sm-12" class="abt-circle">
                         <div class="entry-form">
                              <form action="#" method="post">
                                   <h2>Signup today</h2>
                                   <input type="text" name="full name" class="form-control" placeholder="Full name" required="">

                                   <input type="email" name="email" class="form-control" placeholder="Your email address" required="">

                                   <input type="password" name="password" class="form-control" placeholder="Your password" required="">

                                   <button class="submit-btn form-control" id="form-submit">Get started</button>
                              </form>
                         </div>
                    </div>

               </div>
          </div>
     </section>


     <!-- TEAM -->
     <section id="team">
          <div class="container">
               <div class="row">
                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2>Teachers <small>Meet Professional Trainers</small></h2>
                         </div>
                    </div>
                      
                   <?php
                     $teacherdata = mysqli_query($db,"select * from webteacher");
                     while($teacher = mysqli_fetch_array($teacherdata)){
                    ?>
                    <div class="col-md-3 col-sm-6">
                         <div class="team-thumb">
                              <div class="">
                                   <img src = "admin-customize/images/teachers/<?php echo $teacher['teacher_photo']; ?>" alt="" height = "280px" width="100%">
                              </div>
                              <div class="team-info">
                                   <h3><?php echo $teacher['teacher_name']; ?></h3>
                                   <span><?php echo $teacher['teacher_des']; ?></span>
                              </div>
                              <ul class="social-icon">

                                   <?php if($teacher['teacher_gmail'] != ''){ ?>
                                   <li><a href="<?php echo $teacher['teacher_gmail']; ?>" class="fa fa-google" attr="facebook icon"></a></li><?php } ?>

                                   <?php if($teacher['teacher_facebook'] != ''){ ?>
                                   <li><a href="<?php echo $teacher['teacher_facebook']; ?>" class="fa fa-facebook-square" attr="facebook icon"></a></li><?php } ?>

                                   <?php if($teacher['teacher_twitter'] != ''){ ?>
                                   <li><a href="<?php echo $teacher['teacher_twitter']; ?>" class="fa fa-twitter"></a></li>
                                   <?php } ?>

                                   <?php if($teacher['teacher_insta'] != ''){ ?>
                                   <li><a href="<?php echo $teacher['teacher_insta']; ?>" class="fa fa-instagram"></a></li>
                                   <?php } ?>

                                   <?php if($teacher['teacher_yt'] != ''){ ?>
                                   <li><a href="<?php echo $teacher['teacher_yt']; ?>" class="fa fa-youtube"></a></li>
                                   <?php } ?>

                                   <?php if($teacher['teacher_whatsapp'] != ''){ ?>
                                   <li><a href="<?php echo $teacher['teacher_whatsapp']; ?>" class="fa fa-whatsapp"></a></li>
                                   <?php } ?>
                              </ul>
                         </div>
                    </div>
                    <?php
                        }
                    ?>

                    

               </div>
          </div>
     </section>


     <!-- Courses -->
     <section id="courses">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2>Popular Courses <small>Upgrade your skills with newest courses</small></h2>
                         </div>
                  
                         <div class="owl-carousel owl-theme owl-courses">
                               <?php
                                  $cources = mysqli_query($db,"SELECT * FROM `webcources`");
                                  while($courcesdata = mysqli_fetch_assoc($cources)){ ?>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="courses-thumb">
                                             <div class="courses-top">
                                                  <div class="courses-image">
                                                       <img src="<?php echo "admin-customize/images/cources/".$courcesdata['c_photo']; ?>" alt="" height="250px" width="100%">
                                                  </div>
                                                  <div class="courses-date">
                                                       <span><i class="fa fa-calendar"></i><?php echo $courcesdata['c_startingon']; ?></span>
                                                       <span><i class="fa fa-clock-o"></i><?php echo $courcesdata['c_duration']; ?> Hours</span>
                                                  </div>
                                             </div>

                                             <div class="courses-detail">
                                                  <h3><a href="#"><?php echo $courcesdata['c_name']; ?></a></h3>
                                                  <p><?php echo $courcesdata['c_des']; ?></p>
                                             </div>

                                             <div class="courses-info">
                                                  <div class="courses-author">
                                                       <img src="<?php echo "admin-customize/images/cources/author/".$courcesdata['author_photo']; ?>" alt="" height="250px">
                                                       <span><?php echo $courcesdata['c_author']; ?></span>
                                                  </div>
                                                  <div class="courses-price">
                                                       <a href="#"><span><?php echo $courcesdata['c_price']; ?> INR</span></a>
                                                  </div>
                                             </div>
                                        </div>
                                   </div>
                              </div>
                              <?php
                            }
                          ?>
                          </div>
                          

               </div>
          </div>
     </section>


     <!-- TESTIMONIAL -->
     <section id="testimonial">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2>Student Reviews <small>from around the world</small></h2>
                         </div>

                         <div class="owl-carousel owl-theme owl-client">
                        <?php
                           $reviewdata = mysqli_query($db,"select * from webreviews");
                            while($reviews = mysqli_fetch_assoc($reviewdata)){
                         ?>
                              <div class="col-md-4 col-sm-4">
                                   <div class="item">
                                        <div class="tst-image">
                                             <img src="<?php echo 'admin-customize/images/student/'.$reviews['photo']; ?>" alt="" height = "100px" width="100px">
                                        </div>
                                        <div class="tst-author">
                                             <h4><?php echo $reviews['name']; ?></h4>
                                             <span><?php echo $reviews['des']; ?></span>
                                        </div>
                                        <p><?php echo $reviews['review']; ?></p>
                                        <div class="tst-rating">
                                             <?php echo $reviews['rating']; ?>
                                             <i class="fa fa-star"></i>
                                        </div>
                                   </div>
                              </div>
                         <?php } ?>


                         </div>

               </div>
          </div>
     </section> 


     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <form id="contact-form" role="form" action="" method="post">
                              <div class="section-title">
                                   <h2>Contact us <small>we love conversations. let us talk!</small></h2>
                              </div>

                              <div class="col-md-12 col-sm-12">
                                   <input type="text" class="form-control" placeholder="Enter full name" name="name" required="">
                    
                                   <input type="email" class="form-control" placeholder="Enter email address" name="email" required="">

                                   <textarea class="form-control" rows="6" placeholder="Tell us about your message" name="message" required=""></textarea>
                              </div>

                              <div class="col-md-4 col-sm-12">
                                   <input type="submit" class="form-control" name="send message" value="Send Message">
                              </div>

                         </form>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="contact-image">
                              <img src="images/contact-image.jpg" class="img-responsive" alt="Smiling Two Girls">
                         </div>
                    </div>

               </div>
          </div>
     </section>       


     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Headquarter</h2>
                              </div>
                              <address>
                                   <p>1800 dapibus a tortor pretium,<br> Integer nisl dui, ABC 12000</p>
                              </address>

                              <ul class="social-icon">
                                   <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="#" class="fa fa-twitter"></a></li>
                                   <li><a href="#" class="fa fa-instagram"></a></li>
                              </ul>

                              <div class="copyright-text"> 
                                   <p>Copyright &copy; 2019 Company Name</p>
                                   
                                   <p>Design: TemplateMo</p>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Contact Info</h2>
                              </div>
                              <address>
                                   <p>+65 2244 1100, +66 1800 1100</p>
                                   <p><a href="mailto:youremail.co">hello@youremail.co</a></p>
                              </address>

                              <div class="footer_menu">
                                   <h2>Quick Links</h2>
                                   <ul>
                                        <li><a href="#">Career</a></li>
                                        <li><a href="#">Investor</a></li>
                                        <li><a href="#">Terms & Conditions</a></li>
                                        <li><a href="#">Refund Policy</a></li>
                                   </ul>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-12">
                         <div class="footer-info newsletter-form">
                              <div class="section-title">
                                   <h2>Newsletter Signup</h2>
                              </div>
                              <div>
                                   <div class="form-group">
                                        <form action="#" method="get">
                                             <input type="email" class="form-control" placeholder="Enter your email" name="email" id="email" required="">
                                             <input type="submit" class="form-control" name="submit" id="form-submit" value="Send me">
                                        </form>
                                        <span><sup>*</sup> Please note - we do not spam your email.</span>
                                   </div>
                              </div>
                         </div>
                    </div>
                    
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>
<?php
}
?>
</body>

</html>
<!--      if(mysqli_num_rows($checkrows)>=1){
          if($file_name!="" && ($file_type="image/jpeg"||$file_type="image/png"||$file_type="image/gif")&& $file_size<=614400){
         if(move_uploaded_file ($file_path,'images/'.$file_name)){
              $update_query = mysqli_query($db,"update webback set id = '1',title ='$title',image='$image',description='$des',btn = '$btn'");
               if($update_query){
                echo "Background 1 changed";
               }else{
                    echo "Sonething Went Wrong";
              }
           }
        } 
      }else{
          if($file_name!="" && ($file_type="image/jpeg"||$file_type="image/png"||$file_type="image/gif")&& $file_size<=614400){
         if(move_uploaded_file ($file_path,'images/'.$file_name)){
            $query = mysqli_query($db,"insert into webnav(`id`, `title`, `image`, `description`, `btn`) values('1','$title','$image','$des','$btn')");
            if($query){
                echo "Background 1 changed";
               }else{
                    echo "Sonething Went Wrong";
               }
           }else{
               echo "xxxx";
           }
        }
     } -->