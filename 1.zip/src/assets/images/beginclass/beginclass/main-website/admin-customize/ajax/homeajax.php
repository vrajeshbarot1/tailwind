<?php
  include 'db.php';
                                        // top head
  if(isset($_POST['toptitlechange'])){
	 $logo = $_POST['logo'];
	 $topcontact = $_POST['topcontact'];
	 $checkrows = mysqli_query($db,"select * from webnav");
	 if(mysqli_num_rows($checkrows)>=1){
	  $update_query = mysqli_query($db,"update webnav set title = '$logo',contact='$topcontact'");
		if($update_query){
           echo "head data changed";
		}else{
			echo "Sonething Went Wrong";
		}
	 }else{
       $query = mysqli_query($db,"insert into webnav(title,contact) values('$logo','$topcontact')");
       if($query){
           echo "head data changed";
		}else{
			echo "Sonething Went Wrong";
		}
     }
}
                                  // nav bar

if(isset($_POST['topnavchange'])){
	 $nav1  = $_POST['nav1'];
     $nav2  = $_POST['nav2'];
     $nav3  = $_POST['nav3'];
     $nav4  = $_POST['nav4'];
     $nav5  = $_POST['nav5'];
     $nav6  = $_POST['nav6'];
     $checkrows = mysqli_query($db,"select * from webnav");
	 if(mysqli_num_rows($checkrows)>=1){
	  $update_query = mysqli_query($db,"update webnav set nav1 = '$nav1',nav2='$nav2',nav3='$nav3',nav4='$nav4',nav5='$nav5',nav6='$nav6'");
		if($update_query){
           echo "Nav data changed";
		}else{
			echo "Sonething Went Wrong";
		}
	 }else{
       $query = mysqli_query($db,"insert into webnav(nav1,nav2,nav3,nav4,nav5,nav6) values('$nav1','$nav2','$nav3','$nav4','$nav5','$nav6')");
       if($query){
           echo "Nav data changed";
		}else{
			echo "Sonething Went Wrong";
		}
     }
}
                           // background & des
                                                   // image1
if(isset($_POST['image1'])){
	// var_dump($_FILES);

	$title =  $_POST["title"];
	$des = $_POST["des"];
	$btn = $_POST["btn"];
	$image = $_FILES["file"];
	$tmp_name = $image["tmp_name"];
	 $name = $_FILES["file"]["name"];
	 $target_file = "../images/".$name;	
	$filetype = $image["type"]; 
      if($filetype == 'image/png' || $filetype == 'image/jpeg' || $filetype == 'image/jpg' || $filetype == 'image/gif'){
      	                               // insert Image
				    $checkrows = mysqli_query($db,"select * from webback where id = '1'");
				    $delete = mysqli_fetch_assoc($checkrows);
					if(mysqli_num_rows($checkrows)>=1){
					  $update_query = mysqli_query($db,"update webback set  id = '1',title ='$title',image='$name',description='$des',btn = '$btn' where id ='1'");
						if($update_query){
				           echo "Background 1 changed";
				           unlink("../images/".$delete['image']);
						}else{
							echo "Sonething Went Wrong";
						}
					 }else{
				       $query = mysqli_query($db,"insert into webback(`id`, `title`, `image`, `description`, `btn`) values('1','$title','$name','$des','$btn')");
				       if($query){
				           echo "Background 1 changed";
						}else{
							echo "Sonething Went Wrong";
						}
				     }
				         // condition check

              if (move_uploaded_file($tmp_name, $target_file)) {
			        echo "The file ". $name. " has been uploaded.";
			   } else {
			        echo "Sorry, there was an error uploading your ". $target_file. " file.";
			   }
      }else{
      	echo "invalid Image";
      }
}
	                                    // image2

if(isset($_POST['image2'])){
	// var_dump($_FILES);

	$title =  $_POST["title"];
	$des = $_POST["des"];
	$btn = $_POST["btn"];
	$image = $_FILES["file"];
	$tmp_name = $image["tmp_name"];
	 $name = $_FILES["file"]["name"];
	 $target_file = "../images/".$name;	
	$filetype = $image["type"]; 
      if($filetype == 'image/png' || $filetype == 'image/jpeg' || $filetype == 'image/jpg' || $filetype == 'image/gif'){
      	                               // insert Image
				    $checkrows = mysqli_query($db,"select * from webback where id = '2'");
				    $delete = mysqli_fetch_assoc($checkrows);
					if(mysqli_num_rows($checkrows)>=1){
					  $update_query = mysqli_query($db,"update webback set  id = '2',title ='$title',image='$name',description='$des',btn = '$btn' where id ='2'");
						if($update_query){
				           echo "Background 2 changed";				           
				           unlink("../images/".$delete['image']);
						}else{
							echo "Sonething Went Wrong";
						}
					 }else{
				       $query = mysqli_query($db,"insert into webback(`id`, `title`, `image`, `description`, `btn`) values('2','$title','$name','$des','$btn')");
				       if($query){
				           echo "Background 2 changed";	
						}else{
							echo "Sonething Went Wrong";
						}
				     }
				         // condition check

              if (move_uploaded_file($tmp_name, $target_file)) {
			        echo "The file ". $name. " has been uploaded.";
			   } else {
			        echo "Sorry, there was an error uploading your ". $target_file. " file.";
			   }
      }else{
      	echo "invalid Image";
      }
}

 										// image 3

 if(isset($_POST['image3'])){
	// var_dump($_FILES);
	$title =  $_POST["title"];
	$des = $_POST["des"];
	$btn = $_POST["btn"];
	$image = $_FILES["file"];
	$tmp_name = $image["tmp_name"];
	 $name = $_FILES["file"]["name"];
	 $target_file = "../images/".$name;	
	$filetype = $image["type"]; 
      if($filetype == 'image/png' || $filetype == 'image/jpeg' || $filetype == 'image/jpg' || $filetype == 'image/gif'){
      	                               // insert Image
				    $checkrows = mysqli_query($db,"select * from webback where id = '3'");
				    $delete = mysqli_fetch_assoc($checkrows);
					if(mysqli_num_rows($checkrows)>=1){
					  $update_query = mysqli_query($db,"update webback set  id = '3',title ='$title',image='$name',description='$des',btn = '$btn' where id ='3'");
						if($update_query){
				           echo "Background 3 changed";
				           unlink("../images/".$delete['image']);
						}else{
							echo "Sonething Went Wrong";
						}
					 }else{
				       $query = mysqli_query($db,"insert into webback(`id`, `title`, `image`, `description`, `btn`) values('3','$title','$name','$des','$btn')");
				       if($query){
				           echo "Background 3 changed";
						}else{
							echo "Sonething Went Wrong";
						}
				     }
				         // condition check

              if (move_uploaded_file($tmp_name, $target_file)) {
			        echo "The file ". $name. " has been uploaded.";
			   } else {
			        echo "Sorry, there was an error uploading your ". $target_file. " file.";
			   }
      }else{
      	echo "invalid Image";
      }
}	
                              // detetail box1

if(isset($_POST['detailbox1'])){
  $title1 = $_POST['title1'];
  $des1 = $_POST['des1'];
    $details = mysqli_query($db,"select * from webdetailbox");
    if(mysqli_num_rows($details) >= 1){
    	$update = mysqli_query($db,"update webdetailbox set title1 = '$title1' , des1 = '$des1'");
       if($update){
        	echo "Updated";
        }else{
        	echo "Something Went Wrong";
        }
    }else{
       $insert = mysqli_query($db,"insert into webdetailbox (title1,des1) values ('$title1','$des1') ");
        if($insert){
        	echo "inserted";
        }else{
        	echo "Something Went Wrong";
        }
    } 
 }
                         // detail box2

 if(isset($_POST['detailbox2'])){
  $title2 = $_POST['title2'];
  $des2 = $_POST['des2'];
    $details = mysqli_query($db,"select * from webdetailbox");
    if(mysqli_num_rows($details) >= 1){
    	$update = mysqli_query($db,"update webdetailbox set title2 = '$title2' , des2 = '$des2'");
       if($update){
        	echo "Updated";
        }else{
        	echo "Something Went Wrong";
        }
    }else{
       $insert = mysqli_query($db,"insert into webdetailbox (title2,des2) values ('$title2','$des2') ");
        if($insert){
        	echo "inserted";
        }else{
        	echo "Something Went Wrong";
        }
    } 
 }

                          // detail box3

 if(isset($_POST['detailbox3'])){
  $title3 = $_POST['title3'];
  $des3 = $_POST['des3'];
    $details = mysqli_query($db,"select * from webdetailbox");
    if(mysqli_num_rows($details) >= 1){
    	$update = mysqli_query($db,"update webdetailbox set title3 = '$title3' , des3 = '$des3'");
       if($update){
        	echo "Updated";
        }else{
        	echo "Something Went Wrong";
        }
    }else{
       $insert = mysqli_query($db,"insert into webdetailbox (title3,des3) values ('$title3','$des3') ");
        if($insert){
        	echo "inserted";
        }else{
        	echo "Something Went Wrong";
        }
    } 
 }                                                									
?>