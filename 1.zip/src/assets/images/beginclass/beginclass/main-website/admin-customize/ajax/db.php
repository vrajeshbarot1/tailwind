<?php
   //$db=mysqli_connect('localhost','user_rv','Ravi@luhar9','jeet_db');
    $db = mysqli_connect("localhost","root","","beginclass");
   
?>