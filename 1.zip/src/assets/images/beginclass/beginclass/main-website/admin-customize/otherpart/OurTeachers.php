<?php
  include '../ajax/db.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/common.css">
<style type="text/css">
	.teachers-edit{
	   position: relative;
       width: 100%;
       background-color: #fff;
       border-radius: 20px;
       padding: 10px 10px 0px 50px;
       overflow-x: hidden;
       box-shadow: 1px 1px 5px 1px lightgrey;
	}

  @media only screen and (max-width: 768px){
      .teachers-edit{
       padding: 10px 10px 0px 10px;
      }
  }
</style>
</head>
  <body>
	<div class="container-fluid">
	  <h3 class="title">Add Teacher</h3>
	       <div class="teachers-edit col-md-12">
		     <form class="form-main">
			  <div class="row">
			  	<div class="col-md-4">
			  		<label>Teacher Name</label>
			  		<input type="text" name="" id="teacher-name">
			  	</div>
			  	<div class="col-md-8">
			  		<label>Teacher Photo</label>
			  		<input type="file" name="" id="teacher-photo">
			  	</div>
			  	<div class="col-md-4">
			  		<label>Facebook Link(optional)</label>
			  		<input type="text" name="" id="teacher-facebook">
			  	</div>
			  	<div class="col-md-4">
			  		<label>Gmail Link(optional)</label>
			  		<input type="text" name=""  id="teacher-gmail">
			  	</div>
			  	<div class="col-md-4">
			  		<label>Twitter Link(optional)</label>
			  		<input type="text" name=""  id="teacher-twitter">
			  	</div>
			  	<div class="col-md-4">
			  		<label>Instagram Link(optional)</label>
			  		<input type="text" name="" id="teacher-insta">
			  	</div>
			  	<div class="col-md-4">
			  		<label>Youtube Link(optional)</label>
			  		<input type="text" name="" id="teacher-yt">
			  	</div>
			  	<div class="col-md-4">
			  		<label>Whatsapp(optional)</label>
			  		<input type="text" name="" id="teacher-whatsapp">
			  	</div>
			  	<div class="col-md-6">
			  		<label>Teacher Description</label>
			  		<textarea id="teacher-des"></textarea>
			  	</div>
			  	<div class="col-md-6">
			  		<input type="submit" class ="nav-smt col-md-5 teacher-smt" >
			  	</div>
			  </div>
			 </form>
			</div>
	   <h3 class="title">Teacher List</h3>
	   <div class="teachers-edit table-responsive">
	   	<?php
           $teacherdata = mysqli_query($db,"select * from webteacher");
	   	?>
	   	  <table class="table col-md-12">
	   	  	<tr>
	   	  		<th>Name</th>
	   	  		<th>Photo</th>
	   	  		<th>Email Id</th>
	   	  		<th>Description</th>
	   	  		<th>Delete</th>
	   	  	</tr>
	   	  	<?php
               while($teacher = mysqli_fetch_array($teacherdata)){
	   	  	?>
	   	  	<tr>
	   	  		<td><?php echo $teacher['teacher_name']; ?></td>
	   	  		<td><img src = "../images/teachers/<?php echo $teacher['teacher_photo']; ?>" height="100px" width="100px"></td>
	   	  		<td><?php echo $teacher['teacher_gmail']; ?></td>
	   	  		<td><?php echo $teacher['teacher_des']; ?></td>
	   	  		<td><button class="btn btn-danger" onclick = "deleteteacher('<?php echo $teacher['teacher_name']; ?>','<?php echo $teacher['teacher_photo']; ?>')">Delete</button></td>
	   	  	</tr>
	   	  	<?php
             }
	   	  	?>
	   	  </table>
	   </div>
	</div>

<script type="text/javascript">
	$('.teacher-smt').click(function(){
		$teacher_name = $('#teacher-name').val();
		var teacher_photo =$('#teacher-photo').prop('files')[0];
		$teacher_facebook = $('#teacher-facebook').val();
		$teacher_gmail =$('#teacher-gmail').val();
		$teacher_twitter = $('#teacher-twitter').val();
		$teacher_insta = $('#teacher-insta').val();
		$teacher_yt = $('#teacher-yt').val();
		$teacher_whatsapp = $('#teacher-whatsapp').val();
		$teacher_des = $('#teacher-des').val();
		$teacher = true;
		var form_data = new FormData(); 
		form_data.append('file',teacher_photo);
		form_data.append('teacher_name',$teacher_name);
		form_data.append('teacher_facebook',$teacher_facebook);
		form_data.append('teacher_gmail',$teacher_gmail);
		form_data.append('teacher_twitter',$teacher_twitter);
		form_data.append('teacher_insta',$teacher_insta);
		form_data.append('teacher_yt',$teacher_yt);
		form_data.append('teacher_whatsapp',$teacher_whatsapp);
		form_data.append('teacher_des',$teacher_des);
		form_data.append('teacher',true);

		$.ajax({
			url:"../ajax/otherajax.php",
			method:"post",
			data:form_data,	
				cache: false,
				contentType: false,	
	            processData: false,
	            image1:true,
			success:function(data){
				alert(data);
				$('.teachers-edit').load('.teachers-edit');
			}
		});
		return false;
	});
	function deleteteacher(name,photo){
		var name = name;
		var photo = photo;
		var deleteteacher = true;
		$.ajax({
			url:"../ajax/otherajax.php",
			method:"post",
			data:{name:name,photo:photo,deleteteacher:deleteteacher},
			success:function(data){
				alert(data);
			}
		}); 
	}
</script>
  </body>
</html>