<?php
include '../ajax/db.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/common.css">
<style type="text/css">
	.ourdetail-edit{
	   position: relative;
       width: 100%;
       background-color: #fff;
       border-radius: 20px;
       padding: 10px 10px 0px 50px;
       box-shadow: 1px 1px 5px 1px lightgrey;
	}

  @media only screen and (max-width: 768px){
      .ourdetail-edit{
       padding: 10px 10px 0px 10px;
      }
  }
</style>
</head>
<body>

	<?php
      $details = mysqli_query($db,"select * from webdetailbox");
      $detailbox  =mysqli_fetch_assoc($details);
	?>
<div class="container-fluid">
	<h3 class="title">Detail Box 1</h3>
	<div class="ourdetail-edit col-md-12">
	  <form class="form-main ">
          <div class="row">
          	<div class="col-md-4">
          		<label>Title</label>
          		<input type="text" name="" id="title1" value="<?php echo $detailbox['title1']; ?>">
          	</div>
          	<div class="col-md-5">
          		<label>Description</label>
          		  <textarea id="des1"><?php echo $detailbox['des1']; ?></textarea>
          	</div>
          	<div class="col-md-3">
          		<input type="submit" name="" class="nav-smt detail-box1">
           </div>
         </div>
	  </form>
    </div>

    <h3 class="title">Detail Box 2</h3>
	<div class="ourdetail-edit col-md-12">
	  <form class="form-main ">
          <div class="row">
          	<div class="col-md-4">
          		<label>Title</label>
          		<input type="text" name="" id="title2" value="<?php echo $detailbox['title2']; ?>">
          	</div>
          	<div class="col-md-5">
          		<label>Description</label>
          		  <textarea id="des2"><?php echo $detailbox['des2']; ?></textarea>
          	</div>
          	<div class="col-md-3">
          		<input type="submit" name="" class="nav-smt detail-box2">
           </div>
         </div>
	  </form>
    </div>

    <h3 class="title">Detail Box 3</h3>
	<div class="ourdetail-edit col-md-12">
	  <form class="form-main ">
          <div class="row">
          	<div class="col-md-4">
          		<label>Title</label>
          		<input type="text" name="" id="title3" value="<?php echo $detailbox['title3']; ?>">
          	</div>
          	<div class="col-md-5">
          		<label>Description</label>
          		  <textarea id="des3"><?php echo $detailbox['des3']; ?></textarea>
          	</div>
          	<div class="col-md-3">
          		<input type="submit" name="" class="nav-smt detail-box3">
           </div>
         </div>
	  </form>
    </div>

</div>


<script type="text/javascript">
$(document).ready(function(){
	$('.detail-box1').click(function(){

			$detailbox1 = true;
			$title1 = $('#title1').val();
			$des1 = $('#des1').val();
      $.ajax({
			url:"../ajax/homeajax.php",
			method:"post",
			data:{title1:$title1,des1:$des1,detailbox1:$detailbox1},
			success:function(data){
				alert(data);
			}
		});
      return false;
	});
		                              // box 2

    $('.detail-box2').click(function(){

			$detailbox2 = true;
			$title2 = $('#title2').val();
			$des2 = $('#des2').val();
      $.ajax({
			url:"../ajax/homeajax.php",
			method:"post",
			data:{title2:$title2,des2:$des2,detailbox2:$detailbox2},
			success:function(data){
				alert(data);
			}
		});
      return false;
	});
                                            
                                            // box 3

	$('.detail-box3').click(function(){

			$detailbox3 = true;
			$title3 = $('#title3').val();
			$des3 = $('#des3').val();
      $.ajax({
			url:"../ajax/homeajax.php",
			method:"post",
			data:{title3:$title3,des3:$des3,detailbox3:$detailbox3},
			success:function(data){
				alert(data);
			}
		});
      return false;
	});

});


</script>
</body>
</html>