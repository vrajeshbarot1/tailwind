<?php
  include '../ajax/db.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/common.css">
<style type="text/css">
	.cources-edit{
	   position: relative;
       width: 100%;
       background-color: #fff;
       border-radius: 20px;
       padding: 10px 10px 0px 50px;
       overflow-x: hidden;
       box-shadow: 1px 1px 5px 1px lightgrey;
	}

  @media only screen and (max-width: 768px){
      .cources-edit{
       padding: 10px 10px 0px 10px;
      }
  }
</style>
</head>
  <body>
	<div class="container-fluid">
	  <h3 class="title">Add Cources (Recomanded > 3)</h3>
	  <div class="cources-edit col-md-12">
		     <form class="form-main">
		       	<div class="row">
		       		<div class="col-md-5">
			  		   <label>Cource Name</label>
			  		   <input type="text" name="" id="cource-name">
			  	     </div>
			  	     <div class="col-md-4">
			  		   <label>Cource Photo</label>
			  		   <input type="file" name="" id="cource-photo">
			  	     </div>
			  	     <div class="col-md-3">
			  		   <label>Starting Date</label>
			  		   <input type="date" name="" id="cource-starting">
			  	     </div>
			  	     <div class="col-md-4">
			  		   <label>Cource Duration (hrs)</label>
			  		   <input type="number" name="" id="cource-duration">
			  	     </div>
			  	     <div class="col-md-4">
			  		   <label>Cource Author</label>
			  		   <input type="text" name="" id="cource-author">
			  	     </div>
			  	     <div class="col-md-4">
			  		   <label>Cource Author Photo</label>
			  		   <input type="file" name="" id="author-photo">
			  	     </div>
			  	     <div class="col-md-3">
			  		   <label>Cource Price</label>
			  		   <input type="number" name="" id="cource-price">
			  	     </div>
			  	     <div class="col-md-5">
			  		   <label>Cource Description</label>
			  		    <textarea id="cource-des"></textarea>
			  	     </div>
			  	     <div class="col-md-4">
				  		<input type="submit" class ="nav-smt col-md-5 cource-smt" >
				  	</div>
			    </div>
			</form>
	   </div>
	   <h3 class="title">Cource List</h3>
	    <div class="cources-edit col-md-12">
            <div class="table-responsive">
            	<table class="table">
            		<tr>
            			<th>Cource Name</th>
            			<th>Cource Photo</th>
            			<th>Starting Date</th>
            			<th>Cource Duration</th>
            			<th>Cource Author</th>
            			<th>Author Photo</th>
            			<th>Cource Price</th>
            			<th>Cource Description</th>
            		</tr>
            		<?php
                        $cources = mysqli_query($db,"SELECT * FROM `webcources`");
                        while($courcesdata = mysqli_fetch_assoc($cources)){ ?>
                             <tr>
		            			<td><?php echo $courcesdata['c_name']; ?></td>
		            			<td><img src="<?php echo "../images/cources/".$courcesdata['c_photo']; ?>" height="100px" width = "100px"></td>
		            			<td><?php echo $courcesdata['c_startingon']; ?></td>
		            			<td><?php echo $courcesdata['c_duration']; ?></td>
		            			<td><?php echo $courcesdata['c_author']; ?></td>
		            			<td><img src="<?php echo "../images/cources/author/".$courcesdata['author_photo']; ?>" height="100px" width = "100px"></td>
		            			<td><?php echo $courcesdata['c_price']; ?></td>
		            			<td><?php echo $courcesdata['c_des']; ?></td>
		            		</tr>
                    <?php    
                        }
            		?>
            	</table>
            	
            </div>
	    </div>
	</div>
	<script type="text/javascript">
		$('.cource-smt').click(function(){
			$courcename = $('#cource-name').val();
			$courcephoto = $('#cource-photo').prop('files')[0];
			$authorphoto = $('#author-photo').prop('files')[0];
			$courcestarting = $('#cource-starting').val();
			$courceduration = $('#cource-duration').val();
			$courceauthor = $('#cource-author').val();
			$courceprice = $('#cource-price').val();
            $courcedes = $('#cource-des').val();
            $cources = true;
            var form_data = new FormData(); 
            form_data.append('author',$authorphoto);
            form_data.append('file',$courcephoto);
            form_data.append('courcename',$courcename);
            form_data.append('courcestarting',$courcestarting);
            form_data.append('courceduration',$courceduration);
            form_data.append('courceauthor',$courceauthor);
            form_data.append('courceprice',$courceprice);
            form_data.append('courcedes',$courcedes);
            form_data.append('cources',$courcestarting);
            $.ajax({
            	url: "../ajax/otherajax.php",
            	method: "post",
            	data:form_data,	
					cache: false,
					contentType: false,	
		            processData: false,
		            image1:true,
            	success:function(data){
                  alert(data);
            	}
            });
            return false;
           
		});
	</script>
</body>
</html>