<?php
  include '../ajax/db.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/common.css">
<style type="text/css">
	.about-edit{
	   position: relative;
       width: 100%;
       background-color: #fff;
       border-radius: 20px;
       padding: 10px 10px 0px 50px;
       box-shadow: 1px 1px 5px 1px lightgrey;
	}

  @media only screen and (max-width: 768px){
      .about-edit{
       padding: 10px 10px 0px 10px;
      }
  }
</style>
</head>
<body>
	<div class="container-fluid">
	<h3 class="title">Detail Box 1</h3>
	<div class="about-edit col-md-12">
		<form class="form-main">
			<div class="row">
				<?php
                     $query = mysqli_query($db,"select * from webabout");
                     $about = mysqli_fetch_assoc($query);
				?>
				<div class="col-md-12">
					<label>Title</label>
					<input type="text" name="" id="title" value="<?php echo $about['title']; ?>">
				</div>

				<div class="col-md-6">
					<label>List1</label>
					<input type="text" name="" id="list1" value="<?php echo $about['list1']; ?>">
				</div>
				<div class="col-md-6">
					<label>List1 description</label>
					<input type="text" name="" id="list1des" value="<?php echo $about['list1des']; ?>">
				</div>

				<div class="col-md-6">
					<label>List 2</label>
					<input type="text" name=""  id="list2" value="<?php echo $about['list2']; ?>">
				</div>
				<div class="col-md-6">
					<label>List 2 description</label>
					<input type="text" name="" id="list2des" value="<?php echo $about['list2des']; ?>">
				</div>

				<div class="col-md-6">
					<label>List 3</label>
					<input type="text" name=""  id="list3" value="<?php echo $about['list3']; ?>">
				</div>
				<div class="col-md-6">
					<label>List3 description</label>
					<input type="text" name="" id="list3des" value="<?php echo $about['list3des']; ?>">
				</div>


				<div class="col-md-6">
	          		<label>About Box</label>
					<input type="text" name="" id="aboutbox" value="<?php echo $about['aboutbox']; ?>">	
	           </div>
				<div class="col-md-4">
	          		<input type="submit" name="" class="nav-smt about-smt col-md-6" value="Edit">
	           </div>
			</div>
		</form>
	</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('.about-smt').click(function(){
			$title = $('#title').val();
			$list1 = $('#list1').val();
			$list1des = $('#list1des').val();
			$list2 = $('#list2').val();
			$list2des = $('#list2des').val();
			$list3 = $('#list3').val();
			$list3des = $('#list3des').val();
			$aboutbox = $('#aboutbox').val();
			$about = true;
			$.ajax({
				url:"../ajax/otherajax.php",
				method:"post",
				data:{title:$title,list1:$list1,list1des:$list1des,list2:$list2,list2des:$list2des,list3:$list3,list3des:$list3des,aboutbox:$aboutbox,about:$about},
				success:function(data){
                    alert(data);
				}
			});
			return false;
		});
	});
</script>
</body>
</html>
