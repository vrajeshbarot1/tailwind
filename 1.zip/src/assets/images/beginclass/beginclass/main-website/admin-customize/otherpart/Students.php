<?php
  include '../ajax/db.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/common.css">
<style type="text/css">
	.studentrev-edit{
	   position: relative;
       width: 100%;
       background-color: #fff;
       border-radius: 20px;
       padding: 10px 10px 0px 50px;
       overflow-x: hidden;
       box-shadow: 1px 1px 5px 1px lightgrey;
	}

  @media only screen and (max-width: 768px){
      .studentrev-edit{
       padding: 10px 10px 0px 10px;
      }
  }
</style>
</head>
  <body>
	<div class="container-fluid">
	  <h3 class="title">Student Reviews</h3>
	       <div class="studentrev-edit col-md-12">
	       	 <form class="form-main">
			  <div class="row">
			  	<div class="col-md-4">
			  		<label>Student Name</label>
			  		<input type="text" name="" id="student-name">
			  	</div>
			  	<div class="col-md-4">
			  		<label>Student Designation</label>
			  		<input type="text" name="" id="student-des">
			  	</div>
			  	<div class="col-md-4">
			  		<label>Student Photo</label>
			  		<input type="file" name="" id="student-photo">
			  	</div>
			  	<div class="col-md-6">
			  		<label>What Student Says About You</label>
			  		<textarea id="student-review"></textarea>
			  	</div>
			  	<div class="col-md-2">
			  		<label>Rating (Out Of 5)</label>
			  		<select id="student-rating">
			  			<option value="1">1</option>
			  			<option value="1.5">1.5</option>
			  			<option value="2">2</option>
			  			<option value="2.5">2.5</option>
			  			<option value="3">3</option>
			  			<option value="3.5">3.5</option>
			  			<option value="4">4</option>
			  			<option value="4.5">4.5</option>
			  			<option value="5">5</option>
			  		</select>
			  	</div>

			  	 <div class="col-md-4">
				  		<input type="submit" class ="nav-smt col-md-5 review-smt" >
				  	</div>
	       </div>
	   </form>
	  </div>
	  <h3 class="title">Reviews List</h3>
	       <div class="studentrev-edit table-responsive col-md-12">
             <table class="table">
             	<tr>
             		<th>Student Name</th>
             		<th>Student Designation</th>
             		<th>Student Photo</th>
             		<th>Review</th>
             		<th>Rating</th>
             	</tr>
             	<?php
                 $reviewdata = mysqli_query($db,"select * from webreviews");
                  while($reviews = mysqli_fetch_assoc($reviewdata)){
             	?>
             	<tr>
             		<td><?php echo $reviews['name']; ?></td>
             		<td><?php echo $reviews['des']; ?></td>
             		<td><img src="<?php echo '../images/student/'.$reviews['photo']; ?> " height="100px" width="100px"></td>
             		<td><?php echo $reviews['review']; ?></td>
             		<td><?php echo $reviews['rating']; ?></td>
             	</tr>
             <?php } ?>
             </table>
	       </div>
	</div>
<script type="text/javascript">
	$('.review-smt').click(function(){
		$studentname = $('#student-name').val();
		$studentdes = $('#student-des').val();
        $studentphoto  = $('#student-photo').prop('files')[0];
        $studentrating = $('#student-rating').val();
        $studentreview = $('#student-review').val();
        $studreview = true;
        var form_data = new FormData();
        form_data.append('studentname',$studentname);
        form_data.append('studentdes',$studentdes);
        form_data.append('studentphoto',$studentphoto);
        form_data.append('studentrating',$studentrating);
        form_data.append('studentreview',$studentreview);
        form_data.append('studreview',$studreview);
         $.ajax({
            	url: "../ajax/otherajax.php",
            	method: "post",
            	data:form_data,	
					cache: false,
					contentType: false,	
		            processData: false,
		            image1:true,
            	success:function(data){
                  alert(data);
            	}
            });
         return false;
	});
</script>
</body>
</html>