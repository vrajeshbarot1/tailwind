<?php
  include '../ajax/db.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/common.css">

<style type="text/css">

	.top-nav-edit{
		position: relative;
       width: 100%;
       background-color: #fff;
       border-radius: 20px;
       padding: 10px 10px 0px 50px;
       box-shadow: 1px 1px 5px 1px lightgrey;
	}

  @media only screen and (max-width: 768px){
      .top-nav-edit{
       padding: 10px 10px 0px 10px;
      }
  }
</style>
</head>
<body>
 <div class="container-fluid">
                                        <!-- title & contact -->
  <h3 class="title">Title & Contact</h3>
    <div class="top-nav-edit col-md-12">
    	<form class="form-main ">
    	<div class="row">
    		<div class="col-md-4">
          <?php
             $nav =  mysqli_query($db,"select * from webnav");
             $navdata =  mysqli_fetch_array($nav);
          ?>
    			<label>Title</label>
    		   <input type="text" name="" id="logo-name" value="<?php echo $navdata['title']; ?>">
    		</div>
    		<div class="col-md-4">
    			<label>Contact</label>
    		   <input type="number" name="" id="top-contact" value="<?php echo $navdata['contact']; ?>">
    		</div>
    		<div  class="col-md-4">
    		 <input type="submit" name="" class="nav-smt col-md-4 toptitle" value="Change">
    	    </div>
    	</div>
    	</form>
    </div>
                                            <!-- nav BAr -->

     <h3 class="title">Nav Items</h3>
    <div class="top-nav-edit col-md-12">
      <form class="form-main ">
      <div class="row">
        <div class="col-md-3">
          <label>Nav1</label>
           <input type="text" name="" id="nav1" value="<?php echo $navdata['nav1']; ?>">
        </div>
        <div class="col-md-3">
          <label>Nav2</label>
           <input type="text" name="" id="nav2" value="<?php echo $navdata['nav2']; ?>">
        </div>
        <div class="col-md-3">
          <label>Nav3</label>
           <input type="text" name="" id="nav3" value="<?php echo $navdata['nav3']; ?>">
        </div>
        <div class="col-md-3">
          <label>Nav4</label>
           <input type="text" name="" id="nav4" value="<?php echo $navdata['nav4']; ?>">
        </div>
        <div class="col-md-3">
          <label>Nav5</label>
           <input type="text" name="" id="nav5" value="<?php echo $navdata['nav5']; ?>">
        </div>
        <div class="col-md-3">
          <label>Nav6</label>
           <input type="text" name="" id="nav6" value="<?php echo $navdata['nav6']; ?>">
        </div>
        <div  class="col-md-4">
         <input type="submit" name="" class="nav-smt col-md-4 topnav" value="Change">
        </div>
      </div>
      </form>
    </div>


 </div>
 <script type="text/javascript">
 $(document).ready(function(){
                                 // top logo & contact

        $('.toptitle').click(function(){
          	$toptitlechange = true;
          	$logo = $('#logo-name').val();
          	$topcontact = $('#top-contact').val();
  	        $.ajax({
  		       url:"../ajax/homeajax.php",
  		       method:"post",
  		       data:{logo:$logo,topcontact:$topcontact,toptitlechange:$toptitlechange},
  		       success:function(data){
                    alert(data);
  		       }
      		 	});
      		 	return false;
     	   });
        $('.topnav').click(function(){
             $topnavchange = true;
              $nav1  = $('#nav1').val();
              $nav2  = $('#nav2').val();
              $nav3  = $('#nav3').val();
              $nav4  = $('#nav4').val();
              $nav5  = $('#nav5').val();
              $nav6  = $('#nav6').val();
              $.ajax({
               url:"../ajax/homeajax.php",
               method:"post",
               data:{nav1:$nav1,nav2:$nav2,nav3:$nav3,nav4:$nav4,nav5:$nav5,nav6:$nav6,topnavchange:$topnavchange},
               success:function(data){
                  alert(data);
               }
        });
            return false;
 });
 });
 </script>
</body>
</html>