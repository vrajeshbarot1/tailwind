<?php
  include '../ajax/db.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/common.css">
<style type="text/css">
	.back-edit{
	   position: relative;
	   width: 100%;
	   background-color: #fff;
	   border-radius: 20px;
	   padding: 10px 10px 30px 50px;
	   box-shadow: 1px 1px 5px 1px lightgrey;
	}
	  @media only screen and (max-width: 768px){
      .back-edit{
       padding: 10px 10px 0px 10px;
      }
  }
</style>
</head>
<body>
	<div class="container-fluid">
		<?php
            $webback1 = mysqli_query($db,"select * from webback where id = '1'");
            $background1 = mysqli_fetch_assoc($webback1);
		?>
		<h3 class="title">Background 1</h3>
		<div class="back-edit col-md-12">
			<form class="form-main">
				<div class="row">
					<div class="col-md-5">
		    			<label>Image 1 Title</label>
		    		   <input type="text" name="" id="image1-title" value="<?php echo $background1['title']; ?>">
		    		</div>
		    		<div class="col-md-4">
		    			<label>Choose New Image : </label>
		    		   <input type="file" name="" id="image1-image">
		    		</div>
		    		<div class="col-md-3">
		    			<label>Button Value : </label>
		    		   <input type="text" name="" id="image1-btn" value="<?php echo $background1['btn']; ?>">
		    		</div>
		    		<div class="col-md-5">
		    			<label>Description : </label>
		    		   <textarea id="image1-des"><?php echo $background1['description']; ?></textarea>
		    		</div>
		    		<div class="col-md-3">
		    			<label>Old Image</label>(<?php echo $background1['image']; ?>)
		    			<img src="<?php echo "../images/".$background1['image']; ?>" height=100px; class="col-md-12 img1">
		    		</div>
		    		<div  class="col-md-4">
		    		 <input type="submit" name="" class="nav-smt col-md-4 back-1" value="Change">
		    	    </div>
					
				</div>
			</form>
		</div>
		                                        <!-- Back 2 -->

        <?php  
            $webback2 = mysqli_query($db,"select * from webback where id = '2'");
            $background2 = mysqli_fetch_assoc($webback2);
		?>
		<h3 class="title">Background 2</h3>
		<div class="back-edit col-md-12">
			<form class="form-main">
				<div class="row">
					<div class="col-md-5">
		    			<label>Image 2 Title</label>
		    		   <input type="text" name="" id="image2-title" value="<?php echo $background2['title']; ?>">
		    		</div>
		    		<div class="col-md-4">
		    			<label>Choose Image : </label>
		    		   <input type="file" name="" id="image2-image">
		    		</div>
		    		<div class="col-md-3">
		    			<label>Button Value : </label>
		    		   <input type="text" name="" id="image2-btn" value="<?php echo $background2['btn']; ?>">
		    		</div>
		    		<div class="col-md-5">
		    			<label>Description : </label>
		    		   <textarea id="image2-des"><?php echo $background2['description']; ?></textarea>
		    		</div>
		    		<div class="col-md-3">
		    			<label>Old Image</label>(<?php echo $background2['image']; ?>)
		    			<img src="<?php echo "../images/".$background2['image']; ?>" height=100px; class="col-md-12 img1">
		    		</div>
		    		<div  class="col-md-4">
		    		 <input type="submit" name="" class="nav-smt col-md-4 back-2" value="Change">
		    	    </div>
					
				</div>
			</form>
		</div>
			                                        <!-- Back 3 -->

        <?php  
            $webback3 = mysqli_query($db,"select * from webback where id = '3'");
            $background3 = mysqli_fetch_assoc($webback3);
		?>

		<h3 class="title">Background 3</h3>
		<div class="back-edit col-md-12">
			<form class="form-main">
				<div class="row">
					<div class="col-md-5">
		    			<label>Image 3 Title</label>
		    		   <input type="text" name="" id="image3-title" value="<?php echo $background3['title']; ?>">
		    		</div>
		    		<div class="col-md-4">
		    			<label>Choose Image : </label>
		    		   <input type="file" name="" id="image3-image">
		    		</div>
		    		<div class="col-md-3">
		    			<label>Button Value : </label>
		    		   <input type="text" name="" id="image3-btn" value="<?php echo $background3['btn']; ?>">
		    		</div>
		    		<div class="col-md-5">
		    			<label>Description : </label>
		    		   <textarea id="image3-des"><?php echo $background3['description']; ?></textarea>
		    		</div>
		    		<div class="col-md-3">
		    			<label>Old Image</label>(<?php echo $background3['image']; ?>)
		    			<img src="<?php echo "../images/".$background3['image']; ?>" height=100px; class="col-md-12 img1">
		    		</div>
		    		<div  class="col-md-4">
		    		 <input type="submit" name="" class="nav-smt col-md-4 back-3" value="Change">
		    	    </div>
					
				</div>
			</form>
		</div>
		
	</div>

<script type="text/javascript">
	                                  // image 1
	$('.back-1').click(function() {
		$title = $('#image1-title').val();
		$image = $('#image1-image').val();
		$des = $('#image1-des').val();
		$btn = $('#image1-btn').val();
		var img=$('#image1-image').prop('files')[0];
		alert(img['name']);
		var form_data = new FormData();                  
        form_data.append('file', img);
        form_data.append('title',$title);
        form_data.append('des',$des);
        form_data.append('btn',$btn);
        form_data.append('image1',true);
		
		$.ajax({
			url:"../ajax/homeajax.php",
			method:"post",
			data:
				form_data,	
				cache: false,
				contentType: false,	
	            processData: false,
	            image1:true,
            success:function(data){
             alert(data);
              $('.img1').hide();
            }
		});
		return false;
	});
	                               		// image 2

	$('.back-2').click(function() {
		$title = $('#image2-title').val();
		$image = $('#image2-image').val();
		$des = $('#image2-des').val();
		$btn = $('#image2-btn').val();
		var img=$('#image2-image').prop('files')[0];
		alert(img['name']);
		var form_data = new FormData();                  
        form_data.append('file', img);
        form_data.append('title',$title);
        form_data.append('des',$des);
        form_data.append('btn',$btn);
        form_data.append('image2',true);
		
		$.ajax({
			url:"../ajax/homeajax.php",
			method:"post",
			data:
				form_data,	
				cache: false,
				contentType: false,	
	            processData: false,
	            image1:true,
            success:function(data){
             alert(data);
            }
		});
		return false;
	});      



												// image 3

	$('.back-3').click(function() {
		$title = $('#image3-title').val();
		$image = $('#image3-image').val();
		$des = $('#image3-des').val();
		$btn = $('#image3-btn').val();
		var img=$('#image3-image').prop('files')[0];
		alert(img['name']);
		var form_data = new FormData();                  
        form_data.append('file', img);
        form_data.append('title',$title);
        form_data.append('des',$des);
        form_data.append('btn',$btn);
        form_data.append('image3',true);
		
		$.ajax({
			url:"../ajax/homeajax.php",
			method:"post",
			data:
				form_data,	
				cache: false,
				contentType: false,	
	            processData: false,
	            image1:true,
            success:function(data){
             alert(data);
            }
		});
		return false;
	});  


</script>
</body>
</html>
