<!DOCTYPE html>
<html>
<head>
	<title>loggedin@Begin Test</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
	body{
		margin: 0px;
		padding: 0px;
	}
	.main-div{
		position: absolute;
		height: 100vh;
		width: 100%;
		/*background-color: red;*/
	}
	.top-bar{
		position: fixed;
		background-color: #fff;
		height: 60px;
		width: 100%;
		z-index: 9;
		box-shadow: 1px 1px 2px 2px lightgrey; 
	}
	.top-user-info{
		position: absolute;
		top:15px;
		right: 30px; 
		cursor: pointer;
		user-select: none;
	}
	.top-user-info img{
		height: 40px;
		width: 40px;
		border-radius: 50%;
	}
	#menu-icn{
		position: absolute;
		font-size: 30px;
		top: 15px;
		left: 10px;
		display: none;
	}
	#menu-icn1{
		position: absolute;
		font-size: 30px;
		top: 15px;
		left: 10px;
		transform: rotate(90deg);
		/*display: none;*/
	}
	.top-search{
		position:relative;
		top: -60px;
		height: 60px;
		z-index: 8;
		transition: .4s;
	}
	.top-search-input{
		position:relative;
		height: 60px;
		padding-left: 2%;
		font-size: 1.5em;
		background-color: #fff;
		/*box-shadow: 0px 0px 4px 2px grey; */
		width: 100%;
		z-index: 1;
	}
	.top-bar-responsive{
		position: relative;
		top: 0px;
		height: 60px;
		width: 100%;
		background-color: #fff;
		border-top: 1px solid lightgrey;
		box-shadow: 1px 2px 2px 2px lightgrey; 
		z-index: 2;
	}
	#top-search-icn{
		position: relative;
		top: -52px;
		left: 60px;
		font-weight: 400;
		font-size: 24px;
		color: grey;
		background-color: #f1f1f1;
		padding: 10px;
		border-radius: 50%;
		cursor: pointer;
	}

	.top-bar-icon{
		position: absolute;
		height: 100px;
		/*float: left;*/
		background-color: red;
		font-size: 24px;
		z-index: 100;
	}
	.srh-cancel{
		position: absolute;
		top: 20px;
		right: 20px;
		z-index: 3;
		cursor: pointer;
		font-size: 1.4em;
	}
	#logo-head{
      height: 50px;
      width: auto;
      position:absolute;
      left: 50%;
      transform: translate(-50%);
      top: 5px;
	}
	.right-responsive-menu{
		position: absolute;
		top:15px;
		right: 30px; 
		cursor: pointer;
		user-select: none;
	}
	.right-responsive-menu i{
		display: none;
		font-size: 34px;
	}
	.dropdown-menu li{
		padding: 5px;
	}
	.dropdown-menu li a{
     font-size: 1.1em;
     padding-left: 5px;
     text-decoration: none;
     list-style: none;
     color: #000;
	}
	.dropdown-menu li:hover{
		background-color: #f1f1f1;
	}
	.dropdown-menu{
		margin-left: -10px; 
	     padding: 10px;
	     width: 220px;
	}
	.left-part{
		position: fixed;
		top: 60px;
		z-index: 1;
		height: 90vh;
		overflow-y: scroll;
		width: 280px;
		left: 0px;
		transition: .4s;
		background-color: #fff;
	}
	::-webkit-scrollbar {
       width: 8px;
	}
	::-webkit-scrollbar-track {
/*	  box-shadow: inset 0 0 5px grey;*/ 
	  border-radius: 10px;
	}
	::-webkit-scrollbar-thumb {
	  background: grey; 
	  border-radius: 10px;
	}
	::-webkit-scrollbar-thumb:hover {
	  background: #666666; 
	}
	.menu-profile{
		position: relative;
		/*background-color: red;*/
		background-image: url('https://teacher.bahonafeedback.com/assets/img/backgrounds/1@2x.jpg');
		background-size: 100% 100%;
      height: 150px;
      width: 100%;
	}
	.menu-profile img{
      position: relative;
      top:20px;
      border-radius: 50%; 
      height: 100px;
      width: 100px;
      left: 10px;
	 }      
	 #user-name{
	 	position: absolute;
	 	left:130px;
	 	top: 50px;
	 	font-size: 1.2em;
	 	font-weight: bold;
	 }
	 #user-position{
	 	position: absolute;
	 	left:130px;
	 	top: 75px;
	 }
	 .menu-block{
         position: relative;
         top: 10px;
         background-color: #fafafa;
	 }
	 .menu-list{
	 	position: relative;
	 	background-color: #fff;
	 	height:50px;
	 	padding-top: 15px;
        text-align: center;
        font-size: 1.2em;
        letter-spacing: .5px;
        cursor: pointer;
        user-select: none;
        transition: .4s;
        /*background-color: red;*/
        padding-bottom: 10px;
        border-bottom: 1px solid #f2f2f2;
      }
      .menu-list:hover{
	 	background-color: #f2f2f2;
      }
      .menu-list label{
      	position: absolute;
      	right: 20px;
      }
      .list-data ul{
      	transition: .5s;
         list-style: none;
         padding-top: 10px;
      }
      .list-data ul li{
         padding: 10px;
         padding-left: 20px;	
         position: relative;
         left: -20px;
         border-radius: 10px;
         cursor: pointer;
	   }
      .list-data ul li:hover{
	 	background-color: #f2f2f2;
	   }
      .home-data{
      	display: none;
      }
      .teacher-data{
      	display: none;
      }
      .student-data{
      	display: none;
      }

                              /*rightpart*/
	.right-part{
		position: absolute;
		top: 60px;
		height: calc(100vh - 60px);
		background-color: #f1f1f1;	
		width: calc(100% - 280px);
		transition: .5s;
		left: 280px;
		border: none;
	}
  .main-content{
  	border: none;
  }
	@media only screen and (max-width: 500px){
	   .top-user-info{
		top:60px;
		right: 0px;
		background-color: #fff;
		box-shadow: 1px 2px 2px 1px #d3d3d3;
		border-radius: 0px 0px 10px 10px;
	  }
	  .top-addbtn{
		position: absolute;
		top: 250px;
		transform: translate(0%,-50%);
		left: 30px;
	}
	.right-responsive-menu i{
		display:block;
	}
	 .top-user-info{
		display: none;
	}
	 .rightpart-top{
       height: 40vh;
       min-height: 300px;
	 }
	 .top-content{
		top: 40px;
		margin-left: 20px;
	}
	.right-part{
		width:100%;
		left: 0px;
	}
	.left-part{
		left: -280px;
	}
	#menu-icn{
		display: block;
	}
	#menu-icn1{
		display: none;
	}
	}
</style>
</head>
<body>

<div class="main-div">
	<div class="top-bar">
		<i class="fa fa-bars" aria-hidden="true" id="menu-icn"></i>
		<i class="fa fa-bars" aria-hidden="true" id="menu-icn1"></i>
		<div class="top-search">
		  <input type="text" name="srh" class="top-search-input" placeholder="Search ...">
		   <i class="fa fa-times srh-cancel"></i>
		</div>

		   <i class="fa fa-search" id="top-search-icn"></i>
		<center>
         <div id="logo-head">
          <img src="../img/login1.png" height="50px">
		    <b></b>
		   </div>
	    </center>
         <div class="right-responsive-menu">
           <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
         </div>
    	<div class="dropdown top-user-info">
    		<div class="dropdown-toggle" type="button" data-toggle="dropdown"><img src="../img/login1.png">
    			
		  <span class="caret"></span></div>
		  <ul class="dropdown-menu">
		    <li><a href="#">Account Settings</a></li>
		    <hr>
		    <li><a href="../html/login.php"><button class="btn btn-danger logout-btn ml-2">Logout</button></a></li>
		  </ul>
         </div>
	</div>
	<div class="left-part">
		<div class="menu-profile">
			<img src="img/login1.png">
			<div id="user-name">Admin</div>
			<div id="user-position"></div>
		</div>
		               <!-- menu list -->
		<div class="menu-block">
			<div class="menu-list home-list">
				Home
			  <label><i class="fa fa-angle-down" aria-hidden="true"></i></label>
			</div>
			<div class="list-data home-data">
				<ul>
					<li class="openframe backcolor">Nav Bar</li>
					<li class="openframe backcolor">Background</li>	
					<li class="openframe backcolor">Our Details</li>	
				</ul>
			</div>
	
			<div class="menu-list openframe menu-nodown">
				About
			</div>
			
			<div class="menu-list openframe menu-nodown">
				Our Teachers
			</div>

			<div class="menu-list openframe menu-nodown">
				Cources
			</div>
			<div class="menu-list openframe menu-nodown">
				Students
			</div>
		</div>
	</div>
	                              <!-- right part -->
	<div class="right-part">
		<iframe src="home/NavBar.php" name="myfrm" height="100%" width="100%" id="main-content "></iframe>
	</div>
</div>



<script type="text/javascript">
		 $('.srh-cancel').click(function(){
    	$('.top-search').css('top','-60px');
    });  
	$('#top-search-icn').click(function(){
		$('.top-search').css('top','0px');
	});
	$('.right-responsive-menu').find('i').click(function(){
		$('.top-user-info').toggle()
	});


 
     $('.menu-nodown').click(function(){
     	$('.menu-nodown').css('background-color','#fff');
     	$(this).css('background-color','#f2f2f2');;
     });
     $('.menu-list').click(function(){
     	$('.menu-nodown').css('background-color','#fff');
     });
	$('.openframe').click(function(){
		$('.menu-nodown').css('background-color','#fff');
		var x=($(this).html()).replace(/\s/g,"");
		if(x=='NavBar' || x=='Background' || x == 'OurDetails'){
           $('.backcolor').css('background-color','transparent');
		   $(this).css('background-color','#f2f2f2');	
			document.myfrm.location.replace("home/"+x+".php");
		}else {
			$(this).css('background-color','#f2f2f2');
			document.myfrm.location.replace("otherpart/"+x+".php");
		}
		// 	document.myfrm.location.replace("php/"+x+".php");
	});
	$('.openframe:first-of-type').css('background-color','#f2f2f2');
	
	$(document).ready(function(){
	if($(window).width()>500){
      $('#menu-icn').click(function(){
       	$('.left-part').css("left","0px");
       	$('#menu-icn').hide();
       	$('#menu-icn1').show();
       	$('.right-part').css({"left":"280px","width":"calc(100% - 280px)"});
       });
	$('#menu-icn1').click(function(){
       	$('.left-part').css("left","-280px");
       	$('#menu-icn1').hide();
       	$('#menu-icn').show();
       	$('.right-part').css({"left":"0px","width":"100%"});
       });
     $('.right-part').click(function(){
		$('.left-part').css("left","-280px");
		$('#menu-icn1').hide();
       	$('#menu-icn').show();
       	$('.right-part').css("left","280px");
       	$('.right-part').css({"left":"0px","width":"100%"});
	});
   }else{
      $('#menu-icn').click(function(){
       	$('.left-part').css("left","0px");
       	$('#menu-icn').hide();
       	$('#menu-icn1').show();
       	$('.right-part').css({"left":"0px","width":"100%"});
       });
	$('#menu-icn1').click(function(){
       	$('.left-part').css("left","-280px");
       	$('#menu-icn1').hide();
       	$('#menu-icn').show();
       	$('.right-part').css({"left":"0px"});
       });
    $('.right-part').click(function(){
		$('.left-part').css("left","-280px");
		$('#menu-icn1').hide();
       	$('#menu-icn').show();
       	$('.right-part').css("left","280px");
       	$('.right-part').css({"left":"0px","width":"100%"});
	});
   }



	// $('.dashboard').click(function(){
	// 	$('.dashboard').css("background-color","#f0f0f0");
	// });
	$home=0;
	$('.home-list').click(function(){
		if($home == 0){
		$('.home-data').show();
		$('.home-list').css("background-color","#f0f0f0");
		$('.dashboard').css("background-color","#fff");
		$home=1;
	    }else{
	    	$('.home-data').hide();
		    $('.home-list').css("background-color","#fff");
		    $home=0;
	    }
	});
    $('.')
});
</script>	
</body>
</html>