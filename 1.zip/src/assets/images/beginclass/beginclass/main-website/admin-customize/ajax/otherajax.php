<?php
include 'db.php';

									// about

if(isset($_POST['about'])){
    $title = $_POST['title'];
	$list1 = $_POST['list1'];
	$list1des = $_POST['list1des'];
	$list2 = $_POST['list2'];
	$list2des = $_POST['list2des'];
	$list3 = $_POST['list3'];
	$list3des = $_POST['list3des'];
	$aboutbox = $_POST['aboutbox'];
    
    $query = mysqli_query($db,"select * from webabout");
    if(mysqli_num_rows($query)>=1){
         $updateabt = mysqli_query($db,"UPDATE `webabout` SET `title`='$title',`list1`='$list1',`list1des`='$list1des',`list2`='$list2',`list2des`='$list2des',`list3`='$list3',`list3des`='$list3des',`aboutbox`='$aboutbox'");
         if($updateabt){
			echo "Updated";
		}else{
			echo "Something Went Wrong";
		}
    }else{
       $about = mysqli_query($db,"insert into webabout (`title`, `list1`, `list1des`, `list2`, `list2des`, `list3`, `list3des`, `aboutbox`) VALUES ('$title','$list1','$list1des','$list2','$list2des','$list3','$list3des','$aboutbox') ");
		if($about){
			echo "Inserted";
		}else{
			echo "Something Went Wrong";
		}
	}

}
                                 // Our teachers

if(isset($_POST['teacher'])){
	$teacher_photo = $_FILES['file'];
	$name = $_FILES['file']['name'];
	$tmp_name = $teacher_photo["tmp_name"];
	$teacher_name = $_POST['teacher_name'];
	$teacher_gmail = $_POST['teacher_gmail'];
	$teacher_facebook = $_POST['teacher_facebook'];
	$teacher_twitter = $_POST['teacher_twitter'];
	$teacher_insta = $_POST['teacher_insta'];
	$teacher_yt = $_POST['teacher_yt'];
	$teacher_whatsapp = $_POST['teacher_whatsapp'];
	$teacher_des = $_POST['teacher_des'];
	$target_file = "../images/teachers/".$name;
	$filetype = $teacher_photo["type"];
    if($filetype == 'image/png' || $filetype == 'image/jpeg' || $filetype == 'image/jpg' || $filetype == 'image/gif' || $filetype ==''){
      $query = mysqli_query($db,"INSERT INTO `webteacher`(`teacher_name`, `teacher_photo`, `teacher_gmail`, `teacher_facebook`, `teacher_twitter`, `teacher_insta`, `teacher_yt`, `teacher_whatsapp`, `teacher_des`) VALUES ('$teacher_name','$name','$teacher_gmail','$teacher_facebook','$teacher_twitter','$teacher_insta','$teacher_yt','$teacher_whatsapp','$teacher_des')");
       if($query){
       	  if (move_uploaded_file($tmp_name, $target_file)) {
			        echo "The file ". $name. " has been uploaded.";
			   } else {
			        echo "Sorry, there was an error uploading your ". $target_file. " file.";
			   }
           echo "Teacher Data Inserted";	
		}else{
			echo "Sonething Went Wrong";
		}
    }else{
    	echo "Invalid Image";
    }
}
                                 // Teacher Delete
if(isset($_POST['deleteteacher'])){
	$tname = $_POST['name'];
	$tphoto = $_POST['photo'];
	$deleteteacher = mysqli_query($db,"delete from webteacher where teacher_name = '$tname'");
	if($deleteteacher){
		echo $tname."Deleted";
		unlink('../images/teachers/'.$tphoto);
	}else{
		echo "Something Went Wrong";
	}
}
                                // Cources
if(isset($_POST['cources'])){
	$courcename = $_POST['courcename'];
	$courcephoto = $_FILES['file'];
	$courcetmp = $courcephoto['tmp_name'];
	$name = $_FILES['file']['name'];
	$courcestarting = $_POST['courcestarting'];
	$courceduration = $_POST['courceduration'];
	$courceauthor = $_POST['courceauthor'];
	$courceprice = $_POST['courceprice'];
	$courcedes = $_POST['courcedes'];
	$cources = $_POST['cources'];
    $filetype = $courcephoto["type"];
    $target_file = "../images/cources/".$name;
    $authorphoto = $_FILES['author'];
    $authorphotoname =  $_FILES['author']['name'];
    $authortmp = $authorphoto['tmp_name'];
    $authortarget = "../images/cources/author/".$authorphotoname;
    $autortype = $authorphoto["type"];
    if($filetype == 'image/png' || $filetype == 'image/jpeg' || $filetype == 'image/jpg' || $filetype == 'image/gif' || $filetype =='' && $authortype == 'image/png' || $authortype == 'image/jpeg' || $authortype == 'image/jpg' || $authortype == 'image/gif' || $authortype ==''){

          $query = mysqli_query($db,"INSERT INTO `webcources`(`c_name`, `c_photo`, `c_startingon`, `c_duration`, `c_author`,`author_photo`, `c_price`, `c_des`) VALUES ('$courcename','$name','$courcestarting','$courceduration','$courceauthor','$authorphotoname','$courceprice','$courcedes')");
          if($query){
       	  if (move_uploaded_file($courcetmp, $target_file) && move_uploaded_file($authortmp, $authortarget)) {
			        echo "The file ". $name. " has been uploaded.";
			   } else {
			        echo "Sorry, there was an error uploading your ". $target_file. " file.";
			   }
           echo "Cource Added";	
		}else{
			echo "Sonething Went Wrong";
		}
    }else{
    	echo "Invalid Image";
    }
}
                            // student review

if(isset($_POST['studreview'])){
	$studentname = $_POST['studentname'];
	$studentdes = $_POST['studentdes'];
	$studentphoto = $_FILES['studentphoto'];
	$studentrating = $_POST['studentrating'];
	$studentreview = $_POST['studentreview'];
	$name = $studentphoto['name'];
	$student_temp = $studentphoto['tmp_name'];
	$student_target = "../images/student/".$name;
	$file_type = $studentphoto['type'];
	 if($file_type == 'image/png' || $file_type == 'image/jpeg' || $file_type == 'image/jpg' || $file_type == 'image/gif' || $filetype =='' ){
        $review_insert = mysqli_query($db,"INSERT INTO `webreviews`(`name`, `des`, `photo`, `rating`, `review`) VALUES ('$studentname','$studentdes','$name','$studentrating','$studentreview')");
        if($review_insert){
        	if (move_uploaded_file($student_temp, $student_target) ) {
			        echo "The file ". $name. " has been uploaded. & Review Submitted";
			   } else {
			        echo "Sorry, there was an error uploading your ". $target_file. " file.";
			   }
        }else{
        	echo "Something Went Wrong";
        }
	 }
   
}                            
?>