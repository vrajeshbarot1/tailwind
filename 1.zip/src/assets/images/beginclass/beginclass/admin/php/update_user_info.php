<?php
session_start();
include '../../php/database.php';
	if(!isset($_SESSION['who'])){
		header('location:html/login.php');
	}

$ChageDataidOfStudent=$_SESSION['clg']; 
$who=$_SESSION['who'];
$clg=$_SESSION['clg'];
// update Name
  if(isset($_POST['update_name'])){
  	$first_name = $_POST['first_name'];
    $update_user = mysqli_query($db,"update $who set $who[0]_name ='$first_name' where $who[0]_insshortname ='$ChageDataidOfStudent'");
    if($update_user){
    	echo "Name Updated";
    }else{
    	echo "Please Try Again";
    }
  }
                         // update contact

   if(isset($_POST['update_contact'])){
   	  $old_contact = $_POST['old_contact'];
   	  $new_contact = $_POST['new_contact'];
   	  $validate = mysqli_query($db,"select * from $who where $who[0]_phno ='$old_contact'");
   	  $rows = mysqli_num_rows($validate);
   	  if($rows >= 1){
         $update_contact = mysqli_query($db,"update $who set $who[0]_phno = '$new_contact' where $who[0]_insshortname ='$ChageDataidOfStudent'");
         if($update_contact){
         	echo "Contact Updated";
         }else{
         	echo "Already Exists This Number";
         }
   	  }else{
   	  	echo "wrong Contact Number";
   	  }
   }
                          // update email

   if(isset($_POST['update_email'])){
	   	$old_email = $_POST['old_email'];
	   	$new_email = $_POST['new_email'];
	   	$validate = mysqli_query($db,"select * from $who where $who[0]_emailid ='$old_email'");
	   	$rows = mysqli_num_rows($validate);
	   	if($rows >= 1){
	   		$update_email = mysqli_query($db,"update $who set $who[0]_emailid = '$new_email' where $who[0]_insshortname ='$ChageDataidOfStudent' ");
	          if($update_email){
	         	echo "Email Updated";
	         }else{
	         	echo "Please Try again";
	         }
	   	}else{
	   	  	echo "wrong Email ID";
	   	 }
	 }
	                 // update Password

	if(isset($_POST['update_pass'])){
		$old_pass = $_POST['old_pass'];
		$new_pass = $_POST['new_pass'];
		$validate = mysqli_query($db,"select * from $who where $who[0]_pass ='$old_pass' and $who[0]_insshortname ='$ChageDataidOfStudent'");
		$rows = mysqli_num_rows($validate);
	   	if($rows >= 1){
	   		$update_pass = mysqli_query($db,"update $who set $who[0]_pass= '$new_pass' where $who[0]_insshortname ='$ChageDataidOfStudent'");
	   	    if($update_pass){
	         	echo "Password Updated";
	         }else{
	         	echo "Please Try again";
	         }
        }else{
	   	  	echo "wrong Old Password";
	   	 }
	 }
?>