<?php
	session_start();
	include '../../php/database.php';
	$hphno=$_GET['id'];
	$sql = "select * from teacher where t_phno = '$hphno'";
	$result = mysqli_query($db, $sql);
	if (mysqli_num_rows($result) ==1) {
	    while($row = mysqli_fetch_assoc($result)){
	    	 $id=$row['t_id'];
	    	 $name=$row['t_name'];
	    	 $emailid=$row['t_emailid'];
	    	 $phno=$row['t_phno'];
	    	 $pass=$row['t_pass'];
	    }
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
     <link href='https://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>
	<style type="text/css">   
		body{
			margin-top: 35px;
			padding: 0px;
	    	overflow-x: hidden;
		}
		.headleft{
             
        	position: absolute;
            margin: 10px;
        	 padding: 0px;
            border-right: 1px solid grey;
            padding-right: 3vw;
        }
        .headright{
          width: 300px;
            height: 10vh;
        	font-size: 2.8rem;
        	letter-spacing: 1px;
        	word-spacing: 3px;
        	font-family: sans-serif;
        	position: relative;
        	top: 20px;
        	left: 40vw;
        }
#TeacherFirstName{
position: relative;
left:20vw;
top: -60px;
font-size:3em; 
}
#profile {
	position: absolute;
	top: 70px;
 	margin: 2.2rem;
 	padding-left: 20px;
 	position: relative;
  min-width: 310px;
  font: 16px Helvetica, Avernir, sans-serif;
  line-height: 24px;
  color: #000
}
#profile img {
  float: right;
  padding: 10px;
  background: #fff;
  margin: 0 30px;
  box-shadow: 0 0 4px rgba(0, 0, 0, .3);
  width: 30%;
  max-width: 220px;
  border-radius: 10px;
}
 #profile h1 {
  margin: 0 0 16px 0;
  padding: 0 0 6px 0;
  font-size: 42px;
  letter-spacing: -2px;
  border-bottom: 1px solid #999;
  line-height: 50px
}
#profile h2 {
  font-size: 20px;
  margin: 0 0 6px 0;
  position: relative
}
#profile h2 span {
  position: absolute;
  bottom: 0;
  right: 0;
  font-style: italic;
  font-family: Georgia, serif;
  font-size: 16px;
  color: #999;
  font-weight: normal
}

#profile p {
  margin: 0 0 16px 0
}

#profile a {
  color: #999;
  text-decoration: none;
  border-bottom: 1px dotted #999
}

#profile a:hover {
  border-bottom-style: solid;
  color: #000
}

#profile p.objective {
  font-family: Georgia, serif;
  font-style: italic;
  color: #666
}

#profile dt {
  font-style: italic;
  font-weight: bold;
  font-size: 18px;
  text-align: right;
  padding: 0 26px 0 0;
  width: 150px;
  border-right: 1px solid #999
}

#profile dl {
  display: table-row
}

#profile dl dt,
#profile dl dd {
  display: table-cell;
  padding-bottom: 20px
}
#profile dl dd {
  width: 500px;
  padding-left: 26px
}


  #page5{
          position: relative;
         top: 50px;
            min-height: 350px;
            max-height: 800px;
      height: 65vh;
      width: 100%;
      background-color: #252525;
    }
.footfont{
  word-spacing: 4px;
  letter-spacing: 1px;
  color: #fff;
  font-family: sans-serif;
  font-size: 1rem;
}
.footfont1{
  text-align: justify;
  word-spacing: 0px;
  letter-spacing: 0px;
  font-size: 1rem;
  color: grey;
}
.footer1{
  position: absolute;
  width: 20%;
  height: 20%;
  top: 10%;
  left: 5%;
}
.footer2{
  top: 10%;
  position: absolute;
  width: 20%;
  left: 30%;
}

.footer3{
  top: 10%;
  position: absolute;
  width: 20%;
 left: 55%;
}

/* Responsive View  */

@media only screen and (max-width: 900px){
	.imghead{
            height: 100px;  
            border-right: none;
            padding-right: 0vw;
            left: 30vw;

        }
       .head h1{
        	top: 90px;
        	left: 10vw;
        }
        }

        @media only screen and (max-width: 600px){
	.imghead{
		font-size: 2.3rem;
	}
	.head h1{
		left: 90px;
	}
}

@media only screen and (max-width: 500px){
	.imghead{
		font-size: 1.7rem;
		left: 5vw;	
	}
	.head h1{
		left: 30px;
	}
  .headright{
    font-size: 1em;
  }
  #TeacherFirstName{
    top: 10px;
    left:auto;
  }
}

@media only screen and (max-width: 400px){
	.imghead{
		font-size: 1.7rem;
		left: 2vw;	
	}
	.head h1{
		left: 10px;
	}
}
@media only screen and (max-width: 350px){
	.imghead{
		font-size: 1.5rem;
		left: 0vw;	
	}
	.head h1{
		left: -10px;
	}
@media screen and (max-width:1100px) {
  #profile h2 span {
    position: static;
    display: block;
    margin-top: 2px
  }
}

@media screen and (max-width:550px) {
  body {
    margin: 1rem
  }
  #profile img {
    transform: rotate(0deg)
  }
}

@media screen and (max-width:400px) {

 #profile dl dt {
    border-right: none;
    border-bottom: 1px solid #999
  }
  #profile dl,
  #profile dl dd,
#profile dl dt {
    display: block;
    padding-left: 0;
    margin-left: 0;
    padding-bottom: 0;
    text-align: left;
    width: 100%
  }
 #profile dl dd {
    margin-top: 6px
  }
  #profile h2 {
    font-style: normal;
    font-weight: 400;
    font-size: 18px
  }
#profile dt {
    font-size: 20px
  }
  h1 {
    font-size: 36px;
    margin-right: 0;
    line-height: 0
  }
  #profile img {
    margin: 0
  }
}

@media screen and (max-width:320px) {
  body {
    margin: 0
  }
  img {
    margin: 0;
    margin-bottom: -40px
  }
  #profile {
    width: 320px;
    padding: 12px;
    overflow: hidden
  }
  p,
  li {
    margin-right: 20px
  }
}
	</style>
</head>
<body onload="fun()">
<div class="headleft"><img src="../../img/login1.png"  height="80px"></div>
        <div class="headright">Teacher Profile</div>
 
 <!-- profile -->
    <div id="profile">
<!--     	<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/4273/james-moriarty.jpg" alt="James Moriarty"> -->
    	<h1>Teacher Name:</h1>
      <p id="TeacherFirstName"><?php echo $name;?></p>
      <br/>
      <br/>
      <p>ID: <a href=#><?php echo $id;?></a></p>
<dl>
<dt>CONTACT-1 NO.
<dd id="contactOne">
<?php echo $phno;?>    
 </dd>
</dl>
<dl>
<dt>Email-ID.
<dd id="emailid">
	<?php echo $emailid;?>
     </dd>
</dl>
<dl>
<dt>Password.
<dd id="pass">
	<?php echo $pass;?>
     </dd>
</dl>
</div>
</body>
</html>