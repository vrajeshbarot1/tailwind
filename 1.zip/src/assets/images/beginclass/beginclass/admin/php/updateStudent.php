<?php
	include '../../php/database.php';
	$hphno=$_GET['id'];
	$sql = "select * from users where phno1 = '$hphno'";
	$result = mysqli_query($db, $sql);
	if (mysqli_num_rows($result) ==1) {
	    while($row = mysqli_fetch_assoc($result)){
	    	 $fname=$row['fname'];
	    	 $lname=$row['lname'];
	    	 $email=$row['email'];
	    	 $enroll=$row['enrollno'];
	    	 $phno=$row['phno1'];
	    	 $phno1=$row['phno2'];
	    	 $branch=$row['branch'];
	    	 $fathermailid=$row['fatheremail'];
	    	 $fatherphno=$row['fatherphno'];
	    	 $gender=$row['gender'];
	    	 $id=$row['id'];
	    	 $pass=$row['pass'];
	
	    }
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/css/mdb.min.css" rel="stylesheet">
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/js/mdb.min.js"></script>


	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://j11y.io/demos/plugins/jQuery/autoresize.jquery.js"></script>
	<style type="text/css">
		body{
			padding-bottom: 200px;
			padding-top: 10px;
			padding-left: 100px;
			padding-right: 100px;
			background-color: #fff;
			user-select: none;
		}
		.box{

			transition: 1s;
			border-radius: 6px;
			z-index: 5;	
		}
		.add{
			font-weight: 500;
			font-family: sans-serif;
		}
		.options{
			margin-top: 5%;
			padding:50px;
			border:4px solid white;
			box-shadow:
			0 0 16px rgba(41,42,51,0.06),
			0 6px 20px rgba(41,42,51,0.02);
			background-color: #F5F5F5;;
		}

		.book{
			display: block;
		}
		@media only screen and (max-width: 786px){
		 	.box{
		 		margin-bottom: 100px;
		 	}
		 	body{
				padding: 0px 3px;
				background-color: #fff;
				user-select: none;
			}
		 	.options{
			}
		}
	</style>	
</head>
<body>
	<br/>
	
	<div class="container options">
    		<h1>Update Student</h1>	
    	<div class="book" class="tab-pane fade">
    	<!-- <form  action="../php/imageUpload.php" metStudent="post" enctype="multipart/form-data" class="book" class="tab-pane fade"> -->
    		<br/>
			<br/>
			<div class="form-group">
			    <label for="exampleInputEmail1">Student First Name :</label>
			    <input type="text" name="fname" id="fname" class="form-control" id="exampleInputEmail2" value="<?php echo $fname;?>"  placeholder="Enter Student First Name">
			</div>
 			<br/>
 			<div class="form-group">
			    <label for="exampleInputEmail1">Student Last Name :</label>
			    <input type="text" name="lname" id="lname" class="form-control" id="exampleInputEmail3"  value="<?php echo $lname;?>" placeholder="Enter Student Last Name">
			</div>
			<br/>
			<!-- Default inline 1-->
			 <label class="" for="defaultInline0"><b>Gender : </b></label>
			<div class="custom-control custom-radio custom-control-inline">
			  <input type="radio" class="custom-control-input" id="defaultInline1" name="gender" value="male" >
			  <label class="custom-control-label" for="defaultInline1">Male</label>
			</div>

			<!-- Default inline 2-->
			<div class="custom-control custom-radio custom-control-inline">
			  <input type="radio" class="custom-control-input" id="defaultInline2" name="gender" value="female">
			  <label class="custom-control-label" for="defaultInline2">Female</label>
			</div>

			<!-- Default inline 3-->
			<div class="custom-control custom-radio custom-control-inline">
			  <input type="radio" class="custom-control-input" id="defaultInline3" name="gender" value="other">
			  <label class="custom-control-label" for="defaultInline3">Other</label>
			</div>
			<br/>
			<br/>
			<div class="form-group">
			    <label for="exampleInputEmail1">Student Email ID :</label>
			    <input type="email" name="emailid" id="emailid" class="form-control" value="<?php echo $email;?>" id="exampleInputEmail2"  placeholder="Enter Student Email-ID ">
			</div>
			<br/>
 			<div class="form-group">
			    <label for="exampleInputEmail1">Student User-ID/EnrollNo. :</label>
			    <input type="text" name="enrolno" id="enrolno" class="form-control" id="exampleInputEmail3" value="<?php echo $enroll;?>" placeholder="Enter Student Student User-ID/EnrollNo.">
			</div>
			<br/>
			<div class="form-group">
			    <label for="exampleInputEmail1">Student Phone No. :</label>
			    <input type="number" name="sphno" id="sphno" class="form-control" id="exampleInputEmail2" value="<?php echo $phno;?>"  placeholder="Enter Student Phone No.">
			</div>
			<br/>
			<div class="form-group">
			    <label for="exampleInputEmail1">Student Phone No2. :</label>
			    <label style="float: right; color:red;">If Only * </label>
			    <input type="number" name="sphno2" id="sphno2" class="form-control" id="exampleInputEmail2" value="<?php echo $phno1;?>" placeholder="Enter Student Phone No2.">
			</div>
			<br/>
			<div class="form-group">
			    <label for="exampleInputEmail1">Student Password :</label>
			    <input type="text" name="hpassword" id="hpassword" class="form-control" id="exampleInputEmail2" value="<?php echo $pass;?>" placeholder="Enter Student Password">
			</div>
			<!-- aayiya option aavse -->
			<br/>
			<select class="browser-default custom-select" id="branch">
			  <option selected>Select Branch</option>
			  <option value="1">1</option>
			  <option value="2">2</option>
			  <option value="3">3</option>
			  <option value="4">4</option>
			  <option value="5">5</option>
			  <option value="6">6</option>
			  <option value="7">7</option>
			  <option value="8">8</option>
			  <option value="9">9</option>
			  <option value="10">10</option>
			  <option value="11 Commerce">11 Commerce</option>
			  <option value="12 Commerce">12 Commerce</option>
			  <option value="11 Scince">11 Scince</option>
			  <option value="12 Scince">12 Scince</option>
			</select>
			<br/>
			<br/>
	      	<div class="form-group">
			    <label for="exampleInputEmail1">Father Email ID :</label>
			    <input type="email" name="fatheremailid" value="<?php echo $fathermailid ;?>" id="fathermailid" class="form-control" id="exampleInputEmail2"  placeholder="Enter Father Email-ID ">
			</div>
			<div class="form-group">
			    <label for="exampleInputEmail1">Father Phone No. :</label>
			    <input type="number" name="fatherphno" value="<?php echo $fatherphno ;?>" id="fatherphno" class="form-control" id="exampleInputEmail2"  placeholder="Enter Father Phone No.">
			</div>
			<!-- aayiya college short name aavse -->
			<br/>
			<br/><br/>
			 <button type="button" class="btn btn-primary" onclick="submitB()">Submit</button>
		<!-- 	  <input type="submit" value="Upload Image" name="submit"> -->
    	<!-- </form> -->
    	</div>


	</div>
</body>
<script type="text/javascript">
	$('textarea').autoResize();
	$("input[name=gender][value= <?php echo $gender; ?>]").attr('checked', 'checked');
	$("select").val("<?php echo $branch; ?>");
	function submitB(){
		  var fname=$('#fname').val();
		  var lname=$('#lname').val();
		  var gender=$('input[name="gender"]:checked').val();
		  var email=$('#emailid').val();
		  var enroll=$('#enrolno').val();
		  var phno=$('#sphno').val();
		  var phno1=$('#sphno2').val();
		  var branch=$('#branch').find(":selected").text();
		  var pass=$('#hpassword').val();
		  var femail=$('#fathermailid').val();
		  var fphno=$('#fatherphno').val();
		  if(fname.length==0){
	        alert("Please Enter Student First Name");
	        $('#fname').focus();
	    }else if(lname.length==0){
	        alert("Please Enter Student Last Name");
	        $('#lname').focus();
	    }else if(email.length==0){
	        alert("Please Enter Student Email-Id");
	        $('#emailid').focus();
	    }else if(enroll.length==0){
	        alert("Please Enter Student EnrollNo");
	        $('#enrolno').focus();
	    }else if(phno.length==0){
	        alert("Please Enter Student PhoneNo.");
	        $('#sphno').focus();
	    }else if(branch=='Select Branch'){
	        alert("Please Enter Student Branch");
	        $('#branch').focus();
	    }else if(pass.length==0){
	        alert("Please Enter Student Password");
	        $('#hpassword').focus();
	    }else if(femail.length==0){
	        alert("Please Enter Father Email-ID");
	        $('#fathermailid').focus();
	    }else if(fphno.length==0){
	        alert("Please Enter Father Phone No.");
	        $('#fatherphno').focus();
	    }else{
	    	if(phno1.length==0){
	    		phno1='';
	    	}
	    	var form_data={
	    		work:'updatestudent',
	            id:'<?php echo $id;?>',
	            fname:fname,
			    lname:lname,
			    gender:gender,
			    email:email,
			    enroll:enroll,
			    phno:phno,
			    phno1:phno1,
			    branch:branch,
			    pass:pass,
			    femail:femail,
			    fphno:fphno
	        };
		  $.ajax({
		      url: "../php/ajax.php",
		      data: form_data,
		      type: "POST",
		      success: function(data){
		          //$(te).			
					if(data=='Record updated successfully'){
		          		alert('Record updated successfully');
			          	location.replace('../html/UpdateStudent.html');
		          	}
		          	else
		          		alert(data);
		      }
		  });		
	   }
	}
</script>
</html>