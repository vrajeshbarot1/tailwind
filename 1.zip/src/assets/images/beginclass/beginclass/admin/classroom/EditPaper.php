<?php
	session_start();
	$who=$_SESSION['who'];
	if($who=='student' || $who=='')
		echo "<script>parent.location.reload();</script>";
	
	else{
		$tp=explode(",",$_GET['id']);
		$txtLocation=$tp[1];
		$myfile = fopen("../../paper/".$txtLocation.".txt", "r") or die("Unable to open file!");
		$string='';
		while(!feof($myfile)){
		  $string.=fgets($myfile);
		}
		 $x=preg_replace("/\\n/", "<br/>", $string);
	  	fclose($myfile);
?>	  
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.backWork{
		  right: 40px;
		  top: 20px;
		  position: absolute;
		}
		form{
			position:relative;
			top: 100px;
		}
	</style>
	<link href="assets/css/quill.css" rel="stylesheet">
	<script src="assets/css/quill.js"></script>
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<button class="btn btn-danger backWork" onclick="backWork()">back</button>
		<center><h3><b>Date Format:- yyyy-mm-dd_hh:mm</b></h3></center>
		<form method="post" action="EditPaperStyle.php" onsubmit="return fun()" > 
		 <div id="editor">
		 	<p id="maintext" value=""><?php echo $x;?></p>
		 </div>
		 <input type="hidden" name="location" value="<?php echo $txtLocation?>">
		 <input type="hidden" name="text" id="text" value="">
		 <input type="submit" placeholder="submit">
		</form> 	
	</div>	
	<!-- <button type="submit" placeholder="Update" onclick="senDataAjax()">Update</button>  -->
<script type="text/javascript">
	function backWork(){
		location.replace('UpcomingExamsList.php');
    }
	  var quill = new Quill('#editor', {
    theme: 'snow'
  });
	    function fun(){
	  	var str="";
		var arr=document.getElementsByTagName('p');
		for (var i = 0; i < arr.length; i++) {
			str+=arr[i].innerHTML+"\n";
		}
		document.getElementById('text').value = str;
		return true;
	  }
</script>
</body>
</html>
<?php
	}	
?>