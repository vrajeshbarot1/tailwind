<?php
	session_start();
	$classRoomId=$_SESSION['classRoomId'];	
	$mymobileNo=$_SESSION['uid'];
	$clg=$_SESSION['clg'];
    include '../../php/database.php';
	$who=$_SESSION['who'];
	if($who=='student' || $who=='')
		header('location:../../html/login.php');
	$txtLocation=$_GET['d'];
	date_default_timezone_set('Asia/Kolkata');
    $nowCompareExamTime=date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <link rel="stylesheet" href="../../classroom/assets/css-js/bootstrap.min.css">
    <script src="../../classroom/assets/css-js/jquery.min.js"></script>
    <script src="../../classroom/assets/css-js/popper.min.js"></script>
    <script src="../../classroom/assets/css-js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Orbitron&display=swap" rel="stylesheet">
    <style type="text/css">
 p {
			    text-align: center;
			    font-size: 40px;
			    margin-top: 0px;
			    font-family:'Orbitron','sans-serif'; 
			  }
			 body{
			  background-color: #f0f0f0;
			 }

.your-result{
	position: relative;top: 75px;
	font-size: 2em;
}
                        /*Radio Button*/

.container-radio {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 20px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.container-radio input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark-radio {
  position: absolute;
  top: 4px;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.container-radio:hover input ~ .checkmark-radio {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.container-radio input:checked ~ .checkmark-radio {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark-radio:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.container-radio input:checked ~ .checkmark-radio:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.container-radio .checkmark-radio:after {
 	top: 9px;
	left: 9px;
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: white;
}
                                      /*check box*/

.container-check {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 20px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.container-check input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark-check {
  position: absolute;
  top: 4px;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 5px;
}

/* On mouse-over, add a grey background color */
.container-check:hover input ~ .checkmark-check {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.container-check input:checked ~ .checkmark-check {
  background-color: #2196F3;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark-check:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.container-check input:checked ~ .checkmark-check:after {
  display: block;
}

/* Style the checkmark/indicator */
.container-check .checkmark-check:after {
  left: 9px;
  top: 5px;
  width: 6px;
  height: 12px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}



			.allCaintain{
			   border:1px solid lightgrey;
			   border-left: none;
			   border-right:none;
			   width: 100%;
			   background-color: #fff;
			   margin: auto;
			}
			.fullMcq{
			  position: relative;
			  /*background-color: red;*/
			   margin-top: 100px;
			 
			  /*width: 70%;*/
			  padding: 30px;

			   padding-bottom: 0px;
			  margin: auto;
			}
			.marks{
			    position: absolute;
			    right: 4vw;
			}
			.qustion{
			   position: relative;
			   font-size: 1.2em;
			   font-weight: 600;
			}
			.header{
			  position: fixed;
			  top: 0px;
			  z-index: 15;
			  background-color: #3d619b;
			  height: 70px;
			  margin-bottom: 100px;
			  width: 100%;
			}
			#startat{
			  position: fixed;
			  top: -10px;
			  background-color:none;
			  z-index: 16;
			  color:white;
			  right: 380px;
			  font-size: 2em;
			  padding: 20px;
			}
			#demo{
			  position: fixed;
			  top: -10px;
			  background-color:none;
			  z-index: 16;
			  color:white;
			  right: 30px;
			  font-size: 2em;
			  padding: 20px;
			}
			/*orbitron*/
			.subjectname{
			  font-family: sans-serif;
			  color: #fff;
			  margin-top: 5px;
			  margin-left: 30px;
			  letter-spacing: 1px;
			}
			.headerarea{
			  height: 100px;
			  position: relative;
			  width: 100%;
			}
			.smtbtn{
			  position: relative;
			  margin:20px;
			  margin-left: 230px;
			}
			.backWork{
			  right: 40px;
			  top: 100px;
			  position: absolute;
			}
			img{
			  z-index: 7;
			  position: relative;
			  transition: 1.8s;
			}
			img:hover{
			  z-index: 17;
			   transform: scale(1.8); 
			}
			#subnmaemobile{
				display: none;
			}	
			@media only screen and (max-width: 500px){
				.subjectname{
					margin-top: 100px;
					color:black;
					display: none;
					position: relative;
				}
				#subnmaemobile{
					display: block;
				}	
			}
    </style>
</head>
<body>
	<?php
        $myfile = fopen("../../paper/".$txtLocation.".txt", "r") or die("Unable to open file!");
      $sqlfortime="select * from ".$classRoomId."_metadata where txtname ='".$txtLocation."'";
            $listup = mysqli_query($db,$sqlfortime);
            $total=0;
            if (mysqli_num_rows($listup) > 0) {
                while($row = mysqli_fetch_assoc($listup)) {
                    $st=$row['starttime'];
                    $ed=$row['endtime'];
               }
            }
        $n=strtotime($nowCompareExamTime);
        $u=strtotime($st);
        $e=strtotime($ed);
  //live paper
      if($n>=$u && $n<=$e){
      	?>
      		<script type="text/javascript">alert('Live Exam');</script>
      		<?php
	      	include 'livePaper.php';
	      	?>
			</form>
	      	<?php
      }  
  // past      
      if($n>$e){
	    	 $myResult=1;
	    	 $sql="select * from ".$classRoomId."_metadata where txtname='".$txtLocation."'";
		     $result=mysqli_query($db,$sql);
		    if (mysqli_num_rows($result) == 1) {
		    	while($row = mysqli_fetch_assoc($result)){
		    		$myResult =  $row['result'];
		    	}
		    }
		    if($myResult){}
///		      	include 'pastPaper.php';
      		else
      			echo "<center><h1>Result Will Publish Soon : </h1></center>";
      }
  ///fature  
      if($n<$u){
      		?>
      		<script type="text/javascript">alert('fature Exam');</script>
      		<?php
	      	include 'livePaper.php';

      }

      	?>
</body>      
</html>