<?php
	session_start();
	$who=$_SESSION['who'];
	if($who=='student' || $who=='')
		header('location:../../html/login.php');
  	include '../../php/database.php';
  	$classRoomId=$_SESSION['classRoomId'];
	$clientName=$_POST['fnm'];
	$clientNumber=$_POST['b'];
	$Myid=$clientNumber;
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
  	<style type="text/css">
		.chat
		{
		    list-style: none;
		    margin: 0;
		    padding: 0;
		}

		.chat li
		{
		    margin-bottom: 40px;
		    padding-bottom: 5px;
		    /* border-bottom: 1px dotted #B3A9A9; */
		    margin-top: 10px;
		    width: 80%;
		}


		.chat li .chat-body p
		{
		    margin: 0;
		    /* color: #777777; */
		}


		.chat-care
		{
		    overflow-y: scroll;
		    height: 60vh;
		}
		.chat-care .chat-img
		{
		    width: 50px;
		    height: 50px;
		}
		.chat-care .img-circle
		{
		    border-radius: 50%;
		}
		.chat-care .chat-img
		{
		    display: inline-block;
		}
		.chat-care .chat-body
		{
		    display: inline-block;
		    max-width: 80%;
		    background-color: #FFC195;
		    border-radius: 12.5px;
		    padding: 15px;
		}
		.chat-care .chat-body strong
		{
		  color: #0169DA;
		}

		.chat-care .admin
		{
		    text-align: right ;
		    float: right;
		}
		.chat-care .admin p
		{
		    text-align: left ;
		}
		.chat-care .agent
		{
		    text-align: left ;
		    float: left;
		}
		.chat-care .left
		{
		    float: left;
		}
		.chat-care .right
		{
		    float: right;
		}

		.clearfix {
		  clear: both;
		}




		::-webkit-scrollbar-track
		{
		    box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
		    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
		    background-color: #F5F5F5;
		}

		::-webkit-scrollbar
		{
		    width: 12px;
		    background-color: #F5F5F5;
		}

		::-webkit-scrollbar-thumb
		{
		    box-shadow: inset 0 0 6px rgba(0,0,0,.3);
		    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
		    background-color: #555;
		}
  	</style>
</head>
<body>
	<!--================ End Header Menu Area =================-->
<div class="container">
 <br>
 <button class="btn btn-primary" onclick="backBtn()" style="float:right ">Back</button>
 <br>
 <br>
 <br>
	  <div class="row">
	        <div class="col-md-6 mx-auto">
	            <div class="card">
	                <div class="card-header text-center">
	                    <span><?php echo $clientName."<br>".$clientNumber; ?></span>
	                </div>
	                <div class="card-body chat-care" id="chatscroll">
	                    <ul class="chat">
	                    	<div id="chathere"></div>
	                    </ul>
	                </div>
	                <div class="card-footer">
	                    <div class="input-group">
	                        <input id="btn-input"  type="text"  class="form-control input-sm" placeholder="Type your message here..." />
	                        <span class="input-group-btn">
	                            <button class="btn btn-primary" id="btn-chat" onclick="sendmessage()">Send</button>
	                        </span>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
	<br>
	<br>
	<script type="text/javascript">
	var div=document.getElementById('chathere'),scrolling=false;
	function sendmessage(){
		var msg=document.getElementById('btn-input');
		$.ajax({
			url:"sendmessage.php",
			data:{
				f:'<?php echo $classRoomId; ?>.<?php echo $Myid; ?>.enc',
				m:msg.value
			},
			type:"POST",
			success:function(result,status){
				console.log(result);
				scrolling=true;
			}
		});
		msg.value="";
		return false;
	}
	var first=true,txt="",updatecount=0;
	setInterval(function(){
		var elet=document.getElementById('chatscroll');
        var oldscrollHeight =elet.scrollHeight; //Scroll height before the request
		$.ajax({
			url:'../../chats/<?php echo $classRoomId; ?>.'+'<?php echo $Myid; ?>.enc',
			type:"POST",
			success:function(result,status){
				if(txt!=result){
					txt=result;
					var all=result.split("\n");
					div.innerHTML="";
					for(var i = 0; i < all.length-1; i++){
						var tmp=all[i].replace(/\\n/g,'<br>');
						var a=tmp;
						var b=a.split(":");
						var er= all[i].substr(0, all[i].indexOf(':')); 
						if(er!='admin'){
							div.innerHTML=div.innerHTML+`<li class="agent clearfix"><span class="chat-img left clearfix mx-2"><img src="http://placehold.it/50/55C1E7/fff&text=U" alt="Agent" class="img-circle" /></span><div class="chat-body clearfix"><div class="header clearfix"><strong class="primary-font"><?php echo $clientName;?></strong></div><p>${b[2]}</p></div></li>`;
						}else{
							div.innerHTML=div.innerHTML+`<li class="admin clearfix"><span class="chat-img right clearfix  mx-2"><img src="http://placehold.it/50/FA6F57/fff&text=ME" alt="Admin" class="img-circle" /></span><div class="chat-body clearfix"><div class="header clearfix"><strong class="right primary-font">Me(Admin)</strong></div><p>${b[2]}</p></div></li>`;
						}
					}
					scrolling=false;
				}
				//Auto-scroll			
					var elet=document.getElementById('chatscroll');
					var newscrollHeight = elet.scrollHeight;//Scroll height after the request
					if(newscrollHeight > oldscrollHeight){
						$('#chatscroll').animate({ scrollTop:$(document).height()},20); //Autoscroll to bottom of div
					}	
			}
		});
	},500);
	function backBtn(){
		history.go(-1);
	}
	</script>
</body>
</html>
