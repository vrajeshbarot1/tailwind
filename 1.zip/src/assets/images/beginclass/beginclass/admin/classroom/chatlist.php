<?php
	session_start();
	$who=$_SESSION['who'];
	if($who=='student' || $who=='')
		header('location:../../html/login.php');
  	include '../../php/database.php';
  	$classid=ltrim($_SESSION['classRoomId'],'c');

?>
<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/css/mdb.min.css" rel="stylesheet">
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/js/mdb.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Comfortaa&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../css/AccountSetting.css"><title>chats</title>
	<style type="text/css">
		.frndname{
			background-color:lightblue;
			margin: 15px;
			padding:15px; 
			width: 50%;
			font-size: 15px;
			text-align: left;
			padding-left: 20px;
		}
	</style>
</head>
<body>
  	<div class="container-fluid">
  		<h1>Chat List :-</h1>
	  	<center><div id="frndlist"></div></center>
	  	<form method="post" action="chat.php">
	  		<input type="hidden" name="fnm">
	  		<input type="hidden" name="b">
	  		<input type="hidden" name="m">
	  	</form>
  	</div>
  	<script type="text/javascript">
 setInterval(function(){
 //setTimeout(function(){
		$.ajax({
			url:'mychatlistbackend.php',
			type:"POST",
			success:function(result,status){	
				var frnds=[];
				var str=''; 	
				var obj=JSON.parse(result);
				for (var i = 0; i < obj.length; i++){
					frnds.push({f:obj[i].fname+"&nbsp;"+obj[i].lname,e:obj[i].e,t:obj[i].t});
				}
				frnds.sort(function (a, b) {
				  return b.t - a.t;
				});
			  	for (var i = 0; i < frnds.length; i++){
			  		str+='<div class="frndname" onclick="startchat(\''+frnds[i].f+'\',\''+frnds[i].e+'\')"> '+frnds[i].f+'<br>'+frnds[i].e+'</div>';
			  	}	
  			 $('#frndlist').html(str);

			}
		});
	},1000);

  	var form=document.forms[0];
  	function startchat(f,e){
  		form.fnm.value=f;
  		form.b.value=e;
  		form.submit();
  	}
  	</script>
</body>
</html>