<?php
  session_start();
  include '../../php/database.php';
  $who=$_SESSION['who'];
  if($who=='student' || $who=='')
	header('location:../../html/login.php');
  $classid=ltrim($_SESSION['classRoomId'],'c');

  $sql="select u.fname,u.lname,u.phno1 from clasroomstud c , users u where c.classroom_id='$classid' and  c.u_phno=u.phno1";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        $all=array();
        while($row = mysqli_fetch_assoc($result)) {
	  	  $file = file('../../chats/'.$_SESSION['classRoomId'].'.'.$row['phno1'].'.enc');
		  $myTime=explode(':',$file[count($file) - 1]);
          $ar=array('fname'=>$row['fname'],'lname'=>$row['lname'] ,'e'=>$row['phno1'] ,'t'=>$myTime[1]);
          array_push($all,$ar);
        }
        echo json_encode($all);
    }else echo "";
?>