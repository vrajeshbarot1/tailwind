<?php 
  session_start();
  include '../../php/database.php';
  $who=$_SESSION['who'];
  if($who=='student' || $who=='')
    echo "<script>parent.location.reload();</script>";
  $work=$_POST['work'];
  $cid=$_SESSION['classRoomId'];
  $clgfullname=$_SESSION['collageFullName'];
  $who=$_SESSION['who'];
  date_default_timezone_set('Asia/Kolkata');
  $now=date('Y-m-d H:i:s');
 
  if ($work=="pending") {
    $sql="select * from ".$cid."_metadata where starttime >'".$now."'";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        $all=array();
        while($row = mysqli_fetch_assoc($result)) {
          $ar=array('txtlocation'=>$row['txtname'],'uploadtime'=>$row['starttime'] ,'endtime'=>$row['endtime'] ,'who'=>$who,'subject'=>$row['subject'],'devicetime'=>$now);
          array_push($all,$ar);
        }
        echo json_encode($all);
    }else echo "";
}
if($work=="activate"){
    $sql="select * from ".$cid."_metadata where '".$now."' > starttime and '".$now."'< endtime order by txtname desc";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        $all=array();
        while($row = mysqli_fetch_assoc($result)) {
            $ar=array('txtlocation'=>$row['txtname'],'uploadtime'=>$row['starttime'] ,'endtime'=>$row['endtime'] ,'who'=>$who,'subject'=>$row['subject'],'devicetime'=>$now);
          array_push($all,$ar);
        }
        echo json_encode($all);
    }else echo "";
}
if($work=="complete"){
     $sql="select * from ".$cid."_metadata where endtime <'".$now."' order by txtname desc";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        $all=array();
        while($row = mysqli_fetch_assoc($result)) {
          $ar=array('resultnum'=>$row['result'],'txtlocation'=>$row['txtname'],'uploadtime'=>$row['starttime'] ,'endtime'=>$row['endtime'] ,'who'=>$who,'subject'=>$row['subject'],'devicetime'=>$now);
          array_push($all,$ar);
        }
        echo json_encode($all);
    }else echo mysqli_error($db);
}
if($work=="deleteFile"){
  $txt=$_POST['txl']; 
  $sql = "delete from ".$cid."_metadata where txtname = ".$txt;
  if (mysqli_query($db, $sql)) {
      $sql = "delete from ".$cid."_result where txtname = ".$txt;
      mysqli_query($db, $sql);
      echo "Record deleted successfully";
  } else {
      echo "Error deleting record: " . mysqli_error($db);
  }
}
if($work=="mailParents"){
  $txt='data';
  $txtLocationto=$_POST['t'];
  $headi='heading';
  $subject='subject';
  $cid=ltrim($cid, 'c');
  $sql = "select u.fatheremail from users u,clasroomstud c where c.classroom_id='".$cid."' and u.phno1=c.u_phno;";
  $result = mysqli_query($db,$sql);
  $to='';
  if (mysqli_num_rows($result) > 0) {
      // output data of each row
      while($row = mysqli_fetch_assoc($result)) {
          $to.=$row["fatheremail"].",";
      }
  }
 $sql="select a_emailid from admin where a_insshortname ='".$_SESSION['clg']."'";
 $result=mysqli_query($db,$sql);
 if (mysqli_num_rows($result) > 0) {
    $all=array();
    while($row = mysqli_fetch_assoc($result)) {
        $adminid=$row['a_emailid'];
    }
  }
 $sql="select * from c".$cid."_metadata where txtname ='".$txtLocationto."'";
  $result=mysqli_query($db,$sql);
  if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $starttime=$row['starttime'];
        $endtime=$row['endtime'];
        $subjecttxt=$row['subject'];
    }
  }
  $to=rtrim($to, ", ");
  ///*echo $to;*/
 $subject=$clgfullname;
 $headers = "From: $adminid" . "\r\n";
 //echo $headers;
 $msg='The examination of '.$subjecttxt.' is to be conducted on '.$starttime.' to '.$endtime;
 if(@mail($to,$subject,$msg,$headers))
     echo "Successfully sended mail.";
    
}
if($work=="uploadResult"){
 
 $subject=$clgfullname;
 $to='';
 $marks=0;
 $starttime='';
 $mymarks='0';
 $subjecttxt='';
 $r=$_POST['r'];
 
 $sql="select a_emailid from admin where a_insshortname ='".$_SESSION['clg']."'";
 $result=mysqli_query($db,$sql);
 if (mysqli_num_rows($result) > 0) {
    $all=array();
    while($row = mysqli_fetch_assoc($result)) {
        $adminid=$row['a_emailid'];
    }
  }
  $headers = "From: $adminid" . "\r\n";
  
  $sql="select * from ".$cid."_metadata where txtname ='".$r."'";
  $result=mysqli_query($db,$sql);
  if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $starttime=$row['starttime'];
        $subjecttxt=$row['subject'];
    }
  }
  $sql = "update ".$cid."_metadata set result = '1' where txtname='".$r."'";
  if(mysqli_query($db,$sql)){
    $cid1=ltrim($cid, 'c');
    $sql = "select u.fatheremail,cr.my_marks from users u,clasroomstud c,".$cid."_result cr where c.classroom_id='".$cid1."' and u.phno1=c.u_phno and cr.txtname='".$r."' and c.u_phno=cr.u_phono";
    $result = mysqli_query($db,$sql);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $to=$row["fatheremail"];
            $mymarks=$row["my_marks"];
            $msg='Dear parents your child has gained '.$mymarks.' marks in the '.$subjecttxt.' examination conducted on '.$starttime;
            mail($to,$subject,$msg,$headers);
        }
    }
     echo 'Result successfully Upload';
  }else{
    echo "Error Uploading result : " . mysqli_error($db);
  }
 }

 if($work=="studentList"){
    $txt=$_POST['t'];
      $all=array();
     $sql="select * from ".$cid."_result c,users u where c.u_phono=u.phno1 and c.txtname='$txt'";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $ar=array('name'=>$row['fname'],'phno'=>$row['phno1'],'lname'=>$row['lname'],'marks'=>$row['my_marks']);
          array_push($all,$ar);
        }
  }
    $cid1=ltrim($cid,'c');
    $sql="select * from clasroomstud c,users u where c.u_phno=u.phno1 and classroom_id='$cid1'";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
          $xll=array();
        while($row = mysqli_fetch_assoc($result)) {
          $xr=array('name'=>$row['fname'],'phno'=>$row['phno1'],'lname'=>$row['lname'],'marks'=>'<b>Not Attempted</b>');
          array_push($xll,$xr);
        }
        echo json_encode($all).'?'.json_encode($xll);
    }

    else echo mysqli_error($db);
}
if($work=="StudentIncrementMarks"){
  $txname=$_POST['txl'];
  $id=$_POST['id'];
  $mrk=$_POST['mrk'];
     $sql="update  ".$cid."_result set my_marks ='".$mrk."' where u_phono='".$id."' and txtname ='".$txname."'";
      if (mysqli_query($db, $sql)) {
          echo "Record updated successfully";
      } else {
          echo "Error updating record: " . mysqli_error($db);
      }
}
if($work=="showClassJoinStudentList"){
  $cid=ltrim($cid, 'c');
  $all=array();
     $sql="select * from clasroomstud c,users u where c.classroom_id='".$cid."' and u.phno1=c.u_phno";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $ar=array('fname'=>$row['fname'],'lname'=>$row['lname'],'phno'=>$row['phno1'],'joindate'=>$row['joindate']);
            array_push($all,$ar);
          }
        echo json_encode($all);
    }else echo "";
}
if($work=="deleteStudentFromClassRoom"){
  $r=$_POST['r'];
  $cid1=ltrim($cid, 'c');
  $sql = "delete from clasroomstud where classroom_id = '".$cid1."' and u_phno = '".$r."'" ;
  if (mysqli_query($db, $sql)) {
   $sql = "delete from ".$cid."_result where u_phono = '".$r."'" ;
  if (mysqli_query($db, $sql)) {
      echo "Record deleted successfully";
    }
  } else {
      echo "Error deleting record: " . mysqli_error($db);
  }
}
if($work=="showClassSubjectList"){
  $all=array();
     $sql="select * from ".$cid."_metadata order by txtname desc";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $ar=array('txtname'=>$row['txtname'],'sttime'=>$row['starttime'],'edtime'=>$row['endtime'],'subject'=>$row['subject']);
            array_push($all,$ar);
          }
        echo json_encode($all);
    }else echo "";
}
if($work=="studentListForGiveChance"){
    $txt=$_POST['t'];
      $all=array();
     $sql="select * from ".$cid."_result c,users u where c.u_phono=u.phno1 and c.txtname='$txt'";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $ar=array('name'=>$row['fname'],'phno'=>$row['phno1'],'lname'=>$row['lname'],'marks'=>$row['my_marks'],'txtname'=>$row['txtname']);
          array_push($all,$ar);
          }
        echo json_encode($all);
    }else echo mysqli_error($db);
}
if($work=="deleteresultT"){
  $phno=$_POST['p'];
  $txtname=$_POST['t'];
  $sql = "delete from ".$cid."_result where txtname = '".$txtname."' and u_phono = '".$phno."'" ;
  if (mysqli_query($db, $sql)) {
      echo "Record deleted successfully";
  } else {
      echo "Error deleting record: " . mysqli_error($db);
  }
}

if ($work=="deleteclass") {
    $sql = "drop table ".$cid."_metadata";
    mysqli_query($db,$sql);
    
    $sql= "drop table ".$cid."_result";
    mysqli_query($db,$sql);
    
    $cid=ltrim($cid,'c');
    $sql="delete from classroom where c_id = '$cid'";
    mysqli_query($db,$sql);
    
    $sql="delete from clasroomstud where classroom_id='".$cid."'";
    mysqli_query($db,$sql);
    echo "successfully deleted classRoom\n";
}

?>