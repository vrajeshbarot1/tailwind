<?php 
	 session_start();
	 $who=$_SESSION['who'];
	 if($who=='student' || $who=='')
	  echo "<script>parent.location.reload();</script>";
	$txtname=$_GET['x'];
?>	
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/css/mdb.min.css" rel="stylesheet">
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/js/mdb.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/bootstrap-clockpicker.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/jquery-clockpicker.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/bootstrap-clockpicker.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/jquery-clockpicker.min.js"></script>


	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	  <style type="text/css">
    .container{
      background-color: #f1f1f1;
    }
    #heading{
      padding: 20px 0px 20px 0px;
      border-bottom: 1px solid #f1f1f1;
    }
    .head-part{
      background-color: #fff;
      box-shadow: 1px 1px 2px 3px #f1f1f1;
      border-radius: 0px 0px 10px 10px;
      margin-bottom: 30px;
    }
    .start-time{
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #f1f1f1;
    }
    .end-time{
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #f1f1f1;
    }
   input,textarea{
  display: block;
  width: 100%;
  border: 0;
  padding: 10px 5px;
  background: white no-repeat;
  background-image: linear-gradient(to bottom, #0073e6, #0073e6), linear-gradient(to bottom, silver, silver);
  background-size: 0 2px, 100% 1px;
  background-position: 50% 100%, 50% 100%;
  transition: background-size 0.3s cubic-bezier(0.64, 0.09, 0.08, 1);
  background-color:transparent;
  transition: .3s;
   /*color: #fff; */
  font-size: 1.2em;
  letter-spacing: 1px;
  margin-bottom: 20px;
}

input:focus , textarea:focus{
  border:none;
  background-size: 100% 2px, 100% 1px;
  outline: none;
}
  </style>
</head>
<body>
	<div class="container">
		<div class="row head-part">
			<div class="col-12 ">
                <form id="questiondiv" action="addRetestQuestinPaper.php?x=<?php echo $txtname;?>" method="post" autocomplete="off">
					<div class="examinfo" >
	                  <center><h2 id="heading">Exam Timing <img src="assets/images/examclock.png" height="50px" width="50px"></h2></center>
	              <div class="row start-time">
	                  <div class="clock col-md-6"><label>Enter Date when Exam will be start</label><input type="date" name="dateWhenUpload" class="timinginput" id="timinginput" autocomplete="off"/></div>
	                  <div class="clock col-md-6 "><label>Enter Time when Exam will be start</label><input class="input-a timinginput" class="form-control" value="" name="timeWhenUpload" data-default="">
	                    <button type="button" class="btn button-a">Check the  minutes</button><button type="button" class="button-b btn ">Check the  hours</button></div>
	               </div>

	               <div class="row end-time">
	                  <div class="clock col-md-6"><label>Enter Date when Exam will be End</label><input type="date" name="dateWhenEnd" class="timinginput"></div>
	                  <div class="clock col-md-6"><label>Enter Time when Exam will be End</label><input class="input-b timinginput" class="form-control" value="" name="timeWhenEnd" data-default=""><button type="button" class=" btn button-c">Check the  minutes</button><button type="button" class="button-d
	                   btn ">Check the  hours</button></div>
	                </div>
	                <input type="text" name="subject" placeholder="Enter Subject Name">
	                   <br/>
	                   <br/>
	                   <br/>
	                   <br/>
		                <button class="btn btn-primary" type="submit"  id="finish" name="enter">Finish&nbsp;It</button>
	               </div>
				</div>
			</div>
	</form>
	</div>
</body>
<script type="text/javascript">
      //show clock
       var input = $('.input-a');
    input.clockpicker({
       autoclose: true,
        donetext: 'Done'
    });

    // Manual operations
    $('.button-a').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input.clockpicker('show')
                .clockpicker('toggleView', 'minutes');
    });
    $('.button-b').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input.clockpicker('show')
                .clockpicker('toggleView', 'hours');
    });
   
    var input2 = $('.input-b');
    input2.clockpicker({
       autoclose: true,
        donetext: 'Done'
    });
    // Manual operations
    $('.button-c').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input2.clockpicker('show')
                .clockpicker('toggleView', 'minutes');
    });
    $('.button-d').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input2.clockpicker('show')
                .clockpicker('toggleView', 'hours');
    });

     var input3 = $('.input-c');
    input3.clockpicker({
       autoclose: true,
        donetext: 'Done'
    });
    // Manual operations
    $('.button-e').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input3.clockpicker('show')
                .clockpicker('toggleView', 'minutes');
    });
    $('.button-f').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input3.clockpicker('show')
                .clockpicker('toggleView', 'hours');
    });

	window.onload = function()
	{
	    document.getElementById('timinginput').setAttribute('autocomplete', 'off');  // Here frmAccount indicates id of the form.
	}


</script>
</html>