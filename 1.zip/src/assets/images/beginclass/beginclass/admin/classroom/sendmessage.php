<?php
session_start();
date_default_timezone_set('Asia/Kolkata');
$date=date('D M Y H:i:s');
$time=1582000000000;
$filename=round(microtime(true) * 1000)-$time;

$f=$_POST['f'];
$m=$_POST['m'];
$m="admin:".$filename.":".$m;

$file=fopen("../../chats/".$f,'a');
fwrite($file,$m."\n");
fclose($file);
echo "sent";
?>