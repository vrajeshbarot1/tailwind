<?php 
	session_start();
	include '../../php/database.php';
	$who=$_SESSION["who"];
	$classRoomId=$_SESSION["classRoomId"];
	if($who=='student' || $who==''){
		echo "<script>parent.location.reload();</script>";
	}
	$txtName=$_GET['x'];
	$resultShow='0';
	$date_When_Upload=$_POST['dateWhenUpload'];
	$time_When_Upload=$_POST['timeWhenUpload'];

	$date_When_End=$_POST['dateWhenEnd'];
	$time_When_End=$_POST['timeWhenEnd'];
	$Upload_Time_And_Date=$date_When_Upload." ".$time_When_Upload.":00";
	$End_Time_And_Date=$date_When_End." ".$time_When_End.":00";

	$subject=$_POST['subject'];
	$ciphering = "AES-128-CTR"; 
	$iv_length = openssl_cipher_iv_length($ciphering); 
	$options = 0; 
	$encryption_iv = '1234567891011121'; 
	$encryption_key = "BeginClassForBeginners"; 

	$time=1582000000000;
	$filename=round(microtime(true) * 1000)-$time;    

	$myfile = fopen("../../paper/".$txtName.".txt","r")or die("Unable to open file!");
	$i=0;$myExamPaper=array();
	while(!feof($myfile)) {
		$line = fgets($myfile);
		if($i>2){
			   array_push($myExamPaper, $line);
			}
		$i++;
	}	

/*	$ciphering = "AES-128-CTR"; 
	$iv_length = openssl_cipher_iv_length($ciphering); 
	$options = 0; 
	$decryption_iv = '1234567891011121'; 
	$decryption_key = "BeginClassForBeginners"; 
	
	$string=openssl_decrypt ($myExamPaper[0], $ciphering,$decryption_key, $options, $decryption_iv);  
	echo $string;*/
	//
	echo $filename;
	$myfile = fopen("../../paper/".$filename.".txt","a")or die("Unable to open file!");
      $txt="Upload Time : ".$Upload_Time_And_Date;
	 $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
      fwrite($myfile,$txt.PHP_EOL);
      $txt="End Time : ".$End_Time_And_Date;
	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
      fwrite($myfile,$txt.PHP_EOL);
	  $txt="Subject : ".$subject;
	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
      fwrite($myfile,$txt.PHP_EOL);
	  for ($i=0; $i <count($myExamPaper); $i++) { 
	      fwrite($myfile,$myExamPaper[$i]);
	  }
	  $sql="create table if not exists ".$classRoomId."_metadata(txtname varchar(50),starttime varchar(50),endtime varchar(50),subject varchar(20),result varchar(5))";
		mysqli_query($db,$sql);
		$sql="insert into ".$classRoomId."_metadata values('".$filename."','".$Upload_Time_And_Date."','".$End_Time_And_Date."','".$subject."','0')";
		$result=mysqli_query($db,$sql);
		if($result)
		  {
		  echo "<script type='text/javascript'>alert('Successfully added');window.location.replace('CompletedExamsList.php');</script>";
		  }
		else {
		    echo "<script type='text/javascript'>alert('faild! something was wrong..');window.location.replace('CompletedExamsList.php');</script>";
		}

?>