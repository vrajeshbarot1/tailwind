<?php 
	session_start();
	if(!isset($_SESSION["userName"])){
		header("location:index.php");
		exit;	
	}else{
	$myname=$_SESSION["userName"];
	$text =$_POST['text'];
	$key=$_POST['location'];
	$location=$_POST['location'];
	$key=$_SERVER['DOCUMENT_ROOT']."/admin/paper/".$key;
	if(!$key)
		echo "faild Update";
	file_put_contents($key,$text);
	 $myfile = fopen($key,"r")or die("Unable to open file!");
 	 $string=fgets($myfile);
     $manage=substr($string,0,strpos($string,':'));
     $getExamUploadTime="";
     $getExamUploadTime.=substr($string,strpos($string,":")+1,strlen($string));
      
     $string=fgets($myfile);
     $manage=substr($string,0,strpos($string,':'));
     $getExamEndTime="";
     $getExamEndTime.=substr($string,strpos($string,":")+1,strlen($string));
     $getExamEndTime=str_replace("_", " ", $getExamEndTime).":00";
     $getExamUploadTime=str_replace("_", " ", $getExamUploadTime).":00";

      $string=fgets($myfile);
      $timelimit='';
      $manage=substr($string,0,strpos($string,':'));
      $timelimit.=substr($string,strpos($string,":")+1,strlen($string));
      $timelimit= str_replace(PHP_EOL, '', $timelimit);
      
     $string=fgets($myfile);
     $subject='';
     $manage=substr($string,0,strpos($string,':'));
     $subject.=substr($string,strpos($string,":")+1,strlen($string));
     $subject= str_replace(PHP_EOL, '', $subject);
     include 'database.php';
    $sql = "update metadata set start_time='".$getExamUploadTime."', end_time='".$getExamEndTime."',name='".$subject."',time_limit='".$timelimit."' where txtname='".$location."'";
    //starting Time,end Time,txt file name,subject name
    $result=mysqli_query($db,$sql);
    if($result)
      {
     ?>   
        <script type="text/javascript">alert('successfully!! Data Update');
            window.close();</script>
     <?php
      }
    else {
            ?>   
        <script type="text/javascript">alert('faild Update Try Again!!');window.close();</script>
     <?php
    }
}	
?>