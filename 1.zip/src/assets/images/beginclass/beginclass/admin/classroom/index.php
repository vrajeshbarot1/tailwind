<?php 
	session_start();
	$who=$_SESSION['who'];
	if($who=='student' || $who=='')
		header('location:../../html/login.php');
	$id=$_GET['id'];
	include '../../php/database.php';
	if(!mysqli_query($db,'select * from c'.$id.'_metadata LIMIT 1')){
	    mysqli_query($db,"delete from classroom where c_id = '".$id."'");
	    mysqli_query($db,"delete from clasroomstud where classroom_id='".$id."'");
?>
<script>alert('This ClassRoom Data Not Available.\nPlease Admin page reload again..!\nOr Login Again.');window.close();</script>
<?php
	}
	else{
    	$name=$_GET['name'];
    	$_SESSION['classRoomShortName']=$name;
    	$_SESSION['classRoomId']='c'.$id;
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>ClassRoom</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Beginclass" />
    <meta name="keywords" content="Beginclass">
    <meta name="author" content="Beginclass" />
    <!-- vendor css -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    
<style type="text/css">
	.right-part{
		position: relative;
		height: calc(100vh - 65px);
		width: 100%;
		/*padding: 10px;*/
		border:none;
		overflow-x: hidden;
	}
</style>
</head>
<body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<!-- [ Pre-loader ] End -->
	<!-- [ navigation menu ] start -->
	<nav class="pcoded-navbar menupos-fixed menu-light ">
		<div class="navbar-wrapper  ">
			<div class="navbar-content scroll-div " >
				<ul class="nav pcoded-inner-navbar ">
					<li class="nav-item pcoded-menu-caption">
<!-- 						<label style="text-transform:uppercase;">NAVIGATION</label> -->
						<label style="text-transform:uppercase;">Examination</label>
					</li>
					<li class="nav-item active">
					    <a href="main.php" target="frm" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
					</li>
					<li class="nav-item">
					    <a href="addpaper.php" target="frm" class="nav-link"><span class="pcoded-micon"><i class="feather icon-plus-square"></i></span><span class="pcoded-mtext">Add Paper</span></a>
					</li>
					
					<li class="nav-item">
					    <a href="UpcomingExamsList.php" target="frm" class="nav-link"><span class="pcoded-micon"><i class="feather icon-sunset"></i></span><span class="pcoded-mtext">Upcoming Exams</span></a>
					</li>
					<li class="nav-item">
					    <a href="ActivatedExamsList.php" target="frm" class="nav-link"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Activated Exams </span></a>
					</li>
					<li class="nav-item">
					    <a href="CompletedExamsList.php" target="frm" class="nav-link"><span class="pcoded-micon"><i class="feather icon-pocket"></i></span><span class="pcoded-mtext">Completed Exams </span></a>
					</li>

					<li class="nav-item pcoded-menu-caption">
						<label style="text-transform: uppercase;"><?php echo $name."&nbsp;"; ?>conduct</label>
					</li>
					<li class="nav-item">
						<a href="resultShow.php" target="frm" class="nav-link"><span class="pcoded-micon"><i class="feather icon-file-text"></i></span><span class="pcoded-mtext">Result</span></a>
					</li>
					<li class="nav-item">
						<a href="myStudentList.php?n=<?php echo $name?>" target="frm" class="nav-link"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">My Students</span></a>
					</li>
					<li class="nav-item">
						<a href="showAllSubjects.php?n=<?php echo $name?>" target="frm" class="nav-link"><span class="pcoded-micon"><i class="feather icon-book"></i></span><span class="pcoded-mtext"><?php echo $name."&nbsp;"; ?> Subjects</span></a>
					</li>
					<li class="nav-item pcoded-menu-caption">
						<label style="text-transform: uppercase;">contivity</label>
					</li>
					<li class="nav-item">
						<a href="chatlist.php" target="frm" class="nav-link"><span class="pcoded-micon"><i class="feather icon-inbox"></i></span><span class="pcoded-mtext">Chat</span></a>
					</li>
				</ul>
				
<!-- 				<div class="card text-center">
					<div class="card-block">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						<i class="feather icon-sunset f-40"></i>
						<h6 class="mt-3">Help?</h6>
						<p>Please contact us on our email for need any support</p>
						<a href="#!" target="_blank" class="btn btn-primary btn-sm text-white m-0">Support</a>
					</div>
				</div> -->
				
			</div>
		</div>
	</nav>
	<!-- [ navigation menu ] end -->
	<!-- [ Header ] start -->
	<header class="navbar pcoded-header navbar-expand-lg navbar-light headerpos-fixed header-blue">
		
			
				<div class="m-header">
					<a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
					<a href="#!" class="b-brand">
						<?php echo $name;?>
						<!-- ========   change your logo hear   ============ -->
<!-- 						<img src="assets/images/logo.png" alt="" class="logo">
						<img src="assets/images/logo-icon.png" alt="" class="logo-thumb"> -->
					</a>
					<a href="#!" class="mob-toggler">
						<i class="feather icon-more-vertical"></i>
					</a>
				</div>
				<div class="collapse navbar-collapse">
					<ul class="navbar-nav mr-auto">
						<li class="nav-item">
							<a href="#!" class="pop-search"><i class="feather icon-search"></i></a>
							<div class="search-bar">
								<input type="text" id="search" class="form-control border-0 shadow-none" placeholder="Search here">
								<button type="button" class="close" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						</li>
						<li class="nav-item">
							<a href="#!" class="full-screen" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>
						</li>
					</ul>
					<ul class="navbar-nav ml-auto">
						<li>
							<div class="dropdown drp-user">
								<a href="#!" class="dropdown-toggle" data-toggle="dropdown">
                                    <img src="../../img/login1.png" class="img-radius wid-35" alt="User-Profile-Image">
                                </a>
								<div class="dropdown-menu dropdown-menu-right profile-notification">
									<div class="pro-head">
										<img src="../../img/login1.png" class="img-radius" alt="User-Profile-Image">
										<span style="text-transform: uppercase;"><?php echo $who;?></span>
										<a onclick="function tp(){window.close();}tp();" class="dud-logout" title="Logout">
											<i class="feather icon-log-out"></i>
										</a>
									</div>
									<?php 
									    if($who=='admin'){
									?>
									<div class="pro-head">
                                        <span style="text-transform: uppercase;">Delete ClassRoom</span>
										<button onclick="deleteclass()" id="deleclass" class='btn btn-danger dud-logout'style="width:70px;right:5px;padding-right:inherit;height:auto;" >Delete</button>
									</div>
									<?php
									    }
									?>
									<!-- <ul class="pro-body">
										<li><a href="user-profile.html" class="dropdown-item"><i class="feather icon-user"></i> Profile</a></li>
										<li><a href="email_inbox.html" class="dropdown-item"><i class="feather icon-mail"></i> My Messages</a></li>
										<li><a href="auth-signin.html" class="dropdown-item"><i class="feather icon-lock"></i> Lock Screen</a></li>
									</ul> -->
								</div>
							</div>
						</li>
					</ul>
				</div>
				
			
	</header>
	<!-- [ Header ] end -->
	
	

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
               <!-- [ Main Content ] end -->
    <iframe src="main.php" class="right-part" name="frm" frameborder="0" ></iframe>
</div>
<!-- [ Main Content ] end -->
    <!-- Warning Section start -->
    <!-- Older IE warning message -->
    <!--[if lt IE 11]>
        <div class="ie-warning">
            <h1>Warning!!</h1>
            <p>You are using an outdated version of Internet Explorer, please upgrade
               <br/>to any of the following web browsers to access this website.
            </p>
            <div class="iew-container">
                <ul class="iew-download">
                    <li>
                        <a href="http://www.google.com/chrome/">
                            <img src="assets/images/browser/chrome.png" alt="Chrome">
                            <div>Chrome</div>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.mozilla.org/en-US/firefox/new/">
                            <img src="assets/images/browser/firefox.png" alt="Firefox">
                            <div>Firefox</div>
                        </a>
                    </li>
                    <li>
                        <a href="http://www.opera.com">
                            <img src="assets/images/browser/opera.png" alt="Opera">
                            <div>Opera</div>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.apple.com/safari/">
                            <img src="assets/images/browser/safari.png" alt="Safari">
                            <div>Safari</div>
                        </a>
                    </li>
                    <li>
                        <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                            <img src="assets/images/browser/ie.png" alt="">
                            <div>IE (11 & above)</div>
                        </a>
                    </li>
                </ul>
            </div>
            <p>Sorry for the inconvenience!</p>
        </div>
    <![endif]-->
    <!-- Warning Section Ends -->

    <!-- Required Js -->
    <script src="assets/js/vendor-all.min.js"></script>
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <script src="assets/js/pcoded.min.js"></script>

<!-- Apex Chart -->
<script src="assets/js/plugins/apexcharts.min.js"></script>


<!-- custom-chart js -->
<script src="assets/js/pages/dashboard-main.js"></script>

<script type="text/javascript">
	function fu2n(){window.close();}
	var search=document.getElementById('search');
	
	$('.nav li').on('click', function(){
    $('.nav li.active').removeClass('active');
    $(this).addClass('active');
    if(window.innerWidth< 600){
        $('#mobile-collapse').click();
       // alert('hi');
    }
});
function deleteclass(){
  //$("#deleclass").html('Please Wait...');
  //$("#deleclass").prop('disabled', true);
  if(confirm('Are you sure for delete <?php echo $name; ?> classroom ?')){
     $.ajax({
      url:'ajax.php',
      data:{
          work:'deleteclass',
      },
      type:"POST",
      success:function(a,b){
          alert(a+"Please Admin page reload again..!");
          window.close();
      }
  });
  }
}
</script>
</body>

</html>
