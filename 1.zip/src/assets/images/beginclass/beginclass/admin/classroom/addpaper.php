<?php 
	session_start();
	$who=$_SESSION['who'];
	if($who=='student' || $who=='')
		echo "<script>parent.location.reload();</script>";
?>	
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
  <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/css/mdb.min.css" rel="stylesheet">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/js/mdb.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/bootstrap-clockpicker.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/jquery-clockpicker.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/bootstrap-clockpicker.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/jquery-clockpicker.min.js"></script>


  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <style type="text/css">
    .container{
      background-color: #f1f1f1;
    }
    #heading{
      padding: 20px 0px 20px 0px;
      border-bottom: 1px solid #f1f1f1;
    }
    .head-part{
      background-color: #fff;
      box-shadow: 1px 1px 2px 3px #f1f1f1;
      border-radius: 0px 0px 10px 10px;
      margin-bottom: 30px;
    }
    .start-time{
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #f1f1f1;
    }
    .end-time{
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #f1f1f1;
    }
   input,textarea{
  display: block;
  width: 100%;
  border: 0;
  padding: 10px 5px;
  background: white no-repeat;
  background-image: linear-gradient(to bottom, #0073e6, #0073e6), linear-gradient(to bottom, silver, silver);
  background-size: 0 2px, 100% 1px;
  background-position: 50% 100%, 50% 100%;
  transition: background-size 0.3s cubic-bezier(0.64, 0.09, 0.08, 1);
  background-color:transparent;
  transition: .3s;
   /*color: #fff; */
  font-size: 1.2em;
  letter-spacing: 1px;
  margin-bottom: 20px;
}

input:focus , textarea:focus{
  border:none;
  background-size: 100% 2px, 100% 1px;
  outline: none;
}
  </style>
</head>
<body>
  <div class="container">
    <div class="row head-part">
      <div class="col-12 ">
                <form id="questiondiv" action="QustionUpload.php" method="post" autocomplete="off">
          <div class="examinfo" >
                    <center><h2 id="heading">Exam Timing <img src="assets/images/examclock.png" height="50px" width="50px"></h2></center>
                <div class="row start-time">
                    <div class="clock col-md-6"><label>Enter Date when Exam will be start</label><input type="date" name="dateWhenUpload" class="timinginput" id="timinginput" autocomplete="off"/></div>
                    <div class="clock col-md-6 "><label>Enter Time when Exam will be start</label><input class="input-a timinginput" class="form-control" value="" name="timeWhenUpload" data-default="">
                      <button type="button" class="btn button-a">Check the  minutes</button><button type="button" class="button-b btn ">Check the  hours</button></div>
                 </div>

                 <div class="row end-time">
                    <div class="clock col-md-6"><label>Enter Date when Exam will be End</label><input type="date" name="dateWhenEnd" class="timinginput"></div>
                    <div class="clock col-md-6"><label>Enter Time when Exam will be End</label><input class="input-b timinginput" class="form-control" value="" name="timeWhenEnd" data-default=""><button type="button" class=" btn button-c">Check the  minutes</button><button type="button" class="button-d
                     btn ">Check the  hours</button></div>
                  </div>
                     <br/>
                     <br/>
                     subject :<input type="text" name="subject">
                     <br/>
                     <br/>
                  <input type="hidden" name="noqus" id="noqus">
                 </div>
          <div class="col-12" id="txthere"></div>
        </div>
        
      </div>
      <div class="row">
      </div>
      <div class="col-12" id="tp"></div>
    <div class="row">
      <div class="col-md-2 col-12">
        <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" id="type" onsubmit="fun()" >
          <option  value="none">Question Type</option>
          <option value="radio">Radio Button</option>
          <option value="checkbox">Checkbox</option>
          <option value="written">Written</option>
        </select>
      </div>
      <div class="col-md-2 col-5">
        <div class="btn btn-danger" onclick="removeLast()">Remove</div>
      </div>
      <div class="col-md-2 col-5">
                <button class="btn btn-primary" type="submit"  id="finish" name="enter">Finish&nbsp;It</button>
      </div>
    </div>
  </form>
  </div>
</body>

<script type="text/javascript">
	var arr=[];	
	i=0,count=0;
	var container=document.getElementById('txthere');
	var noqus=document.getElementById('noqus');
	var finishbutton=document.getElementById('finish');
	if(i==0)
			finishbutton.disabled=true;
		else
			finishbutton.disabled=false;

	$('select').on('click', function() {
		var selectValue = $(this).val();
		var z = document.createElement('div'); 
		if(selectValue=='radio'){	
			var str='<span id="delete'+i+'"><h3 class="mt-3"><center><h3>Question&nbsp;'+(i+1) +'&nbsp;</h3></center></h3><div class="m-4 box" style="background-color:none;"><div class="form-group"><label class="que">Enter your question here</label><textarea required name="mainQuation'+i+'" rows="3" cols="100" placeholder="Enter The Question" class="quefont" id="qus'+i+'"></textarea><input type="file" name="inputfile" id="inputfile'+i+'" class="inputfile" accept="image/*"><input type="number" name="marks'+i+'" id="marks" value="1" class="input-number marks quefont" placeholder="Enter marks" min="1" required></div><div class="form-group mt-2"><label>Option 1</label><textarea class="col-md-4 quefont" required name="option1'+i+'" id="option1'+i+'"   cols="20" placeholder="Option 1"></textarea><input type="file" id="inputfileforoption1'+i+'" class="inputfileforoption" accept="image/*"><input type="radio" name="answer'+i+'" value="0"></div><div class="form-group mt-1"><label>Option 2</label><textarea placeholder="Option 2" class="col-md-4 quefont" required name="option2'+i+'" id="option2'+i+'"   cols="20"></textarea><input type="file" id="inputfileforoption2'+i+'" class="inputfileforoption" accept="image/*"><input type="radio" name="answer'+i+'" value="1"></div><div class="form-group mt-1"><label>Option 3</label><textarea placeholder="Option 3" class="col-md-4 quefont" required name="option3'+i+'" id="option3'+i+'"    cols="20"></textarea><input type="file" id="inputfileforoption3'+i+'" class="inputfileforoption" accept="image/*"><input type="radio" name="answer'+i+'" value="2"></div><div class="form-group mt-1"><label>Option 4</label><textarea placeholder="Option 4" class="col-md-4 quefont" required name="option4'+i+'" id="option4'+i+'"   cols="20"></textarea><input type="file" id="inputfileforoption4'+i+'" class="inputfileforoption" accept="image/*"><input type="radio" name="answer'+i+'" value="3"><input type="hidden" name="mytype'+i+'" value="radio"></div></span><br/></span><br/>\r\n';
          	z.innerHTML=str;
          	container.appendChild(z);
	        i++;
          	noqus.value=i;
	        count++;

	       }   
	       if(selectValue=='checkbox'){	
			var str='<span id="delete'+i+'"><h3 class="mt-3"><center><h3>Question&nbsp;'+(i+1) +'&nbsp;</h3></center></h3><div class="m-4 box" style="background-color:none;"><div class="form-group"><label class="que">Enter your question here</label><textarea required name="mainQuation'+i+'" rows="3" cols="100" placeholder="Enter The Question" class="quefont" id="qus'+i+'"></textarea><input type="file" name="inputfile" id="inputfile'+i+'" class="inputfile" accept="image/*"><input type="number" name="marks'+i+'" id="marks" value="1" class="input-number marks quefont" placeholder="Enter marks" min="1" required></div><div class="form-group mt-2"><label>Option 1</label><textarea class="col-md-4 quefont" required name="option1'+i+'" id="option1'+i+'" rows="1" cols="20" placeholder="Option 1"></textarea><input type="file" id="inputfileforoption1'+i+'" class="inputfileforoption" accept="image/*"><input type="checkbox" name="answer1'+i+'[]" value="0"></div><div class="form-group mt-1"><label>Option 2</label><textarea placeholder="Option 2" class="col-md-4 quefont" required name="option2'+i+'"  id="option2'+i+'" rows="1" cols="20"></textarea><input type="file" id="inputfileforoption2'+i+'" class="inputfileforoption" accept="image/*"><input type="checkbox" name="answer1'+i+'[]" value="1"></div><div class="form-group mt-1"><label>Option 3</label><textarea placeholder="Option 3" class="col-md-4 quefont" required name="option3'+i+'" id="option3'+i+'"rows="1" cols="20"></textarea><input type="file" id="inputfileforoption3'+i+'" class="inputfileforoption" accept="image/*"><input type="checkbox" name="answer1'+i+'[]" value="2"></div><div class="form-group mt-1"><label>Option 4</label><textarea placeholder="Option 4" class="col-md-4 quefont" required name="option4'+i+'" id="option4'+i+'" rows="1" cols="20"></textarea><input type="file" id="inputfileforoption4'+i+'" class="inputfileforoption" accept="image/*"><input type="checkbox" name="answer1'+i+'[]" value="3"><input type="hidden" name="mytype'+i+'" value="checkbox"></div></span><br/></span><br/>\r\n';
          	z.innerHTML=str;
          	container.appendChild(z);
	        i++;
          	noqus.value=i;
	        count++;
	       }
	       if(selectValue=='written'){	
			var str='<span id="delete'+i+'"><h3 class="mt-3"><center><h3>Question&nbsp;'+(i+1) +'&nbsp;</h3></center></h3><div class="m-4 box" style="background-color:none;"><div class="form-group"><label class="que">Enter your question here</label><textarea required name="mainQuation'+i+'" rows="3" cols="100" placeholder="Enter The Question" class="quefont" id="qus'+i+'"></textarea><input type="file" name="inputfile" id="inputfile'+i+'" class="inputfile" accept="image/*"><input type="number" name="marks'+i+'" id="marks" value="1" class="input-number marks quefont" placeholder="Enter marks" min="1" required><input type="hidden" name="mytype'+i+'" value="written"></div></span><br/></span><br/>\r\n';
          	z.innerHTML=str;
          	container.appendChild(z);
	        i++;
          	noqus.value=i;
	        count++;
	       }
       if(i==0)
			finishbutton.disabled=true;
		else
			finishbutton.disabled=false;

	 $('select').prop('selectedIndex', 0);		   	
	console.log(1);
	});

	function removeLast(){
	  console.log(i);
	  var item = document.getElementById(`delete${i-1}`);
	  item.parentNode.removeChild(item);
	  i--;
	  if(i==0)
			finishbutton.disabled=true;
		else
			finishbutton.disabled=false;
      noqus.value=i;
      return false;
	}

      //show clock
       var input = $('.input-a');
    input.clockpicker({
       autoclose: true,
        donetext: 'Done'
    });

    // Manual operations
    $('.button-a').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input.clockpicker('show')
                .clockpicker('toggleView', 'minutes');
    });
    $('.button-b').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input.clockpicker('show')
                .clockpicker('toggleView', 'hours');
    });
   
    var input2 = $('.input-b');
    input2.clockpicker({
       autoclose: true,
        donetext: 'Done'
    });
    // Manual operations
    $('.button-c').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input2.clockpicker('show')
                .clockpicker('toggleView', 'minutes');
    });
    $('.button-d').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input2.clockpicker('show')
                .clockpicker('toggleView', 'hours');
    });

     var input3 = $('.input-c');
    input3.clockpicker({
       autoclose: true,
        donetext: 'Done'
    });
    // Manual operations
    $('.button-e').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input3.clockpicker('show')
                .clockpicker('toggleView', 'minutes');
    });
    $('.button-f').click(function(e){
        // Have to stop propagation here
        e.stopPropagation();
        input3.clockpicker('show')
                .clockpicker('toggleView', 'hours');
    });

	window.onload = function()
	{
	    document.getElementById('timinginput').setAttribute('autocomplete', 'off');  // Here frmAccount indicates id of the form.
	}







 $(document.body).delegate(".inputfile","change",function(){
    var te=$(this).attr('id');
    console.log(te);
     var res=te.substr(9);
    tel= "#"+te;
          var file_data = $(tel).prop('files')[0];   
          var form_data = new FormData();                  
          form_data.append('file', file_data);
          $.ajax({
              url: "../../php/imageFileUpload.php",
              type: "POST",
              data: form_data,
              contentType: false,
              cache: false,
              processData:false,
              success: function(data){
                  //$(te).;
                  if(data.charAt(0)=='.'){
                    var idname="qus"+res;
                    var message=$("#"+idname).val();
                    message+='</xmp><img src="'+data+'" class="img-rounded" alt="Cinque Terre" width="404" height="236">';
                    document.getElementById(idname).value=message;
                    //console.log(message);
                  }
                  else{
                    //console.log(data);
                  }
              }
          }); 
      });
 $(document.body).delegate(".inputfileforoption","change",function(){
    var te=$(this).attr('id');
    var res=te.substr(18);
    tel= "#"+te;
          var file_data = $(tel).prop('files')[0];   
          var form_data = new FormData();                  
          form_data.append('file', file_data);
          $.ajax({
              url: "../../php/imageFileUpload.php",
              type: "POST",
              data: form_data,
              contentType: false,
              cache: false,
              processData:false,
              success: function(data){
                  //$(te).;
                  if(data.charAt(0)=='.'){
                    var idname="option"+res;
                    var message=$("#"+idname).val();
                    message+='</xmp><img src="'+data+'" class="img-rounded" alt="Cinque Terre" width="404" height="236">';
                    document.getElementById(idname).value=message;
                    //console.log(message);
                  }
                  else{
                    //console.log(data);
                  }
              }
          }); 
      });
</script>
</html>