<?php
	session_start();
	include '../../php/database.php';
	$who=$_SESSION["who"];
	$classRoomId=$_SESSION["classRoomId"];
	if($who=='student' || $who==''){
		echo "<script>parent.location.reload();</script>";
	}
    $numOfQus=$_POST["noqus"];
	if($numOfQus==0)
		header("location:addpaper.php");
	
	$subject=$_POST['subject'];
    $resultShow='0';
    $date_When_Upload=$_POST['dateWhenUpload'];
    $time_When_Upload=$_POST['timeWhenUpload'];

    $date_When_End=$_POST['dateWhenEnd'];
    $time_When_End=$_POST['timeWhenEnd'];
    $Upload_Time_And_Date=$date_When_Upload." ".$time_When_Upload.":00";
    $End_Time_And_Date=$date_When_End." ".$time_When_End.":00";


	$ciphering = "AES-128-CTR"; 
	$iv_length = openssl_cipher_iv_length($ciphering); 
	$options = 0; 
	$encryption_iv = '1234567891011121'; 
	$encryption_key = "BeginClassForBeginners"; 
  
// Use openssl_encrypt() function to encrypt the data 


	$time=1582000000000;
	$filename=round(microtime(true) * 1000)-$time;    
	$myfile = fopen("../../paper/".$filename.".txt","a")or die("Unable to open file!");
      $txt="Upload Time : ".$Upload_Time_And_Date.PHP_EOL;
	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
      
      fwrite($myfile,$txt.PHP_EOL);
      $txt="End Time : ".$End_Time_And_Date.PHP_EOL;
	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 

      fwrite($myfile,$txt.PHP_EOL);
      $txt="Subject : ".$subject .PHP_EOL;
	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 

      fwrite($myfile,$txt.PHP_EOL);
    for ($i=0;$i<$numOfQus;$i++) { 
	    if($_POST["mytype".$i]=='radio'){
      
	  	  $txt = openssl_encrypt('radio', $ciphering,$encryption_key, $options, $encryption_iv);
	      fwrite($myfile,$txt.PHP_EOL);

	      $qus=$_POST["mainQuation".$i];
	      $txt="Question_".($i+1).":".$qus.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $op1=$_POST["option1".$i];
	      $txt="Option_1: ".$op1.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $op2=$_POST["option2".$i];
	      $txt="Option_2: ".$op2.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $op3=$_POST["option3".$i];
	      $txt="Option_3: ".$op3.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);      
	      $op4=$_POST["option4".$i];
	      $txt="Option_4: ".$op4.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $ans=$_POST["answer".$i];
	      $txt="Answer_".($i+1).": ".$ans.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $marks=$_POST["marks".$i];
	      $txt="Question".($i+1)." marks: ".$marks.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv);      
      	if($i == ($numOfQus-1))
      		fwrite($myfile,$txt);
      	else
      		fwrite($myfile,$txt.PHP_EOL);  
	    }
	    if($_POST["mytype".$i]=='checkbox'){
	     
	      $txt = openssl_encrypt('checkbox', $ciphering,$encryption_key, $options, $encryption_iv);
	      fwrite($myfile,$txt.PHP_EOL);

	      $qus=$_POST["mainQuation".$i];
	      $txt="Question_".($i+1).":".$qus.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $op1=$_POST["option1".$i];
	      $txt="Option_1: ".$op1.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $op2=$_POST["option2".$i];
	      $txt="Option_2: ".$op2.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $op3=$_POST["option3".$i];
	      $txt="Option_3: ".$op3.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $op4=$_POST["option4".$i];
	      $txt="Option_4: ".$op4.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $ans=$_POST["answer1".$i];
	      $nowMyAns='';
	      foreach ($ans as $color){ 
			 $nowMyAns.=$color."-";
		  }
	      $txt="Answer_".($i+1).": ".$nowMyAns.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $marks=$_POST["marks".$i];
	      $txt="Question".($i+1)." marks: ".$marks.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
 		if($i == ($numOfQus-1))
      		fwrite($myfile,$txt);
      	else
      		fwrite($myfile,$txt.PHP_EOL);
	    }
	    if($_POST["mytype".$i]=='written'){

	      $txt = openssl_encrypt('written', $ciphering,$encryption_key, $options, $encryption_iv);
	      fwrite($myfile,$txt.PHP_EOL);
	      
	      $qus=$_POST["mainQuation".$i];
	  
	      $txt="Question_".($i+1).":".$qus.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $txt="Option_1: ".PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      $txt="Option_2: ".PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $txt="Option_3: ".PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 

	      fwrite($myfile,$txt.PHP_EOL);
	      $txt="Option_4: ".PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $txt="Answer_".($i+1).": ".PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	      
	      fwrite($myfile,$txt.PHP_EOL);
	      $marks=$_POST["marks".$i];
	      $txt="Question".($i+1)." marks: ".$marks.PHP_EOL;      
	  	  $txt = openssl_encrypt($txt, $ciphering,$encryption_key, $options, $encryption_iv); 
	    if($i == ($numOfQus-1))
      		fwrite($myfile,$txt);
      	else
      		fwrite($myfile,$txt.PHP_EOL);
	    }
    }

$sql="create table if not exists ".$classRoomId."_metadata(txtname varchar(50),starttime varchar(50),endtime varchar(50),subject varchar(20),result varchar(5))";
mysqli_query($db,$sql);
$sql="insert into ".$classRoomId."_metadata values('".$filename."','".$Upload_Time_And_Date."','".$End_Time_And_Date."','".$subject."','0')";
$result=mysqli_query($db,$sql);
if($result)
  {
  echo "<script type='text/javascript'>alert('Successfully added');window.location.replace('addpaper.php');</script>";
  }
else {
    echo "<script type='text/javascript'>alert('faild! something was wrong..');window.location.replace('addpaper.php');</script>";
}

?>