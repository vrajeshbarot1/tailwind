<?php 
	session_start();
	$who=$_SESSION['who'];
	if($who!='student' || $who=='')
		echo "<script>parent.location.reload();</script>";
		//header('location:../../html/login.php');
	$id=$_SESSION['classRoomId'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<br/>
	<br/>
	<div class="content-wrapper">
        <div class="pendingpapers">
          <center><h1>Upcoming Exams :-</h1>
            <br/>
          <div class="ul"></div></center>
          <div class="table-responsive">
            <table class="table" id="pendingtable"></table>
          </div>
        </div>          
    </div>
</body>
<script type="text/javascript">
	var check=[],forloopvalue=0,searchnum=0,tablenumber=0;
      var table1=document.getElementById('pendingtable');
      function tabl(num){
        if(num==1)
          table1.innerHTML='<tr><th>No.</th><th>Exam Name</th><th>Start Time</th><th>View</th></tr>';
      }
      window.parent.search.addEventListener('keyup',function(e){
          var input;
          input = window.parent.search;
          tabl(tablenumber);
          for(var i=0,tmp=1;i<check.length;i++){
              var found=false;
              for(var j=0;j<check[i].length;j++){
                if(typeof(check[i][j])=="string")
                  if(check[i][j].toLowerCase().indexOf(input.value.toLowerCase())>=0)found=true;
            }
            if(found){
              var roo="<tr>";
              roo+="<td>"+(tmp++)+"</td>";
              for(var k=1;k<=forloopvalue;k++){
                  if(typeof(check[i][k])=="string" && k<=searchnum){
                    var indx=check[i][k].toLowerCase().indexOf(input.value.toLowerCase());
                  if(indx>=0){
                    var str=check[i][k].substr(0,indx);
                    str+='<span style="background-color:#ff9632;">'+check[i][k].substr(indx,input.value.length)+'</span>';
                    str+=check[i][k].substr(indx+input.value.length);
                    roo+="<td>"+str+"</td>";
                  }else
                    roo+="<td>"+check[i][k]+"</td>";
                  }else
                    roo+="<td>"+check[i][k]+"</td>";
              }
              roo+="</tr>";
              if(tablenumber==1)
                table1.innerHTML=table1.innerHTML+roo;
          }
        }
      });
       function myFunction(loopvalue,tabnum){
          var input;
          input = window.parent.search;
          tabl(tabnum);
          for(var i=0,tmp=1;i<check.length;i++){
            var found=false;
            for(var j=0;j<check[i].length;j++){
              if(typeof(check[i][j])=="string")
                if(check[i][j].toLowerCase().indexOf(input.value.toLowerCase())>=0)found=true;
          }
          if(found){
            var roo="<tr>";
            roo+="<td>"+(tmp++)+"</td>";
            for(var k=1;k<=loopvalue;k++){
                if(typeof(check[i][k])=="string" && k<=4){
                  var indx=check[i][k].toLowerCase().indexOf(input.value.toLowerCase());
                if(indx>=0){
                  var str=check[i][k].substr(0,indx);
                  str+='<span style="background-color:#2c89f8;">'+check[i][k].substr(indx,input.value.length)+'</span>';
                  str+=check[i][k].substr(indx+input.value.length);
                  roo+="<td>"+str+"</td>";
                }else
                  roo+="<td>"+check[i][k]+"</td>";
                }else
                  roo+="<td>"+check[i][k]+"</td>";
            }
            roo+="</tr>";
            if(tabnum==1)
              table1.innerHTML=table1.innerHTML+roo;
          }
        }
    }
   

    $(document).ready(function(){
        forloopvalue=3;
        searchnum=2;
        tablenumber=1;
        check=[];
        tabl(1);
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {  
              if (this.readyState == 4 && this.status == 200) {
                var obj=JSON.parse(this.responseText);
                for (var i = 0; i < obj.length; i++){
                  var row = table1.insertRow(0);
                  check[i]=[];
                  check[i][0]=i+1;
                  check[i][1]=obj[i].subject;
                  check[i][2]=obj[i].uploadtime;
                 // check[i][3]=obj[i].endtime;
                  var viewpaper=`<button type="submit" onclick="quspopen('<?php echo $_SESSION['uid'];?>','${obj[i].txtlocation}')" class="btn btn-info">Enter</button>`;
                  check[i][3]=viewpaper;
                }
                myFunction(3,1);
              }
          };
          xmlhttp.open("POST", "ajax.php", true);
          xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
          xmlhttp.send("work=Pending");
      });
  function quspopen(e,v){
         window.open('questionPaper.php?d='+v+"-"+e); 
  } 
</script>
</html>