<?php 
  session_start();
  include '../php/database.php';
  $who=$_SESSION['who'];
  if($who!='student' || $who=='')
    echo "<script>parent.location.reload();</script>";
  $work=$_POST['work'];
  $cid=$_SESSION['classRoomId'];
  $who=$_SESSION['who'];
  date_default_timezone_set('Asia/Kolkata');
  $now=date('Y-m-d H:i:s');
 
  if ($work=="Pending") {
    $sql="select * from ".$cid."_metadata where starttime >'".$now."' order by txtname desc";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        $all=array();
        while($row = mysqli_fetch_assoc($result)) {
          $ar=array('txtlocation'=>$row['txtname'],'uploadtime'=>$row['starttime'] ,'endtime'=>$row['endtime'] ,'who'=>$who,'subject'=>$row['subject'],'devicetime'=>$now);
          array_push($all,$ar);
        }
        echo json_encode($all);
    }else echo "";
}
if($work=="activate"){
    $sql="select * from ".$cid."_metadata where '".$now."' > starttime and '".$now."'< endtime order by txtname desc";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        $all=array();
        while($row = mysqli_fetch_assoc($result)) {
            $ar=array('txtlocation'=>$row['txtname'],'uploadtime'=>$row['starttime'] ,'endtime'=>$row['endtime'] ,'who'=>$who,'subject'=>$row['subject'],'devicetime'=>$now);
          array_push($all,$ar);
        }
        echo json_encode($all);
    }else echo "";
}
if($work=="complete"){
     $sql="select * from ".$cid."_metadata where endtime <'".$now."' order by txtname desc";
      $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        $all=array();
        while($row = mysqli_fetch_assoc($result)) {
          $ar=array('resultnum'=>$row['result'],'txtlocation'=>$row['txtname'],'uploadtime'=>$row['starttime'] ,'endtime'=>$row['endtime'] ,'who'=>$who,'subject'=>$row['subject'],'devicetime'=>$now);
          array_push($all,$ar);
        }
        echo json_encode($all);
    }else echo "";
}

?>