<?php 
	session_start();
	$who=$_SESSION['who'];
	if($who!='student' || $who=='')
		echo "<script>parent.location.reload();</script>";
		//header('location:../../html/login.php');
	$id=$_SESSION['classRoomId'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/css/mdb.min.css" rel="stylesheet">
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/js/mdb.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Comfortaa&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../css/AccountSetting.css">
</head>
<body>
	<br/>
	<br/>
	<br/>
	<br/>
	<div class="container outside">
			<center><h1>The Points To Be Read Before Examination</h1></center>
			<div class="form-group purple-border">
			  <textarea class="form-control" id="temscondi" style="font-size: 15pt;margin-top: 8vh;resize: none;background-color: white;font-family: sans-serif;" rows="20" readonly>

-> If any activity is observed outside the examination tab then the exam will be cancelled and the attempted examination will be considered as the final submition.

-> If any miscief willl be observed then the a email will be forwarded to the parental E-mail id accordind to the performed task.

-> Results , examination timing and other activities will be e mailed to parental E-mail id.

-> If the examination is halted by mistake then the admin has the authority to revoke the examination.

-> The examinar will have total access over the students and will be in complete attentiion thus any kind of theft(cheating) will not be tolareted.

-> After the examination is over the attained doughts can be clarified with the given chat option.

-> Duringthe examination if any call is awaked then the examination will be stoped thus please take care (priortise using wifi).

-> In the subjective examinaton the option of uploding answer pictures will be provided.

-> In the post examinatioon stage the admin will uplod the results and can be seen on the students acoount.

-> The marking scale will be provided on the right handside of the questions.

-> If any codes are used in other place then copy right strike will be claimed.

-> If there will be  weak network then the submitionn might not occur and authorities  will not be responsible.
</textarea>
<br/>
<div class="row">
	<div class="col-md-10">
		<input type="checkbox" name="" >&nbsp;&nbsp;I agree all points to be read before examination
		<br/>
		<br/>
	</div>
	<div class="col-md-2">
		<center><button id="enter" onclick="enterExam()" class="btn btn-primary" style="font-size: 12pt;">Enter</button></center>
	</div>
</div>
</div>		
</div>


<script type="text/javascript">
	document.getElementById('enter').disabled=true;
	$('input[type="checkbox"]').click(function(){
		$('#enter').prop('disabled', function(i, v) { return !v; });
	})
	function enterExam(){
		location.replace('questionPaper.php?d=<?php echo $_GET["d"];?>');
	}
</script>
</body>
</html>