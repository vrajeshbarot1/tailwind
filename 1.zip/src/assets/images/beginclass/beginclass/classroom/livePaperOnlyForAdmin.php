<?php 
	$count=1;
	$ciphering = "AES-128-CTR"; 
	$iv_length = openssl_cipher_iv_length($ciphering); 
	$options = 0; 
	$decryption_iv = '1234567891011121'; 
	$decryption_key = "BeginClassForBeginners"; 
	
	$string=fgets($myfile);
	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
	//echo $string."<br/>";
	
	$string=fgets($myfile);
	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
	//echo $string."<br/>";
	$subjectName='';
	$string=fgets($myfile);
	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
	$subjectName.=substr($string,strpos($string,":")+1,strlen($string));
	//echo $subjectName;
    
    class mcq{
	    var $q;
	    var $a;
	    var $Smarks;
	    var $id;
      var $qusTy;
	    var $myAns;
	    function __construct(){
	      $this->a=array();
	    }
     }
	    $allmcq=array();
	    $j=0;
    while(!feof($myfile)){
	      $x=new mcq;
	      $mcqcount=0;
	      $x->id=$count;
	      $qusType="";
	      $string=fgets($myfile);
		  $qusType=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);
          $x->qusTy=$qusType;
          $string=fgets($myfile);
		  $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);
		  $qus="";
          $manage=substr($string,0,strpos($string,":"));
          for($i=0;$manage!="Option_1";$i++){ 
                $qus.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
          $qus=rtrim($qus,"<br/>");
          $x->q=$qus;

          $op1="";
          $manage=substr($string,0,strpos($string,":"));
          for($i=0;$manage!="Option_2";$i++){ 
                $op1.=substr($string,strpos($string,":")+1,strlen($string))."<br/>"; 
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
           $op1=rtrim($op1,"<br/>");
           $op11=preg_replace('/\s/', '', $op1);
           $x->a["$mcqcount"]=$op1;
           $mcqcount++;

          $op2="";
          $manage=substr($string,0,strpos($string,":"));
          for($i=0;$manage!="Option_3";$i++){ 
                $op2.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
           $op2=rtrim($op2,"<br/>");
           $op22= preg_replace('/\s/', '', $op2);
           $x->a["$mcqcount"]=$op2;
           $mcqcount++;

    	  $op3="";
          $manage=substr($string,0,strpos($string,":"));
          for($i=0;$manage!="Option_4";$i++){ 
                $op3.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
           $op3=rtrim($op3,"<br/>");
           $op33= preg_replace('/\s/', '', $op3);
           $x->a["$mcqcount"]=$op3;
           $mcqcount++;


          $op4="";
          $manage=substr($string,0,strpos($string,":"));

          for($i=0;$manage!="Answer_".$count;$i++){ 
                $op4.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
           $op4=rtrim($op4,"<br/>");
           $op44= preg_replace('/\s/', '', $op4);
           $x->a["$mcqcount"]=$op4;
           $mcqcount++;
           
          $answer=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
	        $answer=rtrim($answer,"<br/>");
          $answer= preg_replace('/\s/', '', $answer);
          $x->myAns=$answer;
          //ans ayiya 6


          $string=fgets($myfile);
		      $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
           $manage=substr($string,0,strpos($string,":"));
           $marks='';
           $marks.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
           $marks=rtrim($marks,"<br/>");
           $marks=preg_replace('/\s/', '', $marks);
          $count++;
          $x->Smarks=$marks;
          array_push($allmcq,$x);
    }
       //shuffle($allmcq);
?>
<p id="demo"></p> 
    <form action="resultCalculate.php" id="myForm" method="post">
    <div class="headerarea">
      <div class="header">
        <input type="hidden" value="<?php echo $txtLocation;?>" name="texname">
        <h1 class="subjectname"><?php echo strtoupper($subjectName);?></h1>
      </div>
    </div>
      <div class="allCaintain">
          <?php 
          for($i=0;$i<sizeof($allmcq);$i++){
            // correct msq must put 0-3
            $suffarr=array(0,1,2,3);
           // $key1s = array_keys($x->a);
            $op11=$suffarr[0];
            $op22=$suffarr[1];
            $op33=$suffarr[2];
            $op44=$suffarr[3];
            $marksCount="marks".($i+1);
            if($allmcq[$i]->qusTy=='radio'){
           ?>
           <div class="fullMcq col-md-9">
            <div class="qustion" style="color: grey;">Question <?php echo ($i+1).":";?> <b style="color: rgb(0,0,0);"><?php echo "  ".$allmcq[$i]->q; ?></b></div><br/>
           <span class="marks"><b><?php echo $allmcq[$i]->Smarks;?>&nbsp; Marks <== </b></span><br/>
           
           <label class="container"><?php echo $allmcq[$i]->a[$suffarr[0]];?>
              <input type="radio" name="<?php echo "option".$allmcq[$i]->id; ?>" class="op1" value="<?php echo "$op11";?>" <?php ($allmcq[$i]->myAns==0)?print('checked'):print(''); ?> >
              <span class="checkmark opsp1"></span><br/>
            </label>

            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[1]];?>
              <input type="radio" name="<?php echo "option".$allmcq[$i]->id; ?>" class="op2" value="<?php echo $op22;?>" <?php ($allmcq[$i]->myAns==1)?print('checked'):print('');?>>
              <span class="checkmark opsp2"></span><br/>
            </label>
            
            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[2]];?>
              <input type="radio" name="<?php echo "option".$allmcq[$i]->id; ?>" class="op3" value="<?php echo $op33;?>" <?php ($allmcq[$i]->myAns==2)?print('checked'):print('');?> >
              <span class="checkmark opsp3"></span><br/>
            </label>
            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[3]];?>
              <input type="radio" name="<?php echo "option".$allmcq[$i]->id; ?>" class="op4" value="<?php echo $op44;?>" <?php ($allmcq[$i]->myAns==3)?print('checked'):print('');?> >
              <span class="checkmark opsp4"></span><br/>
            </label> 
            <hr>
        </div>
        <?php
          }
          if($allmcq[$i]->qusTy=='checkbox'){
            $tempans=explode('-', $allmcq[$i]->myAns);
            $xx=count($tempans);
        ?>
      <div class="fullMcq col-md-9">
           <div class="qustion" style="color: grey;">Question <?php echo ($i+1).":";?> <b style="color: rgb(0,0,0);"><?php echo "  ".$allmcq[$i]->q; ?></b></div><br/>
           <span class="marks"><b><?php echo $allmcq[$i]->Smarks;?>&nbsp; Marks <== </b></span><br/>
           
           <label class="container"><?php echo $allmcq[$i]->a[$suffarr[0]];?>
              <input type="checkbox" name="<?php echo "option".$allmcq[$i]->id; ?>[]" class="op1" value="<?php echo $op11;?>" <?php for($x=0;$x<$xx;$x++){if($tempans[$x]=== '0')echo 'checked';} ?> >
              <span class="checkmark opsp1"></span><br/>
            </label>

            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[1]];?>
              <input type="checkbox" name="<?php echo "option".$allmcq[$i]->id; ?>[]" class="op2" value="<?php echo $op22;?>" <?php for($x=0;$x<$xx;$x++){if($tempans[$x]==1)echo 'checked';} ?>>
              <span class="checkmark opsp2"></span><br/>
            </label>
            
            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[2]];?>
              <input type="checkbox" name="<?php echo "option".$allmcq[$i]->id; ?>[]" class="op3" value="<?php echo $op33;?>" <?php for($x=0;$x<$xx;$x++){if($tempans[$x]==2)echo 'checked';} ?>>
              <span class="checkmark opsp3"></span><br/>
            </label>
            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[3]];?>
              <input type="checkbox" name="<?php echo "option".$allmcq[$i]->id; ?>[]" class="op4" value="<?php echo $op44;?>" <?php for($x=0;$x<$xx;$x++){if($tempans[$x]==3)echo 'checked';} ?>>
              <span class="checkmark opsp4"></span><br/>
            </label> 
            <hr>
          </div>
        <?php
          }
          if($allmcq[$i]->qusTy=='written'){
        ?>
      <div class="fullMcq col-md-9">
           <div class="qustion" style="color: grey;">Question <?php echo ($i+1).":";?> <b style="color: rgb(0,0,0);"><?php echo "  ".$allmcq[$i]->q; ?></b></div><br/>
           <span class="marks"><b><?php echo $allmcq[$i]->Smarks;?>&nbsp; Marks <== </b></span><br/>
           
           <label class="container"><?php echo $allmcq[$i]->a[$suffarr[0]]; echo "<br/>".$allmcq[$i]->myAns;?>
           <p>`Written Question`</p>
<!---             <input type="file" name="" class="inputfile" id="inputfile<?php //echo $i+1;?>" onclick="fun()">

             <textarea  name="<?php //echo "option".$allmcq[$i]->id; ?>" rows="3" style="width: 100%;" placeholder="Enter The Question" class="quefont" id="qus<?php //echo $i+1;?>"></textarea> -->
           </label>
            <hr>
        </div>    
        <?php
          }  
          } 
          //arsort($allmcq->a);
          shuffle($allmcq);
        ?>
 <script type="text/javascript">
              //var countDownDate = new Date('<?php //echo $ed;?>').getTime();
  var countDownDate = new Date('<?php echo $ed;?>').getTime();  
  var x = setInterval(function() {
    var now = new Date().getTime();
    var distance = countDownDate-now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    if(days==0 && hours==0)
    document.getElementById("demo").innerHTML =  minutes + "m : " + seconds + "s ";
    else
    document.getElementById("demo").innerHTML = days + "d : " + hours + "h : "
    + minutes + "m : " + seconds + "s ";
    if (distance < 0) {
      clearInterval(x);
      document.getElementById("demo").innerHTML = "Exam Over You Have To Click On Submit Button";
      $('input[type=radio]').prop("disabled", true );
      $('input[type=checkbox]').prop("disabled", true );
      $('textarea').prop('disabled', true);;
    }
  }, 1000);

 </script> 
 <script type="text/javascript">
  $(document.body).delegate(".inputfile","change",function(){
    var te=$(this).attr('id');
    console.log(te);
     var res=te.substr(9);
    tel= "#"+te;
          var file_data = $(tel).prop('files')[0];   
          var form_data = new FormData();                  
          form_data.append('file', file_data);
          $.ajax({
              url: "../php/imageFileUpload.php",
              type: "POST",
              data: form_data,
              contentType: false,
              cache: false,
              processData:false,
              success: function(data){
                  //$(te).;
                  if(data.charAt(0)=='.'){
                    var idname="qus"+res;
                    var message=$("#"+idname).val();
                    message+='</xmp><img src="'+data+'" class="img-rounded" alt="Cinque Terre" width="404" height="236">';
                    document.getElementById(idname).value=message;
                    console.log(message);
                  }
                  else{
                    console.log(data);
                  }
              }
          }); 
      });
</script>