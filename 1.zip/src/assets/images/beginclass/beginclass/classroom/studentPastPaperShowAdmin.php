<?php 
    $sql="create table if not exists ".$cid."_result(u_phono varchar(20),txtname varchar(40),my_marks varchar(50),result text)";
    mysqli_query($db,$sql);
    $mymobileNo=$myid;
   $sqlfrometatime="select * from ".$classRoomId."_result where txtname ='".$txtLocation."' and u_phono ='".$mymobileNo."'";
   $listup = mysqli_query($db,$sqlfrometatime);
    if(mysqli_num_rows($listup) > 0) {
       while($row = mysqli_fetch_assoc($listup)) {
         $myMarks=$row['my_marks'];
         $resultObject=$row['result'];
       }
    }
    if(isset($p[3])){
      if($p[3]=='edit'){
      
        echo "<br/><br/><br/><center><h1>".$myName." Result is :- ".$myMarks."</h1><br/><button  class='btn btn-primary' onclick='getGoBack()'>Back</button></center>";
      }
    else
      echo "<br/><br/><br/><center><h1>".$myName." Result is :- ".$myMarks."</h1><br/><button onclick='getText()' class='btn btn-primary'>Submit</button></center>";
    }else
      echo "<br/><br/><br/><center><h1>".$myName." Result is :- ".$myMarks."</h1><br/><button onclick='getText()' class='btn btn-primary'>Submit</button></center>";
    

    $jsputMarks=explode('/',$myMarks);
    $realResult=explode('<<>!<>>', $resultObject);
    //print_r($realResult);
  $count=1;
	$ciphering = "AES-128-CTR"; 
	$iv_length = openssl_cipher_iv_length($ciphering); 
	$options = 0; 
	$decryption_iv = '1234567891011121'; 
	$decryption_key = "BeginClassForBeginners"; 
	
	$string=fgets($myfile);
	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
	//echo $string."<br/>";
	
	$string=fgets($myfile);
	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
	//echo $string."<br/>";
	$subjectName='';
	$string=fgets($myfile);
	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
	$subjectName.=substr($string,strpos($string,":")+1,strlen($string));
	//echo $subjectName;
    
    class mcq{
	    var $q;
	    var $a;
	    var $Smarks;
	    var $id;
	    var $qusTy;
	    function __construct(){
	      $this->a=array();
	    }
     }
	    $allmcq=array();
	    $j=0;
    while(!feof($myfile)){
	      $x=new mcq;
	      $mcqcount=0;
	      $x->id=$count;
	      $qusType="";
	      $string=fgets($myfile);
		  $qusType=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);
          $x->qusTy=$qusType;
          $string=fgets($myfile);
		  $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);
		  $qus="";
          $manage=substr($string,0,strpos($string,":"));
          for($i=0;$manage!="Option_1";$i++){ 
                $qus.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
          $qus=rtrim($qus,"<br/>");
          $x->q=$qus;

          $op1="";
          $manage=substr($string,0,strpos($string,":"));
          for($i=0;$manage!="Option_2";$i++){ 
                $op1.=substr($string,strpos($string,":")+1,strlen($string))."<br/>"; 
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
           $op1=rtrim($op1,"<br/>");
           $op11=preg_replace('/\s/', '', $op1);
           $x->a["$mcqcount"]=$op1;
           $mcqcount++;

          $op2="";
          $manage=substr($string,0,strpos($string,":"));
          for($i=0;$manage!="Option_3";$i++){ 
                $op2.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
           $op2=rtrim($op2,"<br/>");
           $op22= preg_replace('/\s/', '', $op2);
           $x->a["$mcqcount"]=$op2;
           $mcqcount++;

    	  $op3="";
          $manage=substr($string,0,strpos($string,":"));
          for($i=0;$manage!="Option_4";$i++){ 
                $op3.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
           $op3=rtrim($op3,"<br/>");
           $op33= preg_replace('/\s/', '', $op3);
           $x->a["$mcqcount"]=$op3;
           $mcqcount++;


          $op4="";
          $manage=substr($string,0,strpos($string,":"));

          for($i=0;$manage!="Answer_".$count;$i++){ 
                $op4.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                $string=fgets($myfile);
			  	$string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                $manage=substr($string,0,strpos($string,":"));
          }
           $op4=rtrim($op4,"<br/>");
           $op44= preg_replace('/\s/', '', $op4);
           $x->a["$mcqcount"]=$op4;
           $mcqcount++;
           
           $answer=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
	       $string=fgets($myfile);
		   $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
           $manage=substr($string,0,strpos($string,":"));
           $marks='';
           $marks.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
           $marks=rtrim($marks,"<br/>");
           $marks=preg_replace('/\s/', '', $marks);
          $count++;
          $x->Smarks=$marks;
          array_push($allmcq,$x);
    }
?>
<p id="demo"></p> 
    <form action="resultCalculate.php" id="myForm" method="post">
    <div class="headerarea">
      <div class="header">
        <input type="hidden" value="<?php echo $txtLocation;?>" name="texname">
        <h1 class="subjectname"><?php echo strtoupper($subjectName);?></h1>
      </div>
    </div>
      <div class="allCaintain">
          <?php 
          for($i=0;$i<sizeof($allmcq);$i++){
            // correct msq must put 0-3
            $suffarr=array(0,1,2,3);
           // $key1s = array_keys($x->a);
            $op11=$suffarr[0];
            $op22=$suffarr[1];
            $op33=$suffarr[2];
            $op44=$suffarr[3];
            $marksCount="marks".($i+1);
            if($allmcq[$i]->qusTy=='radio'){
           ?>
           <div class="fullMcq col-md-9">
            <div class="qustion" style="color: grey;">Question <?php echo ($i+1).":";?> <b style="color: rgb(0,0,0);"><?php echo "  ".$allmcq[$i]->q; ?></b></div><br/>
           <span class="marks"><b><?php echo $allmcq[$i]->Smarks;?>&nbsp; Marks <== </b></span><br/>
           
           <label class="container"><?php echo $allmcq[$i]->a[$suffarr[0]];?>
              <input type="radio" name="<?php echo "option".$allmcq[$i]->id; ?>" class="op1" value="<?php echo "$op11";?>" <?php ($realResult[$i]==0)?print('checked'):print(''); ?> >
              <span class="checkmark opsp1"></span><br/>
            </label>

            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[1]];?>
              <input type="radio" name="<?php echo "option".$allmcq[$i]->id; ?>" class="op2" value="<?php echo $op22;?>" <?php ($realResult[$i]==1)?print('checked'):print('');?>>
              <span class="checkmark opsp2"></span><br/>
            </label>
            
            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[2]];?>
              <input type="radio" name="<?php echo "option".$allmcq[$i]->id; ?>" class="op3" value="<?php echo $op33;?>" <?php ($realResult[$i]==2)?print('checked'):print('');?> >
              <span class="checkmark opsp3"></span><br/>
            </label>
            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[3]];?>
              <input type="radio" name="<?php echo "option".$allmcq[$i]->id; ?>" class="op4" value="<?php echo $op44;?>" <?php ($realResult[$i]==3)?print('checked'):print('');?> >
              <span class="checkmark opsp4"></span><br/>
            </label> 
            <hr>
        </div>
        <?php
        	}
        	if($allmcq[$i]->qusTy=='checkbox'){
            $tempans=explode('-', $realResult[$i]);
            $xx=count($tempans);
        ?>
			<div class="fullMcq col-md-9">
           <div class="qustion" style="color: grey;">Question <?php echo ($i+1).":";?> <b style="color: rgb(0,0,0);"><?php echo "  ".$allmcq[$i]->q; ?></b></div><br/>
           <span class="marks"><b><?php echo $allmcq[$i]->Smarks;?>&nbsp; Marks <== </b></span><br/>
           
           <label class="container"><?php echo $allmcq[$i]->a[$suffarr[0]];?>
              <input type="checkbox" name="<?php echo "option".$allmcq[$i]->id; ?>[]" class="op1" value="<?php echo $op11;?>" <?php for($x=0;$x<$xx;$x++){if($tempans[$x]==0)echo 'checked';} ?> >
              <span class="checkmark opsp1"></span><br/>
            </label>

            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[1]];?>
              <input type="checkbox" name="<?php echo "option".$allmcq[$i]->id; ?>[]" class="op2" value="<?php echo $op22;?>" <?php for($x=0;$x<$xx;$x++){if($tempans[$x]==1)echo 'checked';} ?>>
              <span class="checkmark opsp2"></span><br/>
            </label>
            
            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[2]];?>
              <input type="checkbox" name="<?php echo "option".$allmcq[$i]->id; ?>[]" class="op3" value="<?php echo $op33;?>" <?php for($x=0;$x<$xx;$x++){if($tempans[$x]==2)echo 'checked';} ?>>
              <span class="checkmark opsp3"></span><br/>
            </label>
            <label class="container"><?php echo $allmcq[$i]->a[$suffarr[3]];?>
              <input type="checkbox" name="<?php echo "option".$allmcq[$i]->id; ?>[]" class="op4" value="<?php echo $op44;?>" <?php for($x=0;$x<$xx;$x++){if($tempans[$x]==3)echo 'checked';} ?>>
              <span class="checkmark opsp4"></span><br/>
            </label> 
            <hr>
          </div>
        <?php
        	}
        	if($allmcq[$i]->qusTy=='written'){
        ?>
			<div class="fullMcq col-md-9">
           <div class="qustion" style="color: grey;">Question <?php echo ($i+1).":";?> <b style="color: rgb(0,0,0);"><?php echo "  ".$allmcq[$i]->q; ?></b></div><br/>
           <span class="marks"><b><?php echo $allmcq[$i]->Smarks;?>&nbsp; Marks <== </b></span><br/>
           
           <label class="container"><?php echo $allmcq[$i]->a[$suffarr[0]]; echo "<br/>".$realResult[$i];?>
            <input type="text" style="float: right" class="mymarks" placeholder="Enter Marks" >
             <!-- <textarea  name="<?php //echo "option".$allmcq[$i]->id; ?>" rows="3" style="width: 100%;" placeholder="Enter The Question" class="quefont" id="qus<?php //echo $i+1;?>"></textarea> -->
           </label>
            <hr>
        </div>    
        <?php
        	}  
          } 
          //arsort($allmcq->a);
          shuffle($allmcq);
          if(isset($p[3])){
            if($p[3]=='edit'){
        ?>
        <script type="text/javascript">
           function getGoBack(){
            location.replace('../admin/classroom/studentSubmitExam.php?n=<?php echo $txtLocation;?>');
           }
        </script>
        <?php
          }
        }
        ?>