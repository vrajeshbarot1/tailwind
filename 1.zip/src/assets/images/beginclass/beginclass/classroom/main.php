<?php 
    session_start();
    $who=$_SESSION['who'];
    include '../php/database.php';
    if($who!='student' || $who=='')
        header('location:../html/login.php');
    $cid=$_SESSION['classRoomId'];
    //upcomming
    date_default_timezone_set('Asia/Kolkata');
    $now=date('Y-m-d H:i:s');
    $upcomming=0;
    $sql="select * from ".$cid."_metadata where starttime >'".$now."'";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $upcomming++;
        }
    }else echo mysqli_error($db);

    $live=0;
    $sql="select * from ".$cid."_metadata where '".$now."' > starttime and '".$now."'< endtime";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $live++;
        }
    }else echo mysqli_error($db);

    $past=0;
    $sql="select * from ".$cid."_metadata where endtime <'".$now."'";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $past++;
        }
    }else echo mysqli_error($db);

    $totalStu=0;
    $sql="select * from clasroomstud where classroom_id ='".ltrim($cid,'c')."'";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $totalStu++;
        }
    }else echo mysqli_error($db);

    $userStu=0;
    $sql="select * from users";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $userStu++;
        }
    }else echo mysqli_error($db);

    $subjects=0;
    $sql="select * from ".$cid."_metadata";
    $result=mysqli_query($db,$sql);
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $subjects++;
        }
    }else echo mysqli_error($db);

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="Codedthemes" />
    <!-- Favicon icon -->
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">

    <!-- vendor css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <style type="text/css">
        .right-part-content{
            position: relative;
            overflow-x: hidden;
            padding: 20px;
        }
    </style>
</head>
<body>
 <!-- [ breadcrumb ] start -->
        <!-- <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard Analytics</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard Analytics</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="right-part-content">
        <div class="row">
            <!-- order-card start -->
            <div class="col-md-4 col-sm-6 col-12">
                <div class="card bg-c-blue order-card">
                    <div class="card-body">
                        <h6 class="text-white">Upcoming Exams</h6>
                        <h2 class="text-right text-white"><i class="feather icon-sunset float-left"></i><span><?php echo $upcomming; ?></span></h2>
                       <!--  <p class="m-b-0"><?php //echo $_SESSION['collageFullName'];?></p> -->
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-12">
                <div class="card bg-c-green order-card">
                    <div class="card-body">
                        <h6 class="text-white">Activate Exams</h6>
                        <h2 class="text-right text-white"><i class="feather icon-layout float-left"></i><span><?php echo $live;?></span></h2>
                       <!--  <p class="m-b-0">This Month<span class="float-right">213</span></p> -->
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-12">
                <div class="card bg-c-yellow order-card">
                    <div class="card-body">
                        <h6 class="text-white">Completed Exams</h6>
                        <h2 class="text-right text-white"><i class="feather icon-pocket float-left"></i><span><?php echo $past;?></span></h2>
                       <!--  <p class="m-b-0">This Month<span class="float-right">$5,032</span></p> -->
                    </div>
                </div>
            </div>
            <!-- order-card end -->
            <!-- users visite start -->
            <div class="col-md-12 col-xl-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Unique Chart</h5>
                    </div>
                    <div class="card-body pl-0 pb-0">
                        <div id="unique-visitor-chart"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-xl-6">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-body bg-patern">
                                <div class="row">
                                    <div class="col-auto">
                                        <span>Students</span>
                                    </div>
                                    <div class="col text-right">
                                    </div>
                                </div>
                                <div id="customer-chart"></div>
                                <div class="row mt-3">
                                    <div class="col">
                                        <h3 class="m-0"><i class="fas fa-circle f-10 m-r-5 text-success"></i><?php echo $totalStu;?></h3>
                                        <span class="ml-3"><?php echo $_SESSION['clg'];?> Students</span>
                                    </div>
                                    <div class="col">
                                        <h3 class="m-0"><i class="fas fa-circle text-primary f-10 m-r-5"></i><?php echo $subjects;?></h3>
                                        <span class="ml-3">Exams</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--<div class="col-sm-6">
                        <div class="card bg-primary text-white">
                            <div class="card-body bg-patern-white">
                                <div class="row">
                                    <div class="col-auto">
                                        <span><?php //echo $_SESSION['clg'];?></span>
                                    </div>
                                    <div class="col text-right">
                                    </div>
                                </div>
                                <div id="customer-chart1"></div>
                                <div class="row mt-3">
                                    <div class="col">
                                        <h3 class="m-0 text-white"><i class="fas fa-circle f-10 m-r-5 text-success"></i><?php //echo $totalStu; ?></h3>
                                        <span class="ml-3"><?php //echo$_SESSION['clg']; ?> Stduents</span>
                                    </div>
                                    <div class="col">
                                        <h3 class="m-0 text-white"><i class="fas fa-circle f-10 m-r-5 text-white"></i><?php // echo $userStu; ?></h3>
                                        <span class="ml-3">Stduents</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>-->
                </div>
            </div>
            <!-- users visite end -->


            <!-- social statustic start -->
            <div class="col-md-12 col-lg-4"></div>
            <div class="col-md-6 col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                        <i class="feather icon-file-text text-c-green d-block f-40"></i>
                        <h4 class="m-t-20"><span class="text-c-blgreenue"><?php echo $subjects;?></span> Subjects</h4>
                        <p class="m-b-20">Your main list is growing</p>
                        <button class="btn btn-success btn-sm btn-round">Check them out</button>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-2"></div>
            <!-- social statustic end -->
        </div>
    </div>
    <script src="assets/js/vendor-all.min.js"></script>
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <script src="assets/js/pcoded.min.js"></script>

<!-- Apex Chart -->
<script src="assets/js/plugins/apexcharts.min.js"></script>


<!-- custom-chart js -->
<!-- <script src="assets/js/pages/dashboard-main.js"></script> -->
<script type="text/javascript">
    'use strict';
$(document).ready(function() {
    setTimeout(function() {
        floatchart()
    }, 100);
    // [ campaign-scroll ] start
    var px = new PerfectScrollbar('.customer-scroll', {
        wheelSpeed: .5,
        swipeEasing: 0,
        wheelPropagation: 1,
        minScrollbarLength: 40,
    });
    var px = new PerfectScrollbar('.customer-scroll1', {
        wheelSpeed: .5,
        swipeEasing: 0,
        wheelPropagation: 1,
        minScrollbarLength: 40,
    });
    var px = new PerfectScrollbar('.customer-scroll2', {
        wheelSpeed: .5,
        swipeEasing: 0,
        wheelPropagation: 1,
        minScrollbarLength: 40,
    });
    var px = new PerfectScrollbar('.customer-scroll3', {
        wheelSpeed: .5,
        swipeEasing: 0,
        wheelPropagation: 1,
        minScrollbarLength: 40,
    });
    // [ campaign-scroll ] end
});

function floatchart() {
    // [ seo-card1 ] start
    $(function() {
        var options1 = {
            chart: {
                type: 'area',
                height: 145,
                sparkline: {
                    enabled: true
                }
            },
            dataLabels: {
                enabled: false
            },
            colors: ["#ff5370"],
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark',
                    gradientToColors: ['#ff869a'],
                    shadeIntensity: 1,
                    type: 'horizontal',
                    opacityFrom: 1,
                    opacityTo: 0.8,
                    stops: [0, 100, 100, 100]
                },
            },
            stroke: {
                curve: 'smooth',
                width: 2,
            },
            series: [{
                data: [45, 35, 60, 50, 85, 70]
            }],
            yaxis: {
               min: 5,
               max: 90,
           },
            tooltip: {
                fixed: {
                    enabled: false
                },
                x: {
                    show: false
                },
                y: {
                    title: {
                        formatter: function(seriesName) {
                            return 'Papers '
                        }
                    }
                },
                marker: {
                    show: false
                }
            }
        }
        new ApexCharts(document.querySelector("#seo-card1"), options1).render();
    });
    // [ seo-card1 ] end
    // [ customer-chart ] start
    $(function() {
        var options = {
            chart: {
                height: 150,
                type: 'donut',
            },
            dataLabels: {
                enabled: false
            },
            plotOptions: {
                pie: {
                    donut: {
                        size: '75%'
                    }
                }
            },
            labels: ['Exams', 'students'],
            series: [<?php echo $subjects;?>, <?php echo $totalStu;?>],
            legend: {
                show: false
            },
            tooltip: {
                theme: 'datk'
            },
            grid: {
                padding: {
                    top: 20,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
            },
            colors: ["#4680ff", "#2ed8b6"],
            fill: {
                opacity: [1, 1]
            },
            stroke: {
                width: 0,
            }
        }
        var chart = new ApexCharts(document.querySelector("#customer-chart"), options);
        chart.render();
        var options1 = {
            chart: {
                height: 150,
                type: 'donut',
            },
            dataLabels: {
                enabled: false
            },
            plotOptions: {
                pie: {
                    donut: {
                        size: '75%'
                    }
                }
            },
            labels: ['Total Stduetns', 'This Clss Stduetns'],
            series: [<?php echo $userStu; ?>, <?php echo $totalStu; ?>],
            legend: {
                show: false
            },
            tooltip: {
                theme: 'dark'
            },
            grid: {
                padding: {
                    top: 20,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
            },
            colors: ["#fff", "#2ed8b6"],
            fill: {
                opacity: [1, 1]
            },
            stroke: {
                width: 0,
            }
        }
        var chart = new ApexCharts(document.querySelector("#customer-chart1"), options1);
        chart.render();
    });
    // [ customer-chart ] end
    // [ unique-visitor-chart ] start
    $(function() {
        var options = {
            chart: {
                height: 230,
                type: 'line',
                toolbar: {
                    show: false,
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                width: 2,
                curve: 'smooth'
            },
            series: [{
                name: 'Exam',
                data: [20, 50, 30, 60, 30, 50]
            }, {
                name: 'Stduetns',
                data: [60, 30, 65, 45, 67, 35]
            }],
            legend: {
                position: 'top',
            },
            xaxis: {
                type: 'datetime',
                categories: ['1/11/<?php echo date("Y");?>', '2/11/<?php echo date("Y");?>', '3/11/<?php echo date("Y");?>', '4/11/<?php echo date("Y");?>', '5/11/<?php echo date("Y");?>', '6/11/<?php echo date("Y");?>'],
                axisBorder: {
                    show: false,
                },
                label: {
                    style: {
                        color: '#ccc'
                    }
                },
            },
            yaxis: {
                show: true,
                min: 10,
                max: 70,
                labels: {
                    style: {
                        color: '#ccc'
                    }
                }
            },
            colors: ['#73b4ff', '#59e0c5'],
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'light',
                    gradientToColors: ['#4099ff', '#2ed8b6'],
                    shadeIntensity: 0.5,
                    type: 'horizontal',
                    opacityFrom: 1,
                    opacityTo: 1,
                    stops: [0, 100]
                },
            },
            markers: {
                size: 5,
                colors: ['#4099ff', '#2ed8b6'],
                opacity: 0.9,
                strokeWidth: 2,
                hover: {
                    size: 7,
                }
            },
            grid: {
                borderColor: '#cccccc3b',
            }
        }
        var chart = new ApexCharts(document.querySelector("#unique-visitor-chart"), options);
        chart.render();
    });
    // [ unique-visitor-chart ] end
}
$('#chatopen').click(function(){
    location.replace('chatlist.php');
})
</script>
</body>
</html>