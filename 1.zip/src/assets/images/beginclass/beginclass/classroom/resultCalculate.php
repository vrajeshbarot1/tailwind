<?php
session_start();
    $who=$_SESSION['who'];
  if($who!='student' || $who==''){
    header("location:../html/login.php");
    exit; 
  }else{
    include '../php/database.php';
    $myname=$_SESSION["uid"];
    $cid=$_SESSION['classRoomId'];
    $txtLocation=$_POST['texname'];
    $enrollNum=$_POST['enrollnum'];
    date_default_timezone_set('Asia/Kolkata');
    $now=date('Y-m-d H:i:s');
    $sql="create table if not exists ".$cid."_result(u_phono varchar(20),txtname varchar(40),my_marks varchar(50),result text)";
    mysqli_query($db,$sql);
    $sql="select * from ".$cid."_result where u_phono='".$enrollNum."'and txtname='".$txtLocation."'";
      $result=mysqli_query($db,$sql);
    if (mysqli_num_rows($result) > 0) {
        ?>
        <script type="text/javascript">alert("already Data Exists");window.close();</script>
    <?php
    }
    else{
    $totalQuestion=$_POST['totalQuestion'];
    $sendedAmswer=array();
    $finalResultGenerate='';
    for($i=1;$i<=$totalQuestion;$i++){
       if(isset($_POST['option'.$i])){
            $text=$_POST['option'.$i];
            if(is_array($text)){
              $text= join("-", $_POST['option'.$i]); 
              array_push($sendedAmswer,$text);
            }
            else
              array_push($sendedAmswer,$text);
          }
          else{
              array_push($sendedAmswer,"");
          }
      }  
    // print_r($sendedAmswer);
     $temp='';$myMarksForPaper=0;$myQustionPaperMarks=0;
     $mycheckboxCount=0;
     foreach ($sendedAmswer as $value) {
        $temp.=$value.'<<>!<>>';
     }  
     $myAnsForPaperCheck=explode('<<>!<>>',$temp);
     $myfile = fopen("../paper/".$txtLocation.".txt", "r") or die("Unable to open file!");
     $count=1;
    $ciphering = "AES-128-CTR"; 
    $iv_length = openssl_cipher_iv_length($ciphering); 
    $options = 0; 
    $decryption_iv = '1234567891011121'; 
    $decryption_key = "BeginClassForBeginners"; 
    
    $string=fgets($myfile);
    $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
    //echo $string."<br/>";
    
    $string=fgets($myfile);
    $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
    //echo $string."<br/>";
    $subjectName='';
    $string=fgets($myfile);
    $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
    $subjectName.=substr($string,strpos($string,":")+1,strlen($string));
    //echo $subjectName;
      
      class mcq{
        var $q;
        var $a;
        var $Smarks;
        var $id;
        var $qusTy;
        var $myAns;
        function __construct(){
          $this->a=array();
        }
       }
        $allmcq=array();
        $j=0;
      while(!feof($myfile)){
          $x=new mcq;
          $mcqcount=0;
          $x->id=$count;
          $qusType="";
          $string=fgets($myfile);
        $qusType=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);
            $x->qusTy=$qusType;
            $string=fgets($myfile);
        $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);
        $qus="";
            $manage=substr($string,0,strpos($string,":"));
            for($i=0;$manage!="Option_1";$i++){ 
                  $qus.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                  $string=fgets($myfile);
            $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                  $manage=substr($string,0,strpos($string,":"));
            }
            $qus=rtrim($qus,"<br/>");
            $x->q=$qus;

            $op1="";
            $manage=substr($string,0,strpos($string,":"));
            for($i=0;$manage!="Option_2";$i++){ 
                  $op1.=substr($string,strpos($string,":")+1,strlen($string))."<br/>"; 
                  $string=fgets($myfile);
            $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                  $manage=substr($string,0,strpos($string,":"));
            }
             $op1=rtrim($op1,"<br/>");
             $op11=preg_replace('/\s/', '', $op1);
             $x->a["$mcqcount"]=$op1;
             $mcqcount++;

            $op2="";
            $manage=substr($string,0,strpos($string,":"));
            for($i=0;$manage!="Option_3";$i++){ 
                  $op2.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                  $string=fgets($myfile);
            $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                  $manage=substr($string,0,strpos($string,":"));
            }
             $op2=rtrim($op2,"<br/>");
             $op22= preg_replace('/\s/', '', $op2);
             $x->a["$mcqcount"]=$op2;
             $mcqcount++;

          $op3="";
            $manage=substr($string,0,strpos($string,":"));
            for($i=0;$manage!="Option_4";$i++){ 
                  $op3.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                  $string=fgets($myfile);
            $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                  $manage=substr($string,0,strpos($string,":"));
            }
             $op3=rtrim($op3,"<br/>");
             $op33= preg_replace('/\s/', '', $op3);
             $x->a["$mcqcount"]=$op3;
             $mcqcount++;


            $op4="";
            $manage=substr($string,0,strpos($string,":"));

            for($i=0;$manage!="Answer_".$count;$i++){ 
                  $op4.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
                  $string=fgets($myfile);
            $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
                  $manage=substr($string,0,strpos($string,":"));
            }
             $op4=rtrim($op4,"<br/>");
             $op44= preg_replace('/\s/', '', $op4);
             $x->a["$mcqcount"]=$op4;
             $mcqcount++;
             
            $answer=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
            $answer=rtrim($answer,"<br/>");
            $answer= preg_replace('/\s/', '', $answer);
            $x->myAns=$answer;
            //ans ayiya 6


            $string=fgets($myfile);
            $string=openssl_decrypt ($string, $ciphering,$decryption_key, $options, $decryption_iv);  
             $manage=substr($string,0,strpos($string,":"));
             $marks='';
             $marks.=substr($string,strpos($string,":")+1,strlen($string))."<br/>";
             $marks=rtrim($marks,"<br/>");
             $marks=preg_replace('/\s/', '', $marks);
            $count++;
            $x->Smarks=$marks;
            array_push($allmcq,$x);
      }
         //shuffle($allmcq);
          for($i=0;$i<sizeof($allmcq);$i++){
            // correct msq must put 0-3
            $suffarr=array(0,1,2,3);
           // $key1s = array_keys($x->a);
            $op11=$suffarr[0];
            $op22=$suffarr[1];
            $op33=$suffarr[2];
            $op44=$suffarr[3];
            $marksCount="marks".($i+1);
            if($allmcq[$i]->qusTy=='radio'){
              if($myAnsForPaperCheck[$i]==$allmcq[$i]->myAns){ 
                //yes for radio
                $myMarksForPaper+=$allmcq[$i]->Smarks;
              echo "radio=>".$myMarksForPaper."<br/>";
              }     
              $myQustionPaperMarks+=$allmcq[$i]->Smarks;       
          }
          if($allmcq[$i]->qusTy=='checkbox'){
            $tempans=explode('-', $allmcq[$i]->myAns);
            $myQustionPaperMarks+=$allmcq[$i]->Smarks;
            $checkboxans=explode('-', $myAnsForPaperCheck[$i]);
//           print_r($checkboxans);echo "<br/>";
  //         print_r($tempans);echo "<br/>";
            for($zp=0;$zp<count($checkboxans);$zp++){
              for($zp1=0;$zp1<count($tempans);$zp1++){
                if($checkboxans[$zp]!=''){
                  if($checkboxans[$zp] === $tempans[$zp1]){
                    $mycheckboxCount++;
                  }
                }  
              }
          }
           $getMarks=($allmcq[$i]->Smarks)/4;
           $myMarksForPaper+=($getMarks*$mycheckboxCount);
        }
        if($allmcq[$i]->qusTy=='written'){
          $myQustionPaperMarks+=$allmcq[$i]->Smarks;
        }
          //echo $myMarksForPaper."<br/>";  
        } 
     $sql="insert into ".$cid."_result values('".$enrollNum."','".$txtLocation."','".$myMarksForPaper.'/'.$myQustionPaperMarks."','".$temp."')";
    $result=mysqli_query($db,$sql);
    if($result)
        {
        ?>
        <script type='text/javascript'>
        alert('Successfully Sended');window.close();
        </script>
        <?php
        }
      else {
          echo "<script type='text/javascript'>alert('faild! something was wrong..');window.close();</script>";
      }
      mysqli_close($db);
  }
}  
?>