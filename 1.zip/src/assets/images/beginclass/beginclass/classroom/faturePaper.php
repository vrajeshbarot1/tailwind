<?php
   $sql="select * from ".$classRoomId."_metadata where txtname='".$txtLocation."'";
     $result=mysqli_query($db,$sql);
    if (mysqli_num_rows($result) == 1) {
      while($row = mysqli_fetch_assoc($result)){
        $subjectName =  $row['subject'];
      }
    }
?>
<h3>Paper will starts On :</h3>
  <p id="startat">Paper will starts On :<p id="demo"></p></p>
  <div class="headerarea">
    <div class="header">
      <h1 class="subjectname"><?php echo ucwords($subjectName);?></h1>
    </div>
  </div>
  <script type="text/javascript">
  var countDownDate = new Date('<?php echo $st;?>').getTime();
  var x = setInterval(function() {
    var now = new Date().getTime();
    var distance = countDownDate - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    document.getElementById("demo").innerHTML = days + "d " + hours + "h "
    + minutes + "m " + seconds + "s ";
    if (distance < 0) {
      clearInterval(x);
      document.getElementById("demo").innerHTML = "EXPIRED";
      window.location.reload();
    }
  }, 1000);
</script>