<?php
	session_start();
	$classRoomId=$_SESSION['classRoomId'];	
	$mymobileNo=$_SESSION['uid'];
	$clg=$_SESSION['clg'];
    include '../php/database.php';
    $who=$_SESSION['who'];
	if($who=='student' || $who=='')
		header('location:../html/login.php');
	$x=$_GET['d'];
	$p=explode('-',$x);
	$txtLocation=$p[1];
	$myid=$p[0];
	$myName=$p[2];
	date_default_timezone_set('Asia/Kolkata');
    $nowCompareExamTime=date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="assets/css-js/bootstrap.min.css">
    <script src="assets/css-js/jquery.min.js"></script>
    <script src="assets/css-js/popper.min.js"></script>
    <script src="assets/css-js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Orbitron&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=.5, maximum-scale=12.0, minimum-scale=.25, user-scalable=yes"/>
	<style type="text/css">
    	  body{
    	  	padding-bottom: 50px;
    	  }
    	   p {
			    text-align: center;
			    font-size: 40px;
			    margin-top: 0px;
			    font-family:'Orbitron','sans-serif'; 
			  }
			 body{
			  background-color: #f0f0f0;
			 }
			      .container {
			  display: block;
			  margin-top: 10px;
			  position: relative;
			  padding-left: 35px;
			  margin-bottom: 12px;
			  margin-left: 30px;
			  cursor: pointer;
			  font-size: 1em;
			  width: auto;
			  -webkit-user-select: none;
			  -moz-user-select: none;
			  -ms-user-select: none;
			  user-select: none;
			}
			.allCaintain{
			   border:1px solid lightgrey;
			   border-left: none;
			   border-right:none;
			   width: 100%;
			}
			.fullMcq{
			  position: relative;
			  /*background-color: red;*/
			   margin-top: 100px;
			 
			  /*width: 70%;*/
			  padding: 30px;

			   padding-bottom: 0px;
			  margin: auto;
			}
			.marks{
			    position: absolute;
			    right: 4vw;
			}
			.qustion{
			   position: relative;
			   font-size: 1.2em;
			   font-weight: 600;
			}
			.header{
			  position: fixed;
			  top: 0px;
			  z-index: 15;
			  background-color: #3d619b;
			  height: 70px;
			  margin-bottom: 100px;
			  width: 100%;
			}
			#startat{
			  position: fixed;
			  top: -10px;
			  background-color:none;
			  z-index: 16;
			  color:white;
			  right: 380px;
			  font-size: 2em;
			  padding: 20px;
			}
			#demo{
			  position: fixed;
			  top: -10px;
			  background-color:none;
			  z-index: 16;
			  color:white;
			  right: 30px;
			  font-size: 2em;
			  padding: 20px;
			}
			/*orbitron*/
			.subjectname{
			  font-family: sans-serif;
			  color: #fff;
			  margin-top: 5px;
			  margin-left: 30px;
			  letter-spacing: 1px;
			}
			.headerarea{
			  height: 100px;
			  position: relative;
			  width: 100%;
			}
			.smtbtn{
			  position: relative;
			  margin:20px;
			  margin-left: 230px;
			}
			.backWork{
			  right: 40px;
			  top: 100px;
			  position: absolute;
			}
			img{
			  z-index: 7;
			  position: relative;
			  transition: 1.8s;
			}
			img:hover{
			  z-index: 17;
			   transform: scale(3);
			   margin-left:20%;  
			}
			#subnmaemobile{
				display: none;
			}	
			@media only screen and (max-width: 789px){
				img:hover{
				   transform: scale(1.5); 
				}
			}
			@media only screen and (max-width: 1300px){
				img:hover{
				   transform: scale(2.3); 
				}
			}
			@media only screen and (max-width: 500px){
				.subjectname{
					margin-top: 100px;
					color:black;
					display: none;
					position: relative;
				}
				#subnmaemobile{
					display: block;
				}	
			img:hover{
			   transform: scale(1.6); 
			}
			}
    </style>
</head>
<body>
	<?php
        $myfile = fopen("../paper/".$txtLocation.".txt", "r") or die("Unable to open file!");
      $sqlfortime="select * from ".$classRoomId."_metadata where txtname ='".$txtLocation."'";
            $listup = mysqli_query($db,$sqlfortime);
            $total=0;
            if (mysqli_num_rows($listup) > 0) {
                while($row = mysqli_fetch_assoc($listup)) {
                    $st=$row['starttime'];
                    $ed=$row['endtime'];
               }
            }
        $n=strtotime($nowCompareExamTime);
        $u=strtotime($st);
        $e=strtotime($ed);
  // past      
      //if($n>$e){
		    include 'studentPastPaperShowAdmin.php';
//      }

      	?>
<!-- 	<input type="file" id="inputx" onclick="fun()" > -->
</body>      

<script type="text/javascript">
$('img[data-enlargable]').addClass('img-enlargable').click(function(){
    var src = $(this).attr('src');
    var modal;
    function removeModal(){ modal.remove(); $('body').off('keyup.modal-close'); }
    modal = $('<div>').css({
        background: 'RGBA(0,0,0,.5) url('+src+') no-repeat center',
        backgroundSize: 'contain',
        width:'100%', height:'100%',
        position:'fixed',
        zIndex:'10000',
        top:'0', left:'0',
        cursor: 'zoom-out'
    }).click(function(){
        removeModal();
    }).appendTo('body');
    //handling ESC
    $('body').on('keyup.modal-close', function(e){
      if(e.key==='Escape'){ removeModal(); } 
    });
});
function getText(){
	let bla=0,secondOne='<?php echo $jsputMarks[1];?>',firstOne='<?php echo $jsputMarks[0];?>',id='<?php echo $myid; ?>',txl='<?php echo $txtLocation;?>';
	$('input[type=text]').each(function() {
 		  bla+=parseFloat($(this).val());
	})
	bla+=parseFloat(firstOne);
		//alert(bla+'/'+secondOne);
		if(bla > parseFloat(secondOne)){
			alert('Student marks is greater than Paper Marks');
		}
		else{
			bla=bla+'/'+secondOne;
			 $.ajax({
	            url:'../admin/classroom/ajax.php',
	            data:{
	                work:'StudentIncrementMarks',
	                txl:txl,
	                mrk:bla,
	                id:id
	            },
	            type:"POST",
	            success:function(a,b){
	                alert(a);
	                location.reload();
	            }
	        });	
		}
}
</script>
</html>