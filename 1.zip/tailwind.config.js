module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      fontFamily: {
        'Playfair': ["'Playfair Display', serif"],
      },
      fontSize: {
        '5xl': '2.5rem'
      },
      colors: {
        'green': {
          100: '#E7F2ED',
          200: '#D0D0A7',
          300: '#808013',
          500: '#04282D',
          600: '#a3b6b3',
          700: 'rgba(4, 40, 45, 0.3)'
        },
        'yellow': {
          100:'#F2F2E6'
        },
        'orange': {
          100: '#F8A488'
        },
        'blue': {
          400: '#0B8497',
        },
        'grey': {
          100: '#777777',
          200: 'rgba(0,0,0,.5)'
        }
      }
    },
  },
  plugins: [],
}
